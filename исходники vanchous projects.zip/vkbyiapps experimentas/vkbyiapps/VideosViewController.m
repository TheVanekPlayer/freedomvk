// VideosViewController.m
#import "VideosViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "VideoPlayerViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface VideosViewController () <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate> {
    UITableView *tableView;
    NSArray *videos;
    UIActivityIndicatorView *spinner;
    UISearchBar *searchBar;
    NSMutableDictionary *imageCache;
    UILabel *emptyLabel;
}
@end

@implementation VideosViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Видеозаписи";
    self.view.backgroundColor = [ThemeManager backgroundColor];
    imageCache = [NSMutableDictionary dictionary];
    
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 44)];
    searchBar.delegate = self;
    searchBar.placeholder = @"Поиск видео";
    searchBar.tintColor = [ThemeManager navigationBarTintColor];
    searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [self.view addSubview:searchBar];
    
    tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, self.view.bounds.size.width, self.view.bounds.size.height - 44) style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.rowHeight = 76;
    tableView.separatorColor = [ThemeManager separatorColor];
    [self.view addSubview:tableView];
    
    emptyLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height/2 - 60, self.view.bounds.size.width, 60)];
    emptyLabel.text = @"Видеозаписей нет";
    emptyLabel.textAlignment = NSTextAlignmentCenter;
    emptyLabel.font = [UIFont systemFontOfSize:14];
    emptyLabel.textColor = [UIColor grayColor];
    emptyLabel.numberOfLines = 2;
    emptyLabel.hidden = YES;
    [self.view addSubview:emptyLabel];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [self loadVideos];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadVideos {
    [spinner startAnimating];
    emptyLabel.hidden = YES;
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *uid = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    NSString *urlString = [NSString stringWithFormat:@"%@video.get?owner_id=%@&count=50&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], uid, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [spinner stopAnimating];
            if (error || json[@"error"]) {
                videos = @[];
            } else {
                id items = json[@"response"][@"items"];
                if (![items isKindOfClass:[NSArray class]]) items = @[];
                videos = items;
            }
            [tableView reloadData];
            if (videos.count == 0) {
                emptyLabel.hidden = NO;
                emptyLabel.text = @"Видеозаписей нет или они недоступны в OpenVK";
            }
        });
    });
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)sb {
    [sb resignFirstResponder];
    NSString *query = [sb.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (query.length == 0) { [self loadVideos]; return; }
    
    [spinner startAnimating];
    emptyLabel.hidden = YES;
    
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *q = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlString = [NSString stringWithFormat:@"%@video.search?q=%@&count=50&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], q, token];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [spinner stopAnimating];
            if (error || json[@"error"] || !json[@"response"]) {
                videos = @[];
            } else {
                id items = json[@"response"][@"items"];
                if (![items isKindOfClass:[NSArray class]]) items = @[];
                videos = items;
            }
            [tableView reloadData];
            if (videos.count == 0) {
                emptyLabel.hidden = NO;
                emptyLabel.text = @"Поиск видео недоступен\nв OpenVK";
            }
        });
    });
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return videos.count;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"VideoCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:13];
        cell.textLabel.textColor = [ThemeManager cellTextColor];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.textLabel.numberOfLines = 2;
        cell.detailTextLabel.font = [UIFont systemFontOfSize:11];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = 3;
        cell.imageView.layer.borderWidth = 1;
        cell.imageView.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
        cell.imageView.frame = CGRectMake(0, 0, 90, 60);
        cell.imageView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    }
    
    cell.imageView.image = nil;
    cell.textLabel.text = @"";
    cell.detailTextLabel.text = @"";
    
    if (indexPath.row >= videos.count) return cell;
    NSDictionary *video = [videos objectAtIndex:indexPath.row];
    if (![video isKindOfClass:[NSDictionary class]]) return cell;
    
    cell.textLabel.text = [video objectForKey:@"title"] ?: @"Без названия";
    NSInteger duration = [[video objectForKey:@"duration"] integerValue];
    NSInteger views = [[video objectForKey:@"views"] integerValue];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld:%02ld  •  👁 %ld", (long)duration/60, (long)duration%60, (long)views];
    
    NSString *previewURL = [video objectForKey:@"photo_320"] ?: [video objectForKey:@"photo_130"] ?: [video objectForKey:@"photo_800"];
    if ([previewURL isKindOfClass:[NSString class]] && previewURL.length > 0) {
        UIImage *cached = [imageCache objectForKey:previewURL];
        if (cached) {
            cell.imageView.image = cached;
        } else {
            NSString *cellURL = [previewURL copy];
            [[VKAPIClient sharedClient] downloadImageWithURL:previewURL completion:^(UIImage *image) {
                if (image) {
                    [imageCache setObject:image forKey:cellURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                        if (c) c.imageView.image = image;
                    });
                }
            }];
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= videos.count) return;
    NSDictionary *video = [videos objectAtIndex:indexPath.row];
    NSString *ownerId = [[video objectForKey:@"owner_id"] stringValue];
    NSString *videoId = [[video objectForKey:@"id"] stringValue];
    VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
    [self.navigationController pushViewController:playerVC animated:YES];
}

@end