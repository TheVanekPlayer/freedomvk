// FullscreenImageViewController.h
#import <UIKit/UIKit.h>

@interface FullscreenImageViewController : UIViewController
- (instancetype)initWithImage:(UIImage *)image;
- (instancetype)initWithImageURL:(NSString *)imageURL;
@end