// SettingsViewController.m
#import "SettingsViewController.h"
#import "SideMenuViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface SettingsViewController () <UITableViewDelegate, UITableViewDataSource> {
    UITableView *tableView;
    UISwitch *soundSwitch;
    UISwitch *themeSwitch;
    UISwitch *optimizeSwitch;
    UISwitch *autoPlaySwitch;
}
@end

@implementation SettingsViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Настройки";
    UIImage *texture = [UIImage imageNamed:@"linen_soft.png"];
    self.view.backgroundColor = texture ? [UIColor colorWithPatternImage:texture] : [UIColor colorWithWhite:0.92 alpha:1.0];
    
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.backgroundView = nil;
    tableView.separatorColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    [self.view addSubview:tableView];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0: return 1; // Оптимизация
        case 1: return 2; // Звук, Автовоспроизведение
        case 2: return 1; // Тема
        case 3: return 1; // Версия
        default: return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case 0: return @"Производительность";
        case 1: return @"Уведомления и звук";
        case 2: return @"Оформление";
        case 3: return @"О приложении";
        default: return @"";
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return @"Включите это для более быстрой работы клиента (Для слабых устройств)";
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"SettingsCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont systemFontOfSize:15];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    cell.accessoryView = nil;
    cell.textLabel.text = @"";
    
    if (indexPath.section == 0) {
        cell.textLabel.text = @"Режим Оптимизации";
        if (!optimizeSwitch) {
            optimizeSwitch = [[UISwitch alloc] init];
            [optimizeSwitch addTarget:self action:@selector(optimizeChanged) forControlEvents:UIControlEventValueChanged];
        }
        optimizeSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"OptimizeMode"];
        cell.accessoryView = optimizeSwitch;
    } else if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"Звук при отправке";
            if (!soundSwitch) {
                soundSwitch = [[UISwitch alloc] init];
                [soundSwitch addTarget:self action:@selector(soundChanged) forControlEvents:UIControlEventValueChanged];
            }
            soundSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"ChatSoundEnabled"];
            cell.accessoryView = soundSwitch;
        } else {
            cell.textLabel.text = @"Автовоспроизведение";
            if (!autoPlaySwitch) {
                autoPlaySwitch = [[UISwitch alloc] init];
                [autoPlaySwitch addTarget:self action:@selector(autoPlayChanged) forControlEvents:UIControlEventValueChanged];
            }
            autoPlaySwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"AutoPlayEnabled"];
            cell.accessoryView = autoPlaySwitch;
        }
    } else if (indexPath.section == 2) {
        cell.textLabel.text = @"Тёмная тема";
        if (!themeSwitch) {
            themeSwitch = [[UISwitch alloc] init];
            [themeSwitch addTarget:self action:@selector(themeChanged) forControlEvents:UIControlEventValueChanged];
        }
        themeSwitch.on = [ThemeManager isDarkTheme];
        cell.accessoryView = themeSwitch;
    } else {
        cell.textLabel.text = @"";
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UILabel *v1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 6, self.view.bounds.size.width, 18)];
        v1.text = @"Freedom VK by vanchous";
        v1.textAlignment = NSTextAlignmentCenter;
        v1.font = [UIFont boldSystemFontOfSize:13];
        v1.textColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
        v1.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:v1];
        
        UILabel *v2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 26, self.view.bounds.size.width, 16)];
        v2.text = @"Версия 2.3 Freedom for people";
        v2.textAlignment = NSTextAlignmentCenter;
        v2.font = [UIFont systemFontOfSize:11];
        v2.textColor = [UIColor grayColor];
        v2.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:v2];
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 3) return 50;
    return 44;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Handlers

- (void)soundChanged {
    [[NSUserDefaults standardUserDefaults] setBool:soundSwitch.on forKey:@"ChatSoundEnabled"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)autoPlayChanged {
    [[NSUserDefaults standardUserDefaults] setBool:autoPlaySwitch.on forKey:@"AutoPlayEnabled"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)themeChanged {
    [ThemeManager setDarkTheme:themeSwitch.on];
    [tableView reloadData];
    [[NSNotificationCenter defaultCenter] postNotificationName:ThemeDidChangeNotification object:nil];
}

- (void)optimizeChanged {
    [[NSUserDefaults standardUserDefaults] setBool:optimizeSwitch.on forKey:@"OptimizeMode"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *msg = optimizeSwitch.on
    ? @"Режим оптимизации включён. Клиент будет работать быстрее на слабых устройствах."
    : @"Режим оптимизации выключен.";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Режим оптимизации" message:msg delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

@end