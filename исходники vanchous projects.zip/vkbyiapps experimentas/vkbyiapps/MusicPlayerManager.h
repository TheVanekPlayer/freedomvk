// MusicPlayerManager.h
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@protocol MusicPlayerManagerDelegate <NSObject>
@optional
- (void)musicPlayerDidChangeTrack:(NSDictionary *)track;
- (void)musicPlayerDidChangePlayState:(BOOL)isPlaying;
- (void)musicPlayerDidUpdateProgress:(CGFloat)progress
                         currentTime:(NSTimeInterval)currentTime
                            duration:(NSTimeInterval)duration;
@end

@interface MusicPlayerManager : NSObject <AVAudioPlayerDelegate>

+ (instancetype)sharedManager;

@property (nonatomic, unsafe_unretained) id<MusicPlayerManagerDelegate> delegate;
@property (nonatomic, strong) NSArray *playlist;
@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, assign, readonly) BOOL isPlaying;
@property (nonatomic, strong, readonly) NSDictionary *currentTrack;
@property (nonatomic, assign, readonly) NSTimeInterval currentTime;
@property (nonatomic, assign, readonly) NSTimeInterval duration;

- (void)playTrackAtIndex:(NSInteger)index playlist:(NSArray *)playlist;
- (void)togglePlayPause;
- (void)nextTrack;
- (void)previousTrack;
- (void)stop;
- (void)seekToProgress:(CGFloat)progress;   // 0.0 ... 1.0

@end