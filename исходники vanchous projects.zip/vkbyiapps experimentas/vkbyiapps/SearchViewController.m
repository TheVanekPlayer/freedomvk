// SearchViewController.m
#import "SearchViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "ProfileViewController.h"
#import "GroupWallViewController.h"
#import "PostDetailViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface SearchViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate> {
    NSOperationQueue *searchQueue;
    NSURLConnection *currentConnection;
}
@property (nonatomic, strong) UITextField *searchField;
@property (nonatomic, strong) UIButton *searchButton;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *results;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) UISegmentedControl *typeSegmented;
@property (nonatomic, strong) NSMutableDictionary *avatarCache;
@end

@implementation SearchViewController

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [ThemeManager backgroundColor];
    self.title = @"Поиск";
    self.avatarCache = [NSMutableDictionary dictionary];
    searchQueue = [[NSOperationQueue alloc] init];
    searchQueue.maxConcurrentOperationCount = 1;
    
    self.searchField = [[UITextField alloc] initWithFrame:CGRectMake(10, 10, self.view.bounds.size.width - 80, 40)];
    self.searchField.placeholder = @"Введите запрос (минимум 2 символа)";
    self.searchField.borderStyle = UITextBorderStyleRoundedRect;
    self.searchField.delegate = self;
    self.searchField.returnKeyType = UIReturnKeySearch;
    self.searchField.font = [UIFont systemFontOfSize:15];
    self.searchField.backgroundColor = [UIColor whiteColor];
    self.searchField.layer.cornerRadius = 8.0;
    self.searchField.layer.borderWidth = 0.5;
    self.searchField.layer.borderColor = [UIColor colorWithWhite:0.8 alpha:1.0].CGColor;
    [self.view addSubview:self.searchField];
    
    self.searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.searchButton.frame = CGRectMake(self.view.bounds.size.width - 65, 10, 55, 40);
    [self.searchButton setTitle:@"Искать" forState:UIControlStateNormal];
    [self.searchButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.searchButton.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    self.searchButton.backgroundColor = [ThemeManager navigationBarTintColor];
    self.searchButton.layer.cornerRadius = 8.0;
    [self.searchButton addTarget:self action:@selector(performSearch) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.searchButton];
    
    NSArray *items = @[@"Люди", @"Группы", @"Посты", @"Всё"];
    self.typeSegmented = [[UISegmentedControl alloc] initWithItems:items];
    self.typeSegmented.frame = CGRectMake(10, 55, self.view.bounds.size.width - 20, 30);
    self.typeSegmented.selectedSegmentIndex = 0;
    self.typeSegmented.tintColor = [ThemeManager navigationBarTintColor];
    [self.typeSegmented addTarget:self action:@selector(searchTypeChanged:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:self.typeSegmented];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 95, self.view.bounds.size.width, self.view.bounds.size.height - 95)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.rowHeight = 60;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorColor = [ThemeManager separatorColor];
    [self.view addSubview:self.tableView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(resignSearch)];
    tap.cancelsTouchesInView = NO;
    [self.tableView addGestureRecognizer:tap];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)resignSearch {
    [self.searchField resignFirstResponder];
}

- (void)searchTypeChanged:(UISegmentedControl *)sender {
    if (self.searchField.text.length >= 2) {
        [self performSearch];
    }
}

#pragma mark - Поиск

- (void)performSearch {
    [self.searchField resignFirstResponder];
    NSString *query = [self.searchField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (query.length < 2) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Введите минимум 2 символа" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    [searchQueue cancelAllOperations];
    if (currentConnection) {
        [currentConnection cancel];
        currentConnection = nil;
    }
    
    [self.spinner startAnimating];
    self.results = nil;
    [self.tableView reloadData];
    
    __weak typeof(self) weakSelf = self;
    NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
        if (operation.isCancelled) return;
        NSInteger type = weakSelf.typeSegmented.selectedSegmentIndex;
        if (type == 0) {
            [[VKAPIClient sharedClient] searchUsersWithQuery:query completion:^(NSArray *users, NSError *error) {
                if (operation.isCancelled) return;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf handleSearchResults:users error:error];
                });
            }];
        } else if (type == 1) {
            [[VKAPIClient sharedClient] searchGroupsWithQuery:query completion:^(NSArray *groups, NSError *error) {
                if (operation.isCancelled) return;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf handleSearchResults:groups error:error];
                });
            }];
        } else {
            [[VKAPIClient sharedClient] searchNewsfeedWithQuery:query completion:^(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error) {
                if (operation.isCancelled) return;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf handleSearchResults:items error:error];
                });
            }];
        }
    }];
    [searchQueue addOperation:operation];
}

- (void)handleSearchResults:(NSArray *)results error:(NSError *)error {
    [self.spinner stopAnimating];
    if (error) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        return;
    }
    self.results = results ?: @[];
    [self.tableView reloadData];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self performSearch];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if (newText.length >= 2) {
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(performSearch) object:nil];
        [self performSelector:@selector(performSearch) withObject:nil afterDelay:0.5];
    }
    return YES;
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.results.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"SearchCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    UIImageView *avatarView;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        
        avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 44, 44)];
        avatarView.tag = 900;
        avatarView.contentMode = UIViewContentModeScaleAspectFill;
        avatarView.clipsToBounds = YES;
        avatarView.layer.cornerRadius = 4;
        avatarView.layer.borderWidth = 1;
        avatarView.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
        avatarView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        [cell.contentView addSubview:avatarView];
        
        cell.textLabel.font = [UIFont systemFontOfSize:15];
        cell.textLabel.textColor = [ThemeManager cellTextColor];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        
        cell.indentationWidth = 60;
        cell.indentationLevel = 1;
    } else {
        avatarView = (UIImageView *)[cell.contentView viewWithTag:900];
    }
    
    avatarView.image = [UIImage imageNamed:@"default_avatar"];
    cell.textLabel.text = @"";
    cell.detailTextLabel.text = @"";
    
    if (indexPath.row >= self.results.count) return cell;
    NSDictionary *item = self.results[indexPath.row];
    NSInteger type = self.typeSegmented.selectedSegmentIndex;
    NSString *avatarURL = nil;
    
    if (type == 0) {
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", item[@"first_name"] ?: @"", item[@"last_name"] ?: @""];
        cell.detailTextLabel.text = @"Пользователь";
        avatarURL = item[@"photo_50"] ?: item[@"photo_100"];
    } else if (type == 1) {
        cell.textLabel.text = item[@"name"] ?: @"Без названия";
        cell.detailTextLabel.text = @"Группа";
        avatarURL = item[@"photo_50"];
    } else {
        NSString *text = item[@"text"] ?: @"[Пост]";
        if (text.length > 80) text = [[text substringToIndex:80] stringByAppendingString:@"..."];
        cell.textLabel.text = text;
        cell.detailTextLabel.text = @"Пост";
    }
    
    if ([avatarURL isKindOfClass:[NSString class]] && avatarURL.length > 0) {
        UIImage *cached = self.avatarCache[avatarURL];
        if (cached) {
            avatarView.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    self.avatarCache[avatarURL] = image;
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *currentCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (currentCell) {
                            UIImageView *iv = (UIImageView *)[currentCell.contentView viewWithTag:900];
                            if (iv) iv.image = image;
                        }
                    });
                }
            }];
        }
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= self.results.count) return;
    NSDictionary *item = self.results[indexPath.row];
    NSInteger type = self.typeSegmented.selectedSegmentIndex;
    
    if (type == 0) {
        ProfileViewController *profileVC = [[ProfileViewController alloc] initWithUserId:[item[@"id"] stringValue]];
        profileVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:profileVC animated:YES];
    } else if (type == 1) {
        GroupWallViewController *wallVC = [[GroupWallViewController alloc] initWithGroupId:[NSString stringWithFormat:@"-%@", item[@"id"]] name:item[@"name"] avatarURL:item[@"photo_50"]];
        wallVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:wallVC animated:YES];
    } else {
        PostDetailViewController *detailVC = [[PostDetailViewController alloc] initWithPost:item];
        detailVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:detailVC animated:YES];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.searchField resignFirstResponder];
}

@end