// GroupsViewController.m
#import "GroupsViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "GroupWallViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface GroupsViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *groups;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSMutableDictionary *avatarCache;
@end

@implementation GroupsViewController

- (void)loadView {
    [super loadView];
    self.title = @"Группы";
    self.view.backgroundColor = [UIColor colorWithWhite:0.88 alpha:1.0];
    self.avatarCache = [NSMutableDictionary dictionary];
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    [self.view addSubview:self.tableView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    [self loadGroups];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadGroups {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] getGroupsWithCompletion:^(NSArray *groups, NSError *error) {
        [self.spinner stopAnimating];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        self.groups = groups ?: @[];
        [self.tableView reloadData];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.groups.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"GroupCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:16];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = 0;
        cell.imageView.frame = CGRectMake(0,0,40,40);
    }
    NSDictionary *group = self.groups[indexPath.row];
    cell.textLabel.text = group[@"name"] ?: @"Без названия";
    cell.detailTextLabel.text = group[@"type"];
    NSString *avatarURL = group[@"photo_50"];
    if (avatarURL) {
        UIImage *cached = self.avatarCache[avatarURL];
        if (cached) cell.imageView.image = cached;
        else {
            cell.imageView.image = [UIImage imageNamed:@"default_group"];
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    self.avatarCache[avatarURL] = image;
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) updateCell.imageView.image = image;
                    });
                }
            }];
        }
    } else {
        cell.imageView.image = [UIImage imageNamed:@"default_group"];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 54.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *group = self.groups[indexPath.row];
    NSInteger gid = [group[@"id"] integerValue];
    NSString *ownerId = [NSString stringWithFormat:@"-%ld", (long)gid];
    NSString *name = group[@"name"];
    NSString *avatarURL = group[@"photo_50"];
    GroupWallViewController *wallVC = [[GroupWallViewController alloc] initWithGroupId:ownerId name:name avatarURL:avatarURL];
    wallVC.sideMenuController = self.sideMenuController;
    [self.navigationController pushViewController:wallVC animated:YES];
}

@end