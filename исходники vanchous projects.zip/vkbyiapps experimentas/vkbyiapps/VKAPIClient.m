// VKAPIClient.m
#import "VKAPIClient.h"
#import <CFNetwork/CFNetwork.h>

static NSString * const kOpenVKAPIVersion = @"5.131";
static NSString * const kOpenVKBaseURL = @"https://api.openvk.org/method/";
static NSString * const kOpenVKTokenURL = @"https://api.openvk.org/token";

static NSOperationQueue *gNetworkQueue = nil;
static NSOperationQueue *gImageQueue = nil;

@interface VKAPIClient ()
@property (strong, nonatomic) NSURLCache *urlCache;
@end

@implementation VKAPIClient

#pragma mark - Singleton

+ (instancetype)sharedClient {
    static VKAPIClient *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _urlCache = [[NSURLCache alloc] initWithMemoryCapacity:20 * 1024 * 1024
                                                  diskCapacity:100 * 1024 * 1024
                                                      diskPath:@"OpenVKCache"];
        [NSURLCache setSharedURLCache:_urlCache];
        
        gNetworkQueue = [[NSOperationQueue alloc] init];
        gNetworkQueue.maxConcurrentOperationCount = 4;
        gNetworkQueue.name = @"OpenVKNetwork";
        
        gImageQueue = [[NSOperationQueue alloc] init];
        gImageQueue.maxConcurrentOperationCount = 3;
        gImageQueue.name = @"OpenVKImages";
    }
    return self;
}

- (NSString *)baseURLString { return kOpenVKBaseURL; }
- (NSString *)tokenURLString { return kOpenVKTokenURL; }
- (BOOL)useProxy { return NO; }

#pragma mark - Базовые сетевые методы

- (NSDictionary *)performSyncGET:(NSString *)urlString error:(NSError **)error {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) {
        if (error) *error = [NSError errorWithDomain:@"OpenVK" code:-3 userInfo:@{NSLocalizedDescriptionKey: @"Неверный URL"}];
        return nil;
    }
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url
                                                       cachePolicy:NSURLRequestReturnCacheDataElseLoad
                                                   timeoutInterval:20.0];
    [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
    [req setValue:@"https://openvk.org/" forHTTPHeaderField:@"Referer"];
    
    NSHTTPURLResponse *resp = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:req returningResponse:&resp error:error];
    if (!data) return nil;
    
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:error];
    if (json) json = [VKAPIClient normalizeResponse:json];
    if ([json isKindOfClass:[NSDictionary class]]) return json;
    return nil;
}

- (void)performAsyncGET:(NSString *)urlString completion:(void(^)(NSData *data, NSError *error))completion {
    if (!urlString || !completion) return;
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) { completion(nil, nil); return; }
    
    [gNetworkQueue addOperationWithBlock:^{
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url
                                                           cachePolicy:NSURLRequestReturnCacheDataElseLoad
                                                       timeoutInterval:20.0];
        [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
        [req setValue:@"https://openvk.org/" forHTTPHeaderField:@"Referer"];
        
        NSHTTPURLResponse *resp = nil;
        NSError *err = nil;
        NSData *data = [NSURLConnection sendSynchronousRequest:req returningResponse:&resp error:&err];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(data, err);
        });
    }];
}

#pragma mark - Авторизация

- (void)authenticateWithUsername:(NSString *)username
                        password:(NSString *)password
                      completion:(void(^)(BOOL success, NSString *token, NSString *userId, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *urlString = [NSString stringWithFormat:@"%@?username=%@&password=%@&grant_type=password",
                               kOpenVKTokenURL,
                               [username stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],
                               [password stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        NSURL *url = [NSURL URLWithString:urlString];
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url
                                                           cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                       timeoutInterval:30.0];
        [req setHTTPMethod:@"POST"];
        [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
        NSHTTPURLResponse *resp = nil;
        NSError *error = nil;
        NSData *data = [NSURLConnection sendSynchronousRequest:req returningResponse:&resp error:&error];
        if (!data || error) {
            dispatch_async(dispatch_get_main_queue(), ^{ completion(NO, nil, nil, error); });
            return;
        }
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        if (![json isKindOfClass:[NSDictionary class]]) {
            dispatch_async(dispatch_get_main_queue(), ^{ completion(NO, nil, nil, nil); });
            return;
        }
        NSString *token = json[@"access_token"];
        NSString *uid = [json[@"user_id"] stringValue];
        if (token && uid) {
            dispatch_async(dispatch_get_main_queue(), ^{ completion(YES, token, uid, nil); });
        } else {
            NSString *errMsg = json[@"error_description"] ?: json[@"error_msg"] ?: @"Неверный логин или пароль";
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, nil, nil, [NSError errorWithDomain:@"OpenVK" code:-1 userInfo:@{NSLocalizedDescriptionKey: errMsg}]);
            });
        }
    });
}

- (void)validateToken:(NSString *)token completion:(void(^)(BOOL valid, NSString *userId, NSString *errorMessage))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *urlString = [NSString stringWithFormat:@"%@users.get?access_token=%@&v=%@", kOpenVKBaseURL, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) { completion(NO, nil, error.localizedDescription); return; }
            if (json[@"error"]) { completion(NO, nil, json[@"error"][@"error_msg"]); return; }
            NSArray *users = json[@"response"];
            if ([users isKindOfClass:[NSArray class]] && users.count > 0) {
                completion(YES, [users[0][@"id"] stringValue], nil);
            } else {
                completion(NO, nil, @"Не удалось получить данные пользователя");
            }
        });
    });
}

#pragma mark - Пользователи по ID

- (void)getUsersByIds:(NSArray *)userIds completion:(void(^)(NSDictionary *usersById, NSError *error))completion {
    if (![userIds isKindOfClass:[NSArray class]] || userIds.count == 0) {
        dispatch_async(dispatch_get_main_queue(), ^{ completion(@{}, nil); });
        return;
    }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{ completion(@{}, nil); });
            return;
        }
        NSMutableDictionary *allUsers = [NSMutableDictionary dictionary];
        NSInteger batchSize = 100;
        NSInteger total = userIds.count;
        for (NSInteger i = 0; i < total; i += batchSize) {
            NSInteger count = MIN(batchSize, total - i);
            NSArray *batch = [userIds subarrayWithRange:NSMakeRange(i, count)];
            NSString *ids = [batch componentsJoinedByString:@","];
            NSString *urlString = [NSString stringWithFormat:
                                   @"%@users.get?user_ids=%@&fields=photo_50,photo_100,photo_200,online,last_seen&access_token=%@&v=5.131",
                                   kOpenVKBaseURL, ids, token];
            NSError *error = nil;
            NSDictionary *json = [self performSyncGET:urlString error:&error];
            NSArray *users = json[@"response"];
            if ([users isKindOfClass:[NSArray class]]) {
                for (NSDictionary *u in users) {
                    if (![u isKindOfClass:[NSDictionary class]]) continue;
                    id uid = [u objectForKey:@"id"];
                    if (uid) {
                        NSString *key = [uid stringValue];
                        [allUsers setObject:u forKey:key];
                    }
                }
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            completion([allUsers copy], nil);
        });
    });
}

#pragma mark - Новости

- (void)getNewsfeedWithCompletion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion {
    [self getNewsfeedWithOffset:0 count:20 completion:completion];
}

- (void)getNewsfeedWithOffset:(NSInteger)offset count:(NSInteger)count completion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion {
    [self getNewsfeedWithFilter:@"post" offset:offset count:count completion:completion];
}

- (void)getNewsfeedWithFilter:(NSString *)filter offset:(NSInteger)offset count:(NSInteger)count completion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) { dispatch_async(dispatch_get_main_queue(), ^{ completion(@[], @[], @[], nil); }); return; }
        
        NSString *filtersParam;
        if ([filter rangeOfString:@"="].location != NSNotFound) {
            filtersParam = filter;
        } else {
            filtersParam = [NSString stringWithFormat:@"filters=%@", filter ?: @"post"];
        }
        
        NSString *urlString = [NSString stringWithFormat:
                               @"%@newsfeed.get?%@&count=%ld&fields=photo_50,photo_100,photo_200&access_token=%@&v=%@",
                               kOpenVKBaseURL, filtersParam, (long)count, token, kOpenVKAPIVersion];
        
        NSLog(@"📰 [Feed] GET %@", urlString);
        
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) {
                NSLog(@"📰 [Feed] Ошибка: %@ / %@", error, json[@"error"]);
                completion(@[], @[], @[], error);
                return;
            }
            NSDictionary *resp = json[@"response"];
            if (![resp isKindOfClass:[NSDictionary class]]) { completion(@[], @[], @[], nil); return; }
            id items = resp[@"items"]; if (![items isKindOfClass:[NSArray class]]) items = @[];
            id profiles = resp[@"profiles"]; if (![profiles isKindOfClass:[NSArray class]]) profiles = @[];
            id groups = resp[@"groups"]; if (![groups isKindOfClass:[NSArray class]]) groups = @[];
            NSLog(@"📰 [Feed] Получено %lu постов", (unsigned long)[items count]);
            completion(items, profiles, groups, nil);
        });
    });
}

- (void)searchNewsfeedWithQuery:(NSString *)query completion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *q = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@newsfeed.search?q=%@&count=20&access_token=%@&v=%@", kOpenVKBaseURL, q, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) { completion(@[], @[], @[], error); return; }
            NSDictionary *resp = json[@"response"];
            if (![resp isKindOfClass:[NSDictionary class]]) { completion(@[], @[], @[], nil); return; }
            id items = resp[@"items"]; if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, resp[@"profiles"] ?: @[], resp[@"groups"] ?: @[], nil);
        });
    });
}

#pragma mark - Друзья

- (void)getFriendsWithCompletion:(void(^)(NSArray *friends, NSError *error))completion {
    [self getFriendsWithFields:@"photo_50,photo_100,online" completion:completion];
}

- (void)getFriendsWithFields:(NSString *)fields completion:(void(^)(NSArray *friends, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@friends.get?fields=%@&access_token=%@&v=%@", kOpenVKBaseURL, fields, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = json[@"response"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

- (void)followUser:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@friends.add?user_id=%@&access_token=%@&v=%@", kOpenVKBaseURL, userId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

- (void)unfollowUser:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@friends.delete?user_id=%@&access_token=%@&v=%@", kOpenVKBaseURL, userId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

- (void)getFriendRequestsWithCompletion:(void(^)(NSArray *requests, NSArray *profiles, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{ completion(@[], @[], nil); });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:
                               @"%@friends.getRequests?fields=photo_50,photo_100,online&extended=1&count=100&access_token=%@&v=5.131",
                               kOpenVKBaseURL, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || ![json isKindOfClass:[NSDictionary class]] || json[@"error"]) {
                completion(@[], @[], error);
                return;
            }
            NSDictionary *resp = json[@"response"];
            id items = resp[@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = resp;
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            
            NSArray *profilesArray = resp[@"profiles"];
            if (![profilesArray isKindOfClass:[NSArray class]]) profilesArray = @[];
            
            completion(items, profilesArray, nil);
        });
    });
}

- (void)acceptFriendRequest:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion {
    [self followUser:userId completion:completion];
}

- (void)declineFriendRequest:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion {
    [self unfollowUser:userId completion:completion];
}

#pragma mark - Группы

- (void)getGroupsWithCompletion:(void(^)(NSArray *groups, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *uid = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
        NSString *urlString = [NSString stringWithFormat:
                               @"%@groups.get?user_id=%@&extended=1&fields=photo_50,photo_100,photo_200&access_token=%@&v=%@",
                               kOpenVKBaseURL, uid, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

- (void)getGroupById:(NSString *)groupId completion:(void(^)(NSDictionary *group, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *gId = groupId;
        if ([gId hasPrefix:@"-"]) gId = [gId substringFromIndex:1];
        NSString *urlString = [NSString stringWithFormat:
                               @"%@groups.getById?group_id=%@&fields=photo_50,photo_100,photo_200,members_count,status,description,is_member,type,counters&access_token=%@&v=%@",
                               kOpenVKBaseURL, gId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(nil, error); return; }
            NSArray *groups = json[@"response"];
            completion(([groups isKindOfClass:[NSArray class]] && groups.count > 0) ? groups[0] : nil, nil);
        });
    });
}

- (void)joinGroup:(NSString *)groupId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSCharacterSet *nonDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        NSString *cleanId = [[groupId componentsSeparatedByCharactersInSet:nonDigits] componentsJoinedByString:@""];
        NSString *urlString = [NSString stringWithFormat:@"%@groups.join?group_id=%@&access_token=%@&v=%@", kOpenVKBaseURL, cleanId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

- (void)leaveGroup:(NSString *)groupId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSCharacterSet *nonDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        NSString *cleanId = [[groupId componentsSeparatedByCharactersInSet:nonDigits] componentsJoinedByString:@""];
        NSString *urlString = [NSString stringWithFormat:@"%@groups.leave?group_id=%@&access_token=%@&v=%@", kOpenVKBaseURL, cleanId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

- (void)getLastPostForGroupId:(NSString *)groupId completion:(void(^)(NSDictionary *post, NSError *error))completion {
    if (!groupId) { dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); }); return; }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *gId = groupId;
        if ([gId hasPrefix:@"-"]) gId = [gId substringFromIndex:1];
        NSString *urlString = [NSString stringWithFormat:@"%@wall.get?owner_id=-%@&count=1&access_token=%@&v=%@", kOpenVKBaseURL, gId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(nil, error); return; }
            NSArray *items = json[@"response"][@"items"];
            completion(([items isKindOfClass:[NSArray class]] && items.count > 0) ? items[0] : nil, nil);
        });
    });
}

#pragma mark - Сообщения

- (void)getConversationsWithCompletion:(void(^)(NSArray *conversations, NSDictionary *profiles, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{ completion(@[], @{}, nil); });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:
                               @"%@messages.getConversations?count=20&extended=1&fields=photo_50,photo_100,photo_200,online&access_token=%@&v=5.131",
                               kOpenVKBaseURL, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || ![json isKindOfClass:[NSDictionary class]] || json[@"error"]) {
                completion(@[], @{}, error);
                return;
            }
            NSDictionary *response = json[@"response"];
            if (![response isKindOfClass:[NSDictionary class]]) { completion(@[], @{}, nil); return; }
            
            id items = response[@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            
            id profilesArray = response[@"profiles"];
            if (![profilesArray isKindOfClass:[NSArray class]]) profilesArray = @[];
            
            id groupsArray = response[@"groups"];
            if (![groupsArray isKindOfClass:[NSArray class]]) groupsArray = @[];
            
            NSMutableDictionary *profDict = [NSMutableDictionary dictionary];
            for (id p in profilesArray) {
                if (![p isKindOfClass:[NSDictionary class]]) continue;
                id uid = [p objectForKey:@"id"];
                if (uid) [profDict setObject:p forKey:[uid stringValue]];
            }
            for (id g in groupsArray) {
                if (![g isKindOfClass:[NSDictionary class]]) continue;
                id gid = [g objectForKey:@"id"];
                if (gid) {
                    NSString *key = [NSString stringWithFormat:@"-%@", [gid stringValue]];
                    [profDict setObject:g forKey:key];
                }
            }
            
            completion(items, profDict, nil);
        });
    });
}

- (void)getMessageHistoryForPeerId:(NSString *)peerId completion:(void(^)(NSArray *messages, NSError *error))completion {
    [self getMessageHistoryForPeerId:peerId offset:0 count:30 completion:completion];
}

- (void)getMessageHistoryForPeerId:(NSString *)peerId offset:(NSInteger)offset count:(NSInteger)count completion:(void(^)(NSArray *messages, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.getHistory?peer_id=%@&offset=%ld&count=%ld&access_token=%@&v=%@",
                               kOpenVKBaseURL, peerId, (long)offset, (long)count, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            NSArray *items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion([[items reverseObjectEnumerator] allObjects], nil);
        });
    });
}

- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    [self sendMessage:message toPeerId:peerId attachment:nil stickerId:nil completion:completion];
}

- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId attachment:(NSString *)attachment stickerId:(NSString *)stickerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSInteger randomId = arc4random_uniform(9999999);
        NSMutableString *urlString = [NSMutableString stringWithFormat:@"%@messages.send?peer_id=%@&random_id=%ld&access_token=%@&v=%@",
                                      kOpenVKBaseURL, peerId, (long)randomId, token, kOpenVKAPIVersion];
        if (message.length > 0) {
            [urlString appendFormat:@"&message=%@", [message stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        }
        if (attachment.length > 0) [urlString appendFormat:@"&attachment=%@", attachment];
        if (stickerId.length > 0) [urlString appendFormat:@"&sticker_id=%@", stickerId];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            completion((!error && !json[@"error"]), error);
        });
    });
}

- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId replyTo:(NSNumber *)replyTo completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSInteger randomId = arc4random_uniform(9999999);
        NSString *msg = [message stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.send?peer_id=%@&random_id=%ld&message=%@&reply_to=%@&access_token=%@&v=%@",
                               kOpenVKBaseURL, peerId, (long)randomId, msg, replyTo, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

- (void)editMessage:(NSString *)newText forMessageId:(NSNumber *)messageId peerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *txt = [newText stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.edit?peer_id=%@&message_id=%@&message=%@&access_token=%@&v=%@",
                               kOpenVKBaseURL, peerId, messageId, txt, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

- (void)deleteMessage:(NSNumber *)messageId forPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.delete?message_ids=%@&delete_for_all=1&access_token=%@&v=%@",
                               kOpenVKBaseURL, messageId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            completion((!error && !json[@"error"]), error);
        });
    });
}

- (void)markMessagesAsReadWithPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.markAsRead?peer_id=%@&access_token=%@&v=%@", kOpenVKBaseURL, peerId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion(!error, error); });
    });
}

- (void)searchMessagesWithQuery:(NSString *)query peerId:(NSString *)peerId completion:(void(^)(NSArray *messages, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *q = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.search?q=%@&peer_id=%@&count=50&access_token=%@&v=%@",
                               kOpenVKBaseURL, q, peerId ?: @"", token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

#pragma mark - Загрузка медиа (заглушки)

- (void)uploadPhotoForMessage:(UIImage *)photo completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{
        completion(nil, [NSError errorWithDomain:@"VK" code:-99
                                        userInfo:@{NSLocalizedDescriptionKey: @"Загрузка фото не поддерживается"}]);
    });
}

- (void)uploadPhotoForWall:(UIImage *)photo completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{
        completion(nil, [NSError errorWithDomain:@"VK" code:-99
                                        userInfo:@{NSLocalizedDescriptionKey: @"Загрузка фото не поддерживается"}]);
    });
}

- (void)uploadVideoForMessage:(NSURL *)videoURL completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); });
}

- (void)uploadVideoForWall:(NSURL *)videoURL completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); });
}

- (void)uploadAudioFile:(NSURL *)fileURL completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); });
}

- (void)uploadDocument:(NSURL *)fileURL completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); });
}

#pragma mark - Документы

- (void)getDocumentsWithCompletion:(void(^)(NSArray *docs, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(@[], nil); });
}

- (void)deleteDocument:(NSString *)docId ownerId:(NSString *)ownerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(NO, nil); });
}

#pragma mark - Стикеры

- (void)getStickerImageWithId:(NSString *)stickerId completion:(void(^)(UIImage *image, NSError *error))completion {
    if (!stickerId) { dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); }); return; }
    NSArray *urls = @[
                      [NSString stringWithFormat:@"https://api.openvk.org/sticker/%@/512.png", stickerId],
                      [NSString stringWithFormat:@"https://api.openvk.org/sticker/%@/256.png", stickerId],
                      [NSString stringWithFormat:@"https://api.openvk.org/sticker/%@/128.png", stickerId]
                      ];
    [self tryLoadStickerURLs:urls index:0 completion:completion];
}

- (void)tryLoadStickerURLs:(NSArray *)urls index:(NSInteger)index completion:(void(^)(UIImage *image, NSError *error))completion {
    if (index >= urls.count) { dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); }); return; }
    [self downloadImageWithURL:urls[index] completion:^(UIImage *image) {
        if (image) dispatch_async(dispatch_get_main_queue(), ^{ completion(image, nil); });
        else [self tryLoadStickerURLs:urls index:index+1 completion:completion];
    }];
}

- (void)getStickerPacksWithCompletion:(void(^)(NSArray *packs, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(@[], nil); });
}

- (void)getStickersForPackId:(NSInteger)packId completion:(void(^)(NSArray *stickers, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(@[], nil); });
}

- (void)sendSticker:(NSString *)stickerId toPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    [self sendMessage:@"" toPeerId:peerId attachment:nil stickerId:stickerId completion:completion];
}

#pragma mark - Профиль

- (void)profileGetInfoWithUserId:(NSString *)userId completion:(void(^)(NSDictionary *userInfo, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:
                               @"%@users.get?user_ids=%@&fields=photo_50,photo_100,photo_200,status,bdate,online,last_seen,city,counters,friend_status,site,mobile_phone,home_phone,skype,instagram,twitter,facebook&access_token=%@&v=%@",
                               kOpenVKBaseURL, userId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(nil, error); return; }
            NSArray *users = json[@"response"];
            completion(([users isKindOfClass:[NSArray class]] && users.count > 0) ? users[0] : nil, nil);
        });
    });
}

- (void)getFullProfileInfo:(NSString *)userId completion:(void(^)(NSDictionary *userInfo, NSError *error))completion {
    [self profileGetInfoWithUserId:userId completion:completion];
}

- (void)getCurrentUserInfoWithCompletion:(void(^)(NSDictionary *userInfo, NSError *error))completion {
    NSString *uid = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    if (uid) [self profileGetInfoWithUserId:uid completion:completion];
    else dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, nil); });
}

#pragma mark - Стена

- (void)getWallPostsWithOwnerId:(NSString *)ownerId completion:(void(^)(NSArray *posts, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@wall.get?owner_id=%@&count=30&access_token=%@&v=%@",
                               kOpenVKBaseURL, ownerId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

- (void)wallPost:(NSString *)text ownerId:(NSString *)ownerId attachment:(NSString *)attachment completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *txt = [text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ?: @"";
        NSMutableString *urlString = [NSMutableString stringWithFormat:@"%@wall.post?owner_id=%@&message=%@&access_token=%@&v=%@",
                                      kOpenVKBaseURL, ownerId, txt, token, kOpenVKAPIVersion];
        if (attachment.length > 0) [urlString appendFormat:@"&attachments=%@", attachment];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

#pragma mark - Лайки

- (void)addLikeForOwnerId:(NSString *)ownerId itemId:(NSString *)itemId type:(NSString *)type completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@likes.add?type=%@&owner_id=%@&item_id=%@&access_token=%@&v=%@",
                               kOpenVKBaseURL, type, ownerId, itemId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

#pragma mark - Комментарии

- (void)createComment:(NSString *)text forOwnerId:(NSString *)ownerId postId:(NSString *)postId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *txt = [text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@wall.createComment?owner_id=%@&post_id=%@&message=%@&access_token=%@&v=%@",
                               kOpenVKBaseURL, ownerId, postId, txt, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{ completion((!error && !json[@"error"]), error); });
    });
}

- (void)getCommentsForPostWithOwnerId:(NSString *)ownerId postId:(NSString *)postId completion:(void(^)(NSArray *comments, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@wall.getComments?owner_id=%@&post_id=%@&count=50&extended=1&fields=photo_50,photo_100&access_token=%@&v=%@",
                               kOpenVKBaseURL, ownerId, postId, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

#pragma mark - Фотоальбомы

- (void)getPhotoAlbumsWithCompletion:(void(^)(NSArray *albums, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *uid = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
        NSString *urlString = [NSString stringWithFormat:@"%@photos.getAlbums?owner_id=%@&need_system=1&access_token=%@&v=%@",
                               kOpenVKBaseURL, uid, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = json[@"response"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

#pragma mark - Поиск

- (void)searchUsersWithQuery:(NSString *)query completion:(void(^)(NSArray *users, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *q = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@users.search?q=%@&count=50&fields=photo_50,photo_100&access_token=%@&v=%@",
                               kOpenVKBaseURL, q, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

- (void)searchGroupsWithQuery:(NSString *)query completion:(void(^)(NSArray *groups, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *q = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@groups.search?q=%@&count=50&fields=photo_50,photo_100&access_token=%@&v=%@",
                               kOpenVKBaseURL, q, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

#pragma mark - Аудио

- (void)getAudioWithCompletion:(void(^)(NSArray *audios, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *uid = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
        NSString *urlString = [NSString stringWithFormat:@"%@audio.get?owner_id=%@&count=100&access_token=%@&v=%@",
                               kOpenVKBaseURL, uid, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (!items) items = json[@"response"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

- (void)searchAudioWithQuery:(NSString *)query completion:(void(^)(NSArray *audios, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *q = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@audio.search?q=%@&count=50&access_token=%@&v=%@",
                               kOpenVKBaseURL, q, token, kOpenVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || json[@"error"]) { completion(@[], error); return; }
            id items = json[@"response"][@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            completion(items, nil);
        });
    });
}

- (void)addAudioWithId:(NSString *)audioId ownerId:(NSString *)ownerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@audio.add?audio_id=%@&owner_id=%@&access_token=%@&v=%@",
                               kOpenVKBaseURL, audioId, ownerId, token, kOpenVKAPIVersion];
        NSLog(@"🎵 [Audio] audio.add %@_%@", ownerId, audioId);
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        if (json[@"error"]) {
            NSLog(@"🎵 [Audio] ошибка: %@", json[@"error"]);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            completion((!error && !json[@"error"]), error);
        });
    });
}

#pragma mark - Push

- (void)registerDeviceWithToken:(NSString *)deviceToken completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(YES, nil); });
}

- (void)unregisterDeviceWithCompletion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(YES, nil); });
}

#pragma mark - Long Poll

- (void)startLongPollWithCompletion:(void(^)(NSDictionary *event))eventHandler {}
- (void)stopLongPoll {}

#pragma mark - Изображения

- (void)downloadImageWithURL:(NSString *)imageURL completion:(void(^)(UIImage *image))completion {
    if (!imageURL || !completion) { if (completion) completion(nil); return; }
    if (![imageURL isKindOfClass:[NSString class]]) { completion(nil); return; }
    
    BOOL optimize = [[NSUserDefaults standardUserDefaults] boolForKey:@"OptimizeMode"];
    
    static NSCache *imageCache = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        imageCache = [[NSCache alloc] init];
        [imageCache setCountLimit:optimize ? 50 : 300];
        [imageCache setTotalCostLimit:50 * 1024 * 1024];
    });
    UIImage *cached = [imageCache objectForKey:imageURL];
    if (cached) { completion(cached); return; }
    
    [gImageQueue addOperationWithBlock:^{
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:imageURL]
                                                           cachePolicy:NSURLRequestReturnCacheDataElseLoad
                                                       timeoutInterval:15.0];
        [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
        [req setValue:@"https://openvk.org/" forHTTPHeaderField:@"Referer"];
        
        NSHTTPURLResponse *resp = nil;
        NSError *error = nil;
        NSData *data = [NSURLConnection sendSynchronousRequest:req returningResponse:&resp error:&error];
        
        UIImage *image = nil;
        if (data && !error) {
            image = [UIImage imageWithData:data];
            if (image && optimize && image.size.width > 512) {
                CGFloat ratio = 512.0 / image.size.width;
                CGSize newSize = CGSizeMake(512, image.size.height * ratio);
                UIGraphicsBeginImageContextWithOptions(newSize, NO, 1.0);
                [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
                image = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }
        }
        
        if (image) {
            [imageCache setObject:image forKey:imageURL cost:data.length];
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(image);
        });
    }];
}

- (void)clearVideoPreviewCache {
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

#pragma mark - Нормализация ответов

+ (id)normalizeResponse:(id)value {
    if (!value || value == [NSNull null]) return nil;
    if ([value isKindOfClass:[NSArray class]]) {
        NSMutableArray *array = [NSMutableArray array];
        for (id item in value) {
            id normalized = [self normalizeResponse:item];
            if (normalized) [array addObject:normalized];
        }
        return array;
    }
    if (![value isKindOfClass:[NSDictionary class]]) return value;
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    for (NSString *key in value) {
        id normalized = [self normalizeResponse:[value objectForKey:key]];
        if (normalized) [dict setObject:normalized forKey:key];
    }
    if ([[dict objectForKey:@"type"] isEqual:@"post"] && ![dict objectForKey:@"post_id"] && [dict objectForKey:@"id"])
        [dict setObject:[dict objectForKey:@"id"] forKey:@"post_id"];
    if (![dict objectForKey:@"url"] && [[dict objectForKey:@"src"] isKindOfClass:[NSString class]])
        [dict setObject:[dict objectForKey:@"src"] forKey:@"url"];
    if (![dict objectForKey:@"text"] && [[dict objectForKey:@"body"] isKindOfClass:[NSString class]])
        [dict setObject:[dict objectForKey:@"body"] forKey:@"text"];
    return dict;
}

+ (NSString *)postText:(NSDictionary *)post {
    if (![post isKindOfClass:[NSDictionary class]]) return @"";
    NSMutableArray *parts = [NSMutableArray array];
    id text = [post objectForKey:@"text"];
    if ([text isKindOfClass:[NSString class]] && [text length]) [parts addObject:text];
    
    NSArray *copies = [post objectForKey:@"copy_history"];
    if ([copies isKindOfClass:[NSArray class]]) {
        for (id copy in copies) {
            if ([copy isKindOfClass:[NSDictionary class]]) {
                NSString *quoted = [self postText:copy];
                [parts addObject:[NSString stringWithFormat:@"Репост: %@", quoted.length ? quoted : @"запись"]];
            }
        }
    }
    
    NSArray *attachments = [post objectForKey:@"attachments"];
    if ([attachments isKindOfClass:[NSArray class]]) {
        for (id attachment in attachments) {
            if (![attachment isKindOfClass:[NSDictionary class]]) continue;
            NSString *type = [attachment objectForKey:@"type"];
            if (![type isKindOfClass:[NSString class]] || [type isEqualToString:@"photo"]) continue;
            NSDictionary *body = [attachment objectForKey:type];
            NSString *title = [body isKindOfClass:[NSDictionary class]] ? ([body objectForKey:@"title"] ?: [body objectForKey:@"question"]) : nil;
            if (![title isKindOfClass:[NSString class]]) title = @"";
            NSString *label = [@{@"video": @"Видео", @"audio": @"Аудиозапись", @"doc": @"Документ", @"poll": @"Опрос", @"note": @"Заметка", @"link": @"Ссылка"} objectForKey:type] ?: @"Вложение";
            [parts addObject:title.length ? [NSString stringWithFormat:@"%@: %@", label, title] : label];
        }
    }
    return [parts componentsJoinedByString:@"\n\n"];
}

+ (NSString *)bestPhotoURL:(NSDictionary *)photo {
    if (![photo isKindOfClass:[NSDictionary class]]) return nil;
    
    NSArray *keys = @[@"photo_2560", @"photo_1280", @"photo_807", @"photo_604", @"photo_320", @"photo_200", @"photo_130", @"photo_75"];
    for (NSString *key in keys) {
        id url = [photo objectForKey:key];
        if ([url isKindOfClass:[NSString class]] && [url length] > 0) return url;
    }
    
    id src = [photo objectForKey:@"src"];
    if ([src isKindOfClass:[NSString class]] && [src length] > 0) return src;
    
    id url = [photo objectForKey:@"url"];
    if ([url isKindOfClass:[NSString class]] && [url length] > 0) return url;
    
    NSArray *sizes = [photo objectForKey:@"sizes"];
    if ([sizes isKindOfClass:[NSArray class]] && sizes.count > 0) {
        NSArray *preferred = @[@"w", @"z", @"y", @"x", @"r", @"q", @"p", @"o", @"m", @"s"];
        for (NSString *type in preferred) {
            for (NSDictionary *size in sizes) {
                if (![size isKindOfClass:[NSDictionary class]]) continue;
                if ([[size objectForKey:@"type"] isEqualToString:type]) {
                    id u = [size objectForKey:@"url"];
                    if ([u isKindOfClass:[NSString class]] && [u length] > 0) return u;
                }
            }
        }
        id last = [sizes lastObject];
        if ([last isKindOfClass:[NSDictionary class]]) {
            id u = [last objectForKey:@"url"];
            if ([u isKindOfClass:[NSString class]] && [u length] > 0) return u;
        }
    }
    return nil;
}

@end