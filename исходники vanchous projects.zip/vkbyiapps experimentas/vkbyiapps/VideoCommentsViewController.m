// VideoCommentsViewController.m
#import "VideoCommentsViewController.h"
#import "VKAPIClient.h"
#import "ProfileViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface VideoCommentsViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate> {
    NSString *ownerId;
    NSString *videoId;
    UITableView *tableView;
    NSMutableArray *comments;
    NSMutableDictionary *profiles;
    NSMutableDictionary *avatarCache;
    UITextField *inputField;
    UIActivityIndicatorView *spinner;
    UILabel *emptyLabel;
    BOOL isLoading;
    BOOL sending;
}
@end

@implementation VideoCommentsViewController

- (instancetype)initWithOwnerId:(NSString *)oId videoId:(NSString *)vId {
    self = [super init];
    if (self) {
        ownerId = oId;
        videoId = vId;
        comments = [NSMutableArray array];
        profiles = [NSMutableDictionary dictionary];
        avatarCache = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Комментарии";
    self.view.backgroundColor = [ThemeManager backgroundColor];
    
    // Таблица
    tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 44)
                                             style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.rowHeight = 60;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorColor = [ThemeManager separatorColor];
    [self.view addSubview:tableView];
    
    // Панель ввода
    UIView *inputBar = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44)];
    inputBar.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1.0];
    inputBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    inputBar.layer.shadowColor = [UIColor blackColor].CGColor;
    inputBar.layer.shadowOffset = CGSizeMake(0, -1);
    inputBar.layer.shadowOpacity = 0.15;
    [self.view addSubview:inputBar];
    
    inputField = [[UITextField alloc] initWithFrame:CGRectMake(8, 4, inputBar.bounds.size.width - 60, 36)];
    inputField.borderStyle = UITextBorderStyleRoundedRect;
    inputField.placeholder = @"Написать комментарий...";
    inputField.delegate = self;
    inputField.returnKeyType = UIReturnKeySend;
    inputField.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    inputField.font = [UIFont systemFontOfSize:14];
    inputField.backgroundColor = [UIColor whiteColor];
    [inputBar addSubview:inputField];
    
    UIButton *sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sendButton.frame = CGRectMake(inputBar.bounds.size.width - 48, 4, 40, 36);
    [sendButton setTitle:@"▶" forState:UIControlStateNormal];
    [sendButton setTitleColor:[ThemeManager navigationBarTintColor] forState:UIControlStateNormal];
    sendButton.titleLabel.font = [UIFont systemFontOfSize:18];
    sendButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [sendButton addTarget:self action:@selector(sendComment) forControlEvents:UIControlEventTouchUpInside];
    [inputBar addSubview:sendButton];
    
    // Спиннер и пустой лейбл
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    emptyLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height/2 - 30, self.view.bounds.size.width, 60)];
    emptyLabel.text = @"Комментариев нет";
    emptyLabel.textAlignment = NSTextAlignmentCenter;
    emptyLabel.font = [UIFont systemFontOfSize:14];
    emptyLabel.textColor = [UIColor grayColor];
    emptyLabel.hidden = YES;
    [self.view addSubview:emptyLabel];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    [self loadComments];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)loadComments {
    [spinner startAnimating];
    emptyLabel.hidden = YES;
    
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *urlString = [NSString stringWithFormat:
                           @"%@video.getComments?owner_id=%@&video_id=%@&count=100&extended=1&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], ownerId, videoId, token];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [spinner stopAnimating];
            if (error || ![json isKindOfClass:[NSDictionary class]] || json[@"error"]) {
                NSLog(@"❌ [Comments] Error: %@", error ?: json[@"error"]);
                emptyLabel.hidden = NO;
                emptyLabel.text = @"Не удалось загрузить комментарии";
                return;
            }
            
            NSDictionary *response = json[@"response"];
            NSArray *items = response[@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            
            [comments removeAllObjects];
            [comments addObjectsFromArray:items];
            
            NSArray *profilesArray = response[@"profiles"];
            if ([profilesArray isKindOfClass:[NSArray class]]) {
                for (NSDictionary *p in profilesArray) {
                    if (![p isKindOfClass:[NSDictionary class]]) continue;
                    id pid = [p objectForKey:@"id"];
                    if (pid) [profiles setObject:p forKey:[pid stringValue]];
                }
            }
            
            [tableView reloadData];
            if (comments.count == 0) {
                emptyLabel.hidden = NO;
                emptyLabel.text = @"Комментариев нет";
            }
        });
    });
}

- (void)sendComment {
    if (sending) return;
    NSString *text = inputField.text;
    if (text.length == 0) return;
    
    sending = YES;
    inputField.enabled = NO;
    
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *encoded = [text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlString = [NSString stringWithFormat:
                           @"%@video.createComment?owner_id=%@&video_id=%@&message=%@&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], ownerId, videoId, encoded, token];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            sending = NO;
            inputField.enabled = YES;
            if (error || json[@"error"]) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка"
                                                                message:@"Не удалось отправить комментарий"
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
                [alert show];
                return;
            }
            inputField.text = @"";
            [inputField resignFirstResponder];
            // Перезагружаем список
            [self loadComments];
        });
    });
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return comments.count;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"CommentCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:13];
        cell.textLabel.textColor = [ThemeManager cellTextColor];
        cell.textLabel.numberOfLines = 1;
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [ThemeManager cellTextColor];
        cell.detailTextLabel.numberOfLines = 3;
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = 4;
        cell.imageView.layer.borderWidth = 1;
        cell.imageView.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
        cell.imageView.frame = CGRectMake(0, 0, 40, 40);
    }
    
    if (indexPath.row >= comments.count) return cell;
    NSDictionary *comment = comments[indexPath.row];
    if (![comment isKindOfClass:[NSDictionary class]]) return cell;
    
    NSString *fromId = [[comment objectForKey:@"from_id"] stringValue];
    NSDictionary *profile = [profiles objectForKey:fromId];
    NSString *name = @"Пользователь";
    NSString *avatarURL = nil;
    if ([profile isKindOfClass:[NSDictionary class]]) {
        NSString *fn = [profile objectForKey:@"first_name"] ?: @"";
        NSString *ln = [profile objectForKey:@"last_name"] ?: @"";
        name = [NSString stringWithFormat:@"%@ %@", fn, ln];
        avatarURL = [profile objectForKey:@"photo_50"] ?: [profile objectForKey:@"photo_100"];
    }
    
    cell.textLabel.text = name;
    cell.detailTextLabel.text = [comment objectForKey:@"text"] ?: @"";
    
    cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
    if (avatarURL) {
        UIImage *cached = [avatarCache objectForKey:avatarURL];
        if (cached) {
            cell.imageView.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    [avatarCache setObject:image forKey:avatarURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                        if (c) c.imageView.image = image;
                    });
                }
            }];
        }
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= comments.count) return 60;
    NSDictionary *comment = comments[indexPath.row];
    NSString *text = [comment objectForKey:@"text"] ?: @"";
    CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:12]
                   constrainedToSize:CGSizeMake(self.view.bounds.size.width - 80, CGFLOAT_MAX)
                       lineBreakMode:UILineBreakModeWordWrap];
    return MAX(size.height + 40, 60);
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= comments.count) return;
    NSDictionary *comment = comments[indexPath.row];
    NSString *fromId = [[comment objectForKey:@"from_id"] stringValue];
    if (fromId.length > 0 && [fromId integerValue] > 0) {
        ProfileViewController *pvc = [[ProfileViewController alloc] initWithUserId:fromId];
        [self.navigationController pushViewController:pvc animated:YES];
    }
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self sendComment];
    return YES;
}

#pragma mark - Keyboard

- (void)keyboardWillShow:(NSNotification *)note {
    CGRect kbFrame = [[note.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat kbHeight = kbFrame.size.height;
    NSTimeInterval duration = [[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect tf = tableView.frame;
        tf.size.height = self.view.bounds.size.height - kbHeight - 44;
        tableView.frame = tf;
        UIView *inputBar = inputField.superview;
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - kbHeight - 44, self.view.bounds.size.width, 44);
    }];
}

- (void)keyboardWillHide:(NSNotification *)note {
    NSTimeInterval duration = [[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect tf = tableView.frame;
        tf.size.height = self.view.bounds.size.height - 44;
        tableView.frame = tf;
        UIView *inputBar = inputField.superview;
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44);
    }];
}

@end