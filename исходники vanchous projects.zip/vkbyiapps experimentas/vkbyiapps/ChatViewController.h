// ChatViewController.h
#import <UIKit/UIKit.h>

@interface ChatViewController : UIViewController
@property (nonatomic, assign) BOOL markAsReadOnEnter; // <-- ДОБАВЛЕНО
- (instancetype)initWithPeerId:(NSString *)peerId title:(NSString *)title;
@end