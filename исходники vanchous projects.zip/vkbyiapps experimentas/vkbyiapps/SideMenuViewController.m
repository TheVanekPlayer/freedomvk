// SideMenuViewController.m
#import "SideMenuViewController.h"
#import "MenuViewController.h"
#import "FeedViewController.h"
#import "MessagesViewController.h"
#import "FriendsViewController.h"
#import "MusicViewController.h"
#import "ProfileViewController.h"
#import "PhotosViewController.h"
#import "VideosViewController.h"
#import "GroupsViewController.h"
#import "SearchViewController.h"
#import "SettingsViewController.h"

static CGFloat const kMenuWidth = 260.0;
static CGFloat const kAnimationDuration = 0.3;
static CGFloat const kOpenThreshold = 80.0;
static CGFloat const kEdgeGestureWidth = 30.0;

@interface SideMenuViewController () <UIGestureRecognizerDelegate, UITabBarControllerDelegate>
@property (nonatomic, strong) UIViewController *centerViewController;
@property (nonatomic, strong) MenuViewController *menuViewController;
@property (nonatomic, assign) BOOL menuVisible;
@property (nonatomic, strong) UIView *overlayView;
@property (nonatomic, strong) UIPanGestureRecognizer *panGesture;
@property (nonatomic, assign) CGPoint panStartPoint;
@end

@implementation SideMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    
    // Меню
    self.menuViewController = [[MenuViewController alloc] init];
    self.menuViewController.sideMenuController = self;
    [self addChildViewController:self.menuViewController];
    self.menuViewController.view.frame = CGRectMake(-kMenuWidth, 0, kMenuWidth, self.view.bounds.size.height);
    [self.view addSubview:self.menuViewController.view];
    [self.menuViewController didMoveToParentViewController:self];
    
    // Затемнение
    self.overlayView = [[UIView alloc] initWithFrame:self.view.bounds];
    self.overlayView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    self.overlayView.hidden = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideMenu)];
    [self.overlayView addGestureRecognizer:tap];
    [self.view addSubview:self.overlayView];
    
    // Таббар с иконками
    UITabBarController *tabBarController = [[UITabBarController alloc] init];
    tabBarController.delegate = self;
    
    // Создаём иконки (нужно добавить файлы в проект: news_icon.png, messages_icon.png и т.д.)
    // Если файлов нет, используем системные иконки (но они не будут выглядеть как VK)
    UIImage *newsIcon = [UIImage imageNamed:@"news_icon"] ?: nil;
    UIImage *messagesIcon = [UIImage imageNamed:@"messages_icon"] ?: nil;
    UIImage *friendsIcon = [UIImage imageNamed:@"friends_icon"] ?: nil;
    UIImage *musicIcon = [UIImage imageNamed:@"music_icon"] ?: nil;
    UIImage *profileIcon = [UIImage imageNamed:@"profile_icon"] ?: nil;
    
    FeedViewController *feedVC = [[FeedViewController alloc] init];
    feedVC.sideMenuController = self;
    UINavigationController *nav1 = [[UINavigationController alloc] initWithRootViewController:feedVC];
    nav1.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Новости" image:newsIcon tag:0];
    
    MessagesViewController *msgVC = [[MessagesViewController alloc] init];
    msgVC.sideMenuController = self;
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:msgVC];
    nav2.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Сообщения" image:messagesIcon tag:1];
    
    FriendsViewController *friendsVC = [[FriendsViewController alloc] init];
    friendsVC.sideMenuController = self;
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:friendsVC];
    nav3.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Друзья" image:friendsIcon tag:2];
    
    MusicViewController *musicVC = [[MusicViewController alloc] init];
    musicVC.sideMenuController = self;
    UINavigationController *nav4 = [[UINavigationController alloc] initWithRootViewController:musicVC];
    nav4.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Музыка" image:musicIcon tag:3];
    
    ProfileViewController *profileVC = [[ProfileViewController alloc] initWithCurrentUser];
    profileVC.sideMenuController = self;
    UINavigationController *nav5 = [[UINavigationController alloc] initWithRootViewController:profileVC];
    nav5.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Профиль" image:profileIcon tag:4];
    
    tabBarController.viewControllers = @[nav1, nav2, nav3, nav4, nav5];
    tabBarController.selectedIndex = 0;
    tabBarController.tabBar.tintColor = [UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0];
    
    [self setCenterViewController:tabBarController];
    
    self.panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    self.panGesture.delegate = self;
    [self.view addGestureRecognizer:self.panGesture];
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    static UIViewController *prev = nil;
    if (prev == viewController) {
        UINavigationController *nav = (UINavigationController *)viewController;
        if ([nav isKindOfClass:[UINavigationController class]]) {
            [nav popToRootViewControllerAnimated:YES];
        }
    }
    prev = viewController;
}

- (void)setCenterViewController:(UIViewController *)centerVC {
    if (self.centerViewController) {
        [self.centerViewController.view removeFromSuperview];
        [self.centerViewController removeFromParentViewController];
    }
    _centerViewController = centerVC;
    [self addChildViewController:centerVC];
    centerVC.view.frame = self.view.bounds;
    [self.view addSubview:centerVC.view];
    [centerVC didMoveToParentViewController:self];
    [self.view bringSubviewToFront:self.overlayView];
    [self.view bringSubviewToFront:self.menuViewController.view];
}

- (void)showMenu {
    if (self.menuVisible) return;
    self.menuVisible = YES;
    self.overlayView.hidden = NO;
    [UIView animateWithDuration:kAnimationDuration animations:^{
        self.centerViewController.view.frame = CGRectOffset(self.view.bounds, kMenuWidth, 0);
        self.menuViewController.view.frame = CGRectMake(0, 0, kMenuWidth, self.view.bounds.size.height);
    }];
}

- (void)hideMenu {
    if (!self.menuVisible) return;
    self.menuVisible = NO;
    [UIView animateWithDuration:kAnimationDuration animations:^{
        self.centerViewController.view.frame = self.view.bounds;
        self.menuViewController.view.frame = CGRectMake(-kMenuWidth, 0, kMenuWidth, self.view.bounds.size.height);
    } completion:^(BOOL finished) {
        self.overlayView.hidden = YES;
    }];
}

- (void)switchToViewControllerAtIndex:(NSInteger)index {
    if ([self.centerViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabBarController = (UITabBarController *)self.centerViewController;
        NSInteger tabIndex = -1;
        switch (index) {
            case 0: tabIndex = 4; break; // Моя страница
            case 1: tabIndex = 0; break; // Новости
            case 2: tabIndex = 2; break; // Друзья
            case 5: tabIndex = 3; break; // Музыка
            case 6: tabIndex = 1; break; // Сообщения
            default: break;
        }
        if (tabIndex >= 0) {
            if (tabBarController.selectedIndex == tabIndex) {
                UINavigationController *nav = (UINavigationController *)tabBarController.selectedViewController;
                if ([nav isKindOfClass:[UINavigationController class]]) {
                    [nav popToRootViewControllerAnimated:YES];
                }
            } else {
                [tabBarController setSelectedIndex:tabIndex];
            }
            [self hideMenu];
            return;
        }
    }
    
    UIViewController *vc = nil;
    switch (index) {
        case 3: vc = [[PhotosViewController alloc] init]; break;
        case 4: vc = [[VideosViewController alloc] init]; break;
        case 7: vc = [[GroupsViewController alloc] init]; break;
        case 8: vc = [[SearchViewController alloc] init]; break;
        case 9: vc = [[SettingsViewController alloc] init]; break;
        default: return;
    }
    if ([vc respondsToSelector:@selector(setSideMenuController:)]) {
        [vc performSelector:@selector(setSideMenuController:) withObject:self];
    }
    if ([self.centerViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabBarController = (UITabBarController *)self.centerViewController;
        UIViewController *selected = tabBarController.selectedViewController;
        if ([selected isKindOfClass:[UINavigationController class]]) {
            [(UINavigationController *)selected pushViewController:vc animated:YES];
            [self hideMenu];
            return;
        }
    }
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self.centerViewController presentModalViewController:nav animated:YES];
    [self hideMenu];
}

- (void)handlePan:(UIPanGestureRecognizer *)gesture {
    CGPoint translation = [gesture translationInView:self.view];
    CGPoint velocity = [gesture velocityInView:self.view];
    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
            self.panStartPoint = self.centerViewController.view.frame.origin;
            break;
        case UIGestureRecognizerStateChanged: {
            CGFloat newX = self.panStartPoint.x + translation.x;
            if (newX < 0) newX = 0;
            if (newX > kMenuWidth) newX = kMenuWidth;
            self.centerViewController.view.frame = CGRectMake(newX, 0, self.view.bounds.size.width, self.view.bounds.size.height);
            CGFloat menuX = -kMenuWidth + newX;
            self.menuViewController.view.frame = CGRectMake(menuX, 0, kMenuWidth, self.view.bounds.size.height);
            CGFloat alpha = newX / kMenuWidth * 0.5;
            self.overlayView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:alpha];
            self.overlayView.hidden = (newX == 0);
            break;
        }
        case UIGestureRecognizerStateEnded:
        case UIGestureRecognizerStateCancelled: {
            CGFloat currentX = self.centerViewController.view.frame.origin.x;
            if (currentX > kOpenThreshold || (velocity.x > 500 && currentX > 0)) {
                [self showMenu];
            } else {
                [self hideMenu];
            }
            break;
        }
        default:
            break;
    }
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer == self.panGesture) {
        CGPoint location = [gestureRecognizer locationInView:self.view];
        if (location.x > kEdgeGestureWidth) return NO;
        UIPanGestureRecognizer *pan = (UIPanGestureRecognizer *)gestureRecognizer;
        CGPoint translation = [pan translationInView:self.view];
        if (fabs(translation.y) > fabs(translation.x)) return NO;
        return YES;
    }
    return YES;
}

@end