// FriendsViewController.m
#import "FriendsViewController.h"
#import "SideMenuViewController.h"
#import "VKAPIClient.h"
#import "ProfileViewController.h"
#import "FriendRequestsViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface FriendsViewController () <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate> {
    UITableView *tableView;
    NSArray *allFriends;
    NSArray *filteredFriends;
    UISearchBar *searchBar;
    UIActivityIndicatorView *spinner;
    NSMutableDictionary *avatarCache;
}
@end

@implementation FriendsViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Друзья";
    self.view.backgroundColor = [ThemeManager backgroundColor];
    avatarCache = [NSMutableDictionary dictionary];
    
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 44)];
    searchBar.delegate = self;
    searchBar.placeholder = @"Поиск по друзьям";
    searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    searchBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    searchBar.tintColor = [ThemeManager navigationBarTintColor];
    [self.view addSubview:searchBar];
    
    tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, self.view.bounds.size.width, self.view.bounds.size.height - 44)
                                             style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.rowHeight = 60;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorColor = [ThemeManager separatorColor];
    [self.view addSubview:tableView];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    UIBarButtonItem *requestsBtn = [[UIBarButtonItem alloc] initWithTitle:@"Заявки" style:UIBarButtonItemStylePlain target:self action:@selector(requestsTapped)];
    self.navigationItem.rightBarButtonItem = requestsBtn;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
    
    [self loadFriends];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    // Явно возвращаем навбар, чтобы не было наложения после других экранов
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)themeDidChange:(NSNotification *)notification {
    self.view.backgroundColor = [ThemeManager backgroundColor];
    tableView.separatorColor = [ThemeManager separatorColor];
    [tableView reloadData];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)requestsTapped {
    FriendRequestsViewController *reqVC = [[FriendRequestsViewController alloc] init];
    reqVC.sideMenuController = self.sideMenuController;
    [self.navigationController pushViewController:reqVC animated:YES];
}

- (void)loadFriends {
    [spinner startAnimating];
    [[VKAPIClient sharedClient] getFriendsWithCompletion:^(NSArray *friends, NSError *error) {
        [spinner stopAnimating];
        allFriends = [friends isKindOfClass:[NSArray class]] ? friends : @[];
        filteredFriends = allFriends;
        [tableView reloadData];
    }];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return filteredFriends.count;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"FriendCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    UIImageView *avatarView;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        
        // Кастомный аватар (тег 900)
        avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 44, 44)];
        avatarView.tag = 900;
        avatarView.contentMode = UIViewContentModeScaleAspectFill;
        avatarView.clipsToBounds = YES;
        avatarView.layer.cornerRadius = 4;
        avatarView.layer.borderWidth = 1;
        avatarView.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
        avatarView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        [cell.contentView addSubview:avatarView];
        
        cell.textLabel.font = [UIFont boldSystemFontOfSize:15];
        cell.textLabel.textColor = [ThemeManager cellTextColor];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        
        // Смещаем тексты вправо, чтобы не перекрывались с кастомным imageView
        cell.indentationWidth = 60;
        cell.indentationLevel = 1;
    } else {
        avatarView = (UIImageView *)[cell.contentView viewWithTag:900];
    }
    
    // Сброс
    avatarView.image = [UIImage imageNamed:@"default_avatar"];
    cell.textLabel.text = @"";
    cell.detailTextLabel.text = @"";
    
    if (indexPath.row >= filteredFriends.count) return cell;
    NSDictionary *friend = [filteredFriends objectAtIndex:indexPath.row];
    if (![friend isKindOfClass:[NSDictionary class]]) return cell;
    
    NSString *fn = [friend objectForKey:@"first_name"] ?: @"";
    NSString *ln = [friend objectForKey:@"last_name"] ?: @"";
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", fn, ln];
    
    NSNumber *online = [friend objectForKey:@"online"];
    if ([online boolValue]) {
        cell.detailTextLabel.text = @"● онлайн";
        cell.detailTextLabel.textColor = [UIColor colorWithRed:0.0 green:0.6 blue:0.0 alpha:1.0];
    } else {
        cell.detailTextLabel.text = @"";
        cell.detailTextLabel.textColor = [UIColor grayColor];
    }
    
    NSString *avatarURL = [friend objectForKey:@"photo_50"] ?: [friend objectForKey:@"photo_100"];
    if ([avatarURL isKindOfClass:[NSString class]] && avatarURL.length > 0) {
        UIImage *cached = [avatarCache objectForKey:avatarURL];
        if (cached) {
            avatarView.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    [avatarCache setObject:image forKey:avatarURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        // Обновляем, только если ячейка всё ещё показывает этого друга
                        UITableViewCell *currentCell = [aTableView cellForRowAtIndexPath:indexPath];
                        if (currentCell) {
                            UIImageView *iv = (UIImageView *)[currentCell.contentView viewWithTag:900];
                            if (iv) iv.image = image;
                        }
                    });
                }
            }];
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= filteredFriends.count) return;
    NSDictionary *friend = [filteredFriends objectAtIndex:indexPath.row];
    NSString *uid = [[friend objectForKey:@"id"] stringValue];
    ProfileViewController *pvc = [[ProfileViewController alloc] initWithUserId:uid];
    pvc.sideMenuController = self.sideMenuController;
    [self.navigationController pushViewController:pvc animated:YES];
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)sb textDidChange:(NSString *)searchText {
    if (searchText.length == 0) {
        filteredFriends = allFriends;
    } else {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(first_name CONTAINS[cd] %@) OR (last_name CONTAINS[cd] %@)", searchText, searchText];
        filteredFriends = [allFriends filteredArrayUsingPredicate:predicate];
    }
    [tableView reloadData];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)sb {
    [sb resignFirstResponder];
}

@end