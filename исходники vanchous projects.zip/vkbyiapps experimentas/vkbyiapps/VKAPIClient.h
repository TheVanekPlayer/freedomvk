// VKAPIClient.h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface VKAPIClient : NSObject

+ (instancetype)sharedClient;

- (NSString *)baseURLString;
- (NSString *)tokenURLString;
- (BOOL)useProxy;
- (NSDictionary *)performSyncGET:(NSString *)urlString error:(NSError **)error;
- (void)performAsyncGET:(NSString *)urlString completion:(void(^)(NSData *data, NSError *error))completion;

- (void)authenticateWithUsername:(NSString *)username password:(NSString *)password completion:(void(^)(BOOL success, NSString *token, NSString *userId, NSError *error))completion;
- (void)validateToken:(NSString *)token completion:(void(^)(BOOL valid, NSString *userId, NSString *errorMessage))completion;

- (void)getNewsfeedWithCompletion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion;
- (void)getNewsfeedWithFilter:(NSString *)filter offset:(NSInteger)offset count:(NSInteger)count completion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion;
- (void)getNewsfeedWithOffset:(NSInteger)offset count:(NSInteger)count completion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion;
- (void)searchNewsfeedWithQuery:(NSString *)query completion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion;

- (void)getFriendsWithCompletion:(void(^)(NSArray *friends, NSError *error))completion;
- (void)getFriendsWithFields:(NSString *)fields completion:(void(^)(NSArray *friends, NSError *error))completion;
- (void)followUser:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)unfollowUser:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)getFriendRequestsWithCompletion:(void(^)(NSArray *requests, NSArray *profiles, NSError *error))completion;
- (void)acceptFriendRequest:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)declineFriendRequest:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion;

- (void)getUsersByIds:(NSArray *)userIds completion:(void(^)(NSDictionary *usersById, NSError *error))completion;

- (void)getGroupsWithCompletion:(void(^)(NSArray *groups, NSError *error))completion;
- (void)getGroupById:(NSString *)groupId completion:(void(^)(NSDictionary *group, NSError *error))completion;
- (void)joinGroup:(NSString *)groupId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)leaveGroup:(NSString *)groupId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)getLastPostForGroupId:(NSString *)groupId completion:(void(^)(NSDictionary *post, NSError *error))completion;

- (void)getConversationsWithCompletion:(void(^)(NSArray *conversations, NSDictionary *profiles, NSError *error))completion;
- (void)getMessageHistoryForPeerId:(NSString *)peerId completion:(void(^)(NSArray *messages, NSError *error))completion;
- (void)getMessageHistoryForPeerId:(NSString *)peerId offset:(NSInteger)offset count:(NSInteger)count completion:(void(^)(NSArray *messages, NSError *error))completion;
- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId attachment:(NSString *)attachment stickerId:(NSString *)stickerId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId replyTo:(NSNumber *)replyTo completion:(void(^)(BOOL success, NSError *error))completion;
- (void)editMessage:(NSString *)newText forMessageId:(NSNumber *)messageId peerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)deleteMessage:(NSNumber *)messageId forPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)markMessagesAsReadWithPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)searchMessagesWithQuery:(NSString *)query peerId:(NSString *)peerId completion:(void(^)(NSArray *messages, NSError *error))completion;

- (void)uploadPhotoForMessage:(UIImage *)photo completion:(void(^)(NSString *attachment, NSError *error))completion;
- (void)uploadVideoForMessage:(NSURL *)videoURL completion:(void(^)(NSString *attachment, NSError *error))completion;
- (void)uploadVideoForWall:(NSURL *)videoURL completion:(void(^)(NSString *attachment, NSError *error))completion;
- (void)uploadAudioFile:(NSURL *)fileURL completion:(void(^)(NSString *attachment, NSError *error))completion;
- (void)uploadDocument:(NSURL *)fileURL completion:(void(^)(NSString *attachment, NSError *error))completion;
- (void)uploadPhotoForWall:(UIImage *)photo completion:(void(^)(NSString *attachment, NSError *error))completion;

- (void)getDocumentsWithCompletion:(void(^)(NSArray *docs, NSError *error))completion;
- (void)deleteDocument:(NSString *)docId ownerId:(NSString *)ownerId completion:(void(^)(BOOL success, NSError *error))completion;

- (void)getStickerImageWithId:(NSString *)stickerId completion:(void(^)(UIImage *image, NSError *error))completion;
- (void)getStickerPacksWithCompletion:(void(^)(NSArray *packs, NSError *error))completion;
- (void)getStickersForPackId:(NSInteger)packId completion:(void(^)(NSArray *stickers, NSError *error))completion;
- (void)sendSticker:(NSString *)stickerId toPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion;

- (void)profileGetInfoWithUserId:(NSString *)userId completion:(void(^)(NSDictionary *userInfo, NSError *error))completion;
- (void)getFullProfileInfo:(NSString *)userId completion:(void(^)(NSDictionary *userInfo, NSError *error))completion;
- (void)getCurrentUserInfoWithCompletion:(void(^)(NSDictionary *userInfo, NSError *error))completion;

- (void)getWallPostsWithOwnerId:(NSString *)ownerId completion:(void(^)(NSArray *posts, NSError *error))completion;
- (void)wallPost:(NSString *)text ownerId:(NSString *)ownerId attachment:(NSString *)attachment completion:(void(^)(BOOL success, NSError *error))completion;

- (void)addLikeForOwnerId:(NSString *)ownerId itemId:(NSString *)itemId type:(NSString *)type completion:(void(^)(BOOL success, NSError *error))completion;

- (void)createComment:(NSString *)text forOwnerId:(NSString *)ownerId postId:(NSString *)postId completion:(void(^)(BOOL success, NSError *error))completion;
- (void)getCommentsForPostWithOwnerId:(NSString *)ownerId postId:(NSString *)postId completion:(void(^)(NSArray *comments, NSError *error))completion;

- (void)getPhotoAlbumsWithCompletion:(void(^)(NSArray *albums, NSError *error))completion;

- (void)searchUsersWithQuery:(NSString *)query completion:(void(^)(NSArray *users, NSError *error))completion;
- (void)searchGroupsWithQuery:(NSString *)query completion:(void(^)(NSArray *groups, NSError *error))completion;

- (void)getAudioWithCompletion:(void(^)(NSArray *audios, NSError *error))completion;
- (void)searchAudioWithQuery:(NSString *)query completion:(void(^)(NSArray *audios, NSError *error))completion;

- (void)registerDeviceWithToken:(NSString *)deviceToken completion:(void(^)(BOOL success, NSError *error))completion;
- (void)unregisterDeviceWithCompletion:(void(^)(BOOL success, NSError *error))completion;

- (void)startLongPollWithCompletion:(void(^)(NSDictionary *event))eventHandler;
- (void)stopLongPoll;

- (void)downloadImageWithURL:(NSString *)imageURL completion:(void(^)(UIImage *image))completion;
- (void)clearVideoPreviewCache;

+ (id)normalizeResponse:(id)value;
+ (NSString *)postText:(NSDictionary *)post;
+ (NSString *)bestPhotoURL:(NSDictionary *)photo;
- (void)addAudioWithId:(NSString *)audioId ownerId:(NSString *)ownerId completion:(void(^)(BOOL success, NSError *error))completion;

@end