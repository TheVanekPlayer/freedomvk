#import <UIKit/UIKit.h>

@interface PullToRefreshView : UIView
@property (nonatomic, assign) BOOL isRefreshing;
- (id)initWithTableView:(UITableView *)tableView refreshBlock:(void(^)(void))block;
- (void)endRefreshing;
@end