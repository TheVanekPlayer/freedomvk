#import <UIKit/UIKit.h>

@class SideMenuViewController;

@interface MenuViewController : UIViewController
@property (nonatomic, unsafe_unretained) SideMenuViewController *sideMenuController;
@end