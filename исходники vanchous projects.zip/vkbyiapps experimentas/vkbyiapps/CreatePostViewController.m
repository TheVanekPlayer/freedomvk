// CreatePostViewController.m
#import "CreatePostViewController.h"
#import "VKAPIClient.h"
#import <QuartzCore/QuartzCore.h>

@interface CreatePostViewController () <UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate> {
    UIScrollView *scrollView;
    UITextView *textView;
    UIImageView *photoPreview;
    UIButton *addPhotoButton;
    UIButton *publishButton;
    UIImage *selectedImage;
    UIActivityIndicatorView *spinner;
}
@end

@implementation CreatePostViewController

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"linen_soft.png"]];
    if (!self.view.backgroundColor) self.view.backgroundColor = [UIColor colorWithWhite:0.92 alpha:1.0];
    self.title = @"Новая запись";
    
    scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, 600);
    [self.view addSubview:scrollView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [scrollView addGestureRecognizer:tap];
    
    // Карточка с текстом
    UIView *textCard = [[UIView alloc] initWithFrame:CGRectMake(15, 15, self.view.bounds.size.width - 30, 180)];
    textCard.backgroundColor = [UIColor whiteColor];
    textCard.layer.cornerRadius = 8;
    textCard.layer.shadowColor = [UIColor blackColor].CGColor;
    textCard.layer.shadowOffset = CGSizeMake(0, 2);
    textCard.layer.shadowOpacity = 0.15;
    textCard.layer.shadowRadius = 4;
    [scrollView addSubview:textCard];
    
    UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 8, 200, 20)];
    headerLabel.text = @"Что нового?";
    headerLabel.font = [UIFont boldSystemFontOfSize:14];
    headerLabel.textColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
    [textCard addSubview:headerLabel];
    
    textView = [[UITextView alloc] initWithFrame:CGRectMake(8, 32, textCard.bounds.size.width - 16, 140)];
    textView.font = [UIFont systemFontOfSize:15];
    textView.backgroundColor = [UIColor clearColor];
    textView.delegate = self;
    textView.text = @"Введите текст записи...";
    textView.textColor = [UIColor lightGrayColor];
    [textCard addSubview:textView];
    
    // Превью фото
    photoPreview = [[UIImageView alloc] initWithFrame:CGRectMake(15, 210, self.view.bounds.size.width - 30, 200)];
    photoPreview.contentMode = UIViewContentModeScaleAspectFit;
    photoPreview.backgroundColor = [UIColor whiteColor];
    photoPreview.layer.cornerRadius = 8;
    photoPreview.layer.borderWidth = 1;
    photoPreview.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
    photoPreview.layer.shadowColor = [UIColor blackColor].CGColor;
    photoPreview.layer.shadowOffset = CGSizeMake(0, 2);
    photoPreview.layer.shadowOpacity = 0.15;
    photoPreview.layer.shadowRadius = 4;
    photoPreview.hidden = YES;
    photoPreview.userInteractionEnabled = YES;
    [scrollView addSubview:photoPreview];
    
    // Кнопка удалить фото (крестик)
    UIButton *removePhoto = [UIButton buttonWithType:UIButtonTypeCustom];
    removePhoto.frame = CGRectMake(photoPreview.bounds.size.width - 30, 5, 25, 25);
    [removePhoto setTitle:@"✕" forState:UIControlStateNormal];
    [removePhoto setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    removePhoto.backgroundColor = [UIColor colorWithRed:0.8 green:0.2 blue:0.2 alpha:1.0];
    removePhoto.layer.cornerRadius = 12.5;
    removePhoto.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    removePhoto.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [removePhoto addTarget:self action:@selector(removePhotoTapped) forControlEvents:UIControlEventTouchUpInside];
    [photoPreview addSubview:removePhoto];
    
    // Кнопка "Добавить фото" с градиентом
    addPhotoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    addPhotoButton.frame = CGRectMake(15, 210, self.view.bounds.size.width - 30, 44);
    [addPhotoButton setTitle:@"📷  Добавить фото" forState:UIControlStateNormal];
    [addPhotoButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    addPhotoButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    addPhotoButton.layer.cornerRadius = 8;
    addPhotoButton.layer.shadowColor = [UIColor blackColor].CGColor;
    addPhotoButton.layer.shadowOffset = CGSizeMake(0, 2);
    addPhotoButton.layer.shadowOpacity = 0.3;
    addPhotoButton.layer.shadowRadius = 3;
    
    CAGradientLayer *btnGrad = [CAGradientLayer layer];
    btnGrad.frame = addPhotoButton.bounds;
    btnGrad.colors = @[(id)[UIColor colorWithRed:0.3 green:0.5 blue:0.75 alpha:1.0].CGColor,
                       (id)[UIColor colorWithRed:0.15 green:0.3 blue:0.55 alpha:1.0].CGColor];
    btnGrad.cornerRadius = 8;
    [addPhotoButton.layer insertSublayer:btnGrad atIndex:0];
    
    [addPhotoButton addTarget:self action:@selector(addPhotoTapped) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:addPhotoButton];
    
    // Кнопка "Опубликовать"
    publishButton = [UIButton buttonWithType:UIButtonTypeCustom];
    publishButton.frame = CGRectMake(15, 270, self.view.bounds.size.width - 30, 44);
    [publishButton setTitle:@"✅  Опубликовать" forState:UIControlStateNormal];
    [publishButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    publishButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    publishButton.layer.cornerRadius = 8;
    publishButton.layer.shadowColor = [UIColor blackColor].CGColor;
    publishButton.layer.shadowOffset = CGSizeMake(0, 2);
    publishButton.layer.shadowOpacity = 0.3;
    publishButton.layer.shadowRadius = 3;
    
    CAGradientLayer *pubGrad = [CAGradientLayer layer];
    pubGrad.frame = publishButton.bounds;
    pubGrad.colors = @[(id)[UIColor colorWithRed:0.3 green:0.75 blue:0.3 alpha:1.0].CGColor,
                       (id)[UIColor colorWithRed:0.15 green:0.55 blue:0.15 alpha:1.0].CGColor];
    pubGrad.cornerRadius = 8;
    [publishButton.layer insertSublayer:pubGrad atIndex:0];
    
    [publishButton addTarget:self action:@selector(publishTapped) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:publishButton];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    UIBarButtonItem *cancelBtn = [[UIBarButtonItem alloc] initWithTitle:@"Отмена" style:UIBarButtonItemStylePlain target:self action:@selector(cancelTapped)];
    self.navigationItem.leftBarButtonItem = cancelBtn;
}

- (void)dismissKeyboard {
    [textView resignFirstResponder];
}

- (void)addPhotoTapped {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    picker.allowsEditing = NO;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)removePhotoTapped {
    selectedImage = nil;
    photoPreview.image = nil;
    photoPreview.hidden = YES;
    addPhotoButton.hidden = NO;
    publishButton.frame = CGRectMake(15, 270, self.view.bounds.size.width - 30, 44);
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    [self dismissViewControllerAnimated:YES completion:nil];
    photoPreview.image = selectedImage;
    photoPreview.hidden = NO;
    addPhotoButton.hidden = YES;
    publishButton.frame = CGRectMake(15, 420, self.view.bounds.size.width - 30, 44);
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)publishTapped {
    NSString *text = textView.text;
    if ([text isEqualToString:@"Введите текст записи..."]) text = @"";
    NSString *ownerId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"] ?: @"";
    if (!ownerId.length) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не определён пользователь" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        return;
    }
    [spinner startAnimating];
    publishButton.enabled = NO;
    
    void (^publishBlock)(NSString *) = ^(NSString *attachment) {
        [[VKAPIClient sharedClient] wallPost:text ownerId:ownerId attachment:attachment completion:^(BOOL success, NSError *error) {
            [spinner stopAnimating];
            publishButton.enabled = YES;
            if (success) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Успех" message:@"Запись опубликована" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
                [self.navigationController popViewControllerAnimated:YES];
            } else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
            }
        }];
    };
    
    if (selectedImage) {
        [[VKAPIClient sharedClient] uploadPhotoForWall:selectedImage completion:^(NSString *attachment, NSError *error) {
            if (error) {
                [spinner stopAnimating];
                publishButton.enabled = YES;
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
                return;
            }
            publishBlock(attachment);
        }];
    } else {
        publishBlock(nil);
    }
}

- (void)cancelTapped {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)textViewDidBeginEditing:(UITextView *)tv {
    if ([tv.text isEqualToString:@"Введите текст записи..."]) {
        tv.text = @"";
        tv.textColor = [UIColor blackColor];
    }
}

- (void)textViewDidEndEditing:(UITextView *)tv {
    if (tv.text.length == 0) {
        tv.text = @"Введите текст записи...";
        tv.textColor = [UIColor lightGrayColor];
    }
}

@end