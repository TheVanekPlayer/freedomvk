// VideoPlayerViewController.h
#import <UIKit/UIKit.h>

@interface VideoPlayerViewController : UIViewController

// Основной инициализатор — только ID владельца и ID видео
- (instancetype)initWithVideoOwnerId:(NSString *)ownerId
                             videoId:(NSString *)videoId;

// Расширенный инициализатор — если из ленты уже известны данные видео
// (например, из video.get), можно передать их, чтобы не ждать API
- (instancetype)initWithVideoOwnerId:(NSString *)ownerId
                             videoId:(NSString *)videoId
                           videoInfo:(NSDictionary *)videoInfo;

@end