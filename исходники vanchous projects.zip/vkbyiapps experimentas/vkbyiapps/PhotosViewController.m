// PhotosViewController.m
#import "PhotosViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "FullscreenImageViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface PhotosViewController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *collectionView;
    NSArray *albums;
    NSArray *photos;
    UIActivityIndicatorView *spinner;
    NSMutableDictionary *imageCache;
    NSString *currentAlbumId;
}
// sideMenuController объявлено в .h — здесь НЕ дублируем!
@end

@implementation PhotosViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Фотографии";
    self.view.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1.0];
    imageCache = [NSMutableDictionary dictionary];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(100, 100);
    layout.minimumInteritemSpacing = 4;
    layout.minimumLineSpacing = 4;
    layout.sectionInset = UIEdgeInsetsMake(8, 8, 8, 8);
    
    collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    collectionView.dataSource = self;
    collectionView.delegate = self;
    collectionView.backgroundColor = [UIColor clearColor];
    [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"PhotoCell"];
    [self.view addSubview:collectionView];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [self loadAlbums];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadAlbums {
    [spinner startAnimating];
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    NSString *urlString = [NSString stringWithFormat:@"%@photos.getAlbums?owner_id=%@&need_system=1&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], userId, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [spinner stopAnimating];
            if (error || json[@"error"]) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не удалось загрузить альбомы" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
                return;
            }
            albums = json[@"response"][@"items"] ?: json[@"response"];
            if (![albums isKindOfClass:[NSArray class]] || albums.count == 0) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Инфо" message:@"Нет альбомов" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
                return;
            }
            [collectionView reloadData];
            // Автоматически открываем первый альбом
            if (albums.count > 0) {
                NSDictionary *album = [albums objectAtIndex:0];
                [self openAlbum:[album objectForKey:@"id"]];
            }
        });
    });
}

- (void)openAlbum:(id)albumId {
    currentAlbumId = [albumId stringValue];
    [spinner startAnimating];
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    NSString *urlString = [NSString stringWithFormat:@"%@photos.get?owner_id=%@&album_id=%@&count=100&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], userId, currentAlbumId, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [spinner stopAnimating];
            if (error || json[@"error"]) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не удалось загрузить фото" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
                return;
            }
            photos = json[@"response"][@"items"] ?: json[@"response"];
            if (![photos isKindOfClass:[NSArray class]]) photos = @[];
            [collectionView reloadData];
        });
    });
}

#pragma mark - UICollectionView

- (NSInteger)collectionView:(UICollectionView *)cv numberOfItemsInSection:(NSInteger)section {
    return photos.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"PhotoCell" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    cell.layer.borderWidth = 1;
    cell.layer.borderColor = [UIColor colorWithWhite:0.7 alpha:1.0].CGColor;
    
    UIImageView *imageView = (UIImageView *)[cell.contentView viewWithTag:200];
    if (!imageView) {
        imageView = [[UIImageView alloc] initWithFrame:cell.contentView.bounds];
        imageView.tag = 200;
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = YES;
        [cell.contentView addSubview:imageView];
    }
    imageView.image = nil;
    
    NSDictionary *photo = [photos objectAtIndex:indexPath.row];
    NSString *photoURL = [VKAPIClient bestPhotoURL:photo];
    
    if (photoURL) {
        UIImage *cached = [imageCache objectForKey:photoURL];
        if (cached) {
            imageView.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                if (image) {
                    [imageCache setObject:image forKey:photoURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UICollectionViewCell *updateCell = [cv cellForItemAtIndexPath:indexPath];
                        if (updateCell) {
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:200];
                            iv.image = image;
                        }
                    });
                }
            }];
        }
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)cv didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *photo = [photos objectAtIndex:indexPath.row];
    NSString *photoURL = [VKAPIClient bestPhotoURL:photo];
    if (!photoURL) return;
    
    // Используем полноэкранный просмотр с URL (лучшее качество)
    FullscreenImageViewController *fs = [[FullscreenImageViewController alloc] initWithImageURL:photoURL];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:fs];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:nav animated:YES completion:nil];
}

@end