// GroupsViewController.h
#import <UIKit/UIKit.h>

@interface GroupsViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end