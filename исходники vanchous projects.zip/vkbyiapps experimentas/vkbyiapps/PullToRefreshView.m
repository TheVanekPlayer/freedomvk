#import "PullToRefreshView.h"

#define kPullToRefresh @"Потяните вниз"
#define kReleaseToRefresh @"Потяните, чтобы обновить"
#define kLoading @"Загрузка..."

@interface PullToRefreshView () <UIScrollViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, copy) void(^refreshBlock)(void);
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@end

@implementation PullToRefreshView

- (id)initWithTableView:(UITableView *)tableView refreshBlock:(void(^)(void))block {
    self = [super initWithFrame:CGRectMake(0, -60, tableView.bounds.size.width, 60)];
    if (self) {
        self.tableView = tableView;
        self.refreshBlock = block;
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        self.backgroundColor = [UIColor clearColor];
        self.statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, self.bounds.size.width, 20)];
        self.statusLabel.textAlignment = NSTextAlignmentCenter;
        self.statusLabel.font = [UIFont boldSystemFontOfSize:13];
        self.statusLabel.textColor = [UIColor grayColor];
        self.statusLabel.text = kPullToRefresh;
        [self addSubview:self.statusLabel];
        self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        self.spinner.center = CGPointMake(self.bounds.size.width/2 - 50, 30);
        [self addSubview:self.spinner];
        [self.tableView addSubview:self];
        [self.tableView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    }
    return self;
}

- (void)dealloc {
    [self.tableView removeObserver:self forKeyPath:@"contentOffset"];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"contentOffset"]) {
        if (self.isRefreshing) return;
        CGPoint offset = self.tableView.contentOffset;
        if (offset.y < -80) {
            self.statusLabel.text = kReleaseToRefresh;
        } else if (offset.y < 0) {
            self.statusLabel.text = kPullToRefresh;
        }
    }
}

- (void)endRefreshing {
    self.isRefreshing = NO;
    [self.spinner stopAnimating];
    self.statusLabel.text = kPullToRefresh;
    [UIView animateWithDuration:0.3 animations:^{
        UIEdgeInsets insets = self.tableView.contentInset;
        insets.top = 0;
        self.tableView.contentInset = insets;
    }];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (self.isRefreshing) return;
    if (scrollView.contentOffset.y < -80) {
        self.isRefreshing = YES;
        self.statusLabel.text = kLoading;
        [self.spinner startAnimating];
        [UIView animateWithDuration:0.3 animations:^{
            UIEdgeInsets insets = self.tableView.contentInset;
            insets.top = 60;
            self.tableView.contentInset = insets;
        }];
        if (self.refreshBlock) self.refreshBlock();
    }
}

@end