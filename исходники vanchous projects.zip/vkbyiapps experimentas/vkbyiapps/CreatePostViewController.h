// CreatePostViewController.h
#import <UIKit/UIKit.h>

@interface CreatePostViewController : UIViewController
@end