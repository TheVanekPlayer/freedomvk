// OVKAPICompatibility.h
#import <Foundation/Foundation.h>

@interface OVKAPICompatibility : NSObject

+ (NSString *)postText:(NSDictionary *)post;
+ (id)normalizeResponse:(id)value;
+ (NSError *)errorFromEnvelope:(NSDictionary *)envelope;
+ (NSDictionary *)parameters:(NSDictionary *)parameters forMethod:(NSString *)method userId:(long long)userId;

@end