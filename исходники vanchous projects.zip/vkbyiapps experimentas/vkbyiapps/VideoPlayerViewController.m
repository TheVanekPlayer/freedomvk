// VideoPlayerViewController.m
#import "VideoPlayerViewController.h"
#import "VKAPIClient.h"
#import "ProfileViewController.h"
#import "GroupWallViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>

@interface VideoPlayerViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate> {
    NSString *ownerId;
    NSString *videoId;
    
    // Плеер
    MPMoviePlayerController *moviePlayer;
    UIView *playerContainer;
    
    // Верх / низ
    UIView *topBar;
    UIView *inputBar;
    UITextField *inputField;
    
    // Скролл
    UIScrollView *scrollView;
    
    // Инфо-панель
    UIView *infoView;
    UIImageView *authorAvatar;
    UILabel *authorName;
    UILabel *authorStatus;
    UIButton *authorTapButton;
    UILabel *videoTitle;
    UILabel *metaLabel;
    UIButton *likeButton;
    UIButton *commentsButton;
    
    // Комментарии
    UILabel *commentsHeaderLabel;
    UITableView *commentsTableView;
    NSMutableArray *comments;
    NSMutableDictionary *profiles;
    NSMutableDictionary *avatarCache;
    
    // Прочее
    UIActivityIndicatorView *spinner;
    UILabel *statusLabel;
    UILabel *progressLabel;
    
    NSMutableData *videoData;
    long long expectedBytes;
    long long receivedBytes;
    
    BOOL isLiked;
    NSInteger likeCount;
    NSInteger commentCount;
    BOOL isLoadingComments;
}
@end

@implementation VideoPlayerViewController

- (instancetype)initWithVideoOwnerId:(NSString *)oId videoId:(NSString *)vId {
    self = [super init];
    if (self) {
        ownerId = oId;
        videoId = vId;
        avatarCache = [NSMutableDictionary dictionary];
        comments = [NSMutableArray array];
        profiles = [NSMutableDictionary dictionary];
    }
    return self;
}

#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [ThemeManager backgroundColor];
    self.title = @"Видео";
    
    CGFloat w = self.view.bounds.size.width;
    CGFloat h = self.view.bounds.size.height;
    
    // ===== ВЕРХНЯЯ ПАНЕЛЬ (в стиле навбара VK) =====
    topBar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, 44)];
    topBar.backgroundColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
    topBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:topBar];
    
    CAGradientLayer *topGrad = [CAGradientLayer layer];
    topGrad.frame = topBar.bounds;
    topGrad.colors = @[(id)[UIColor colorWithRed:0.28 green:0.45 blue:0.68 alpha:1.0].CGColor,
                       (id)[UIColor colorWithRed:0.14 green:0.26 blue:0.48 alpha:1.0].CGColor];
    [topBar.layer insertSublayer:topGrad atIndex:0];
    
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(6, 6, 80, 32);
    [backBtn setTitle:@"← Назад" forState:UIControlStateNormal];
    [backBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    backBtn.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    [backBtn addTarget:self action:@selector(closeTapped) forControlEvents:UIControlEventTouchUpInside];
    [topBar addSubview:backBtn];
    
    UILabel *topTitle = [[UILabel alloc] initWithFrame:CGRectMake(90, 11, w - 180, 22)];
    topTitle.text = @"Видео";
    topTitle.textAlignment = NSTextAlignmentCenter;
    topTitle.font = [UIFont boldSystemFontOfSize:17];
    topTitle.textColor = [UIColor whiteColor];
    topTitle.shadowColor = [UIColor colorWithWhite:0 alpha:0.5];
    topTitle.shadowOffset = CGSizeMake(0, -1);
    topTitle.backgroundColor = [UIColor clearColor];
    [topBar addSubview:topTitle];
    
    // ===== ПЛЕЕР ПОД ВЕРХНЕЙ ПАНЕЛЬЮ =====
    CGFloat playerHeight = 220;
    playerContainer = [[UIView alloc] initWithFrame:CGRectMake(0, 44, w, playerHeight)];
    playerContainer.backgroundColor = [UIColor blackColor];
    playerContainer.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:playerContainer];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    spinner.center = CGPointMake(w/2, playerHeight/2 - 20);
    spinner.hidesWhenStopped = YES;
    [playerContainer addSubview:spinner];
    [spinner startAnimating];
    
    statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, playerHeight/2 + 10, w - 40, 40)];
    statusLabel.text = @"Загрузка видео...";
    statusLabel.textAlignment = NSTextAlignmentCenter;
    statusLabel.textColor = [UIColor whiteColor];
    statusLabel.font = [UIFont systemFontOfSize:13];
    statusLabel.numberOfLines = 2;
    statusLabel.backgroundColor = [UIColor clearColor];
    [playerContainer addSubview:statusLabel];
    
    progressLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, playerHeight/2 + 40, w - 40, 18)];
    progressLabel.text = @"";
    progressLabel.textAlignment = NSTextAlignmentCenter;
    progressLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    progressLabel.font = [UIFont systemFontOfSize:11];
    progressLabel.backgroundColor = [UIColor clearColor];
    [playerContainer addSubview:progressLabel];
    
    // ===== СКРОЛЛ С ИНФОЙ И КОММЕНТАМИ =====
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 44 + playerHeight, w, h - 44 - playerHeight - 44)];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.backgroundColor = [ThemeManager backgroundColor];
    scrollView.alwaysBounceVertical = YES;
    [self.view addSubview:scrollView];
    
    [self setupInfoView];
    [self setupCommentsArea];
    
    // ===== ПАНЕЛЬ ВВОДА ВНИЗУ =====
    inputBar = [[UIView alloc] initWithFrame:CGRectMake(0, h - 44, w, 44)];
    inputBar.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1.0];
    inputBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    inputBar.layer.borderColor = [UIColor colorWithWhite:0.8 alpha:1.0].CGColor;
    inputBar.layer.borderWidth = 0.5;
    [self.view addSubview:inputBar];
    
    inputField = [[UITextField alloc] initWithFrame:CGRectMake(8, 5, w - 60, 34)];
    inputField.borderStyle = UITextBorderStyleRoundedRect;
    inputField.placeholder = @"Написать комментарий...";
    inputField.delegate = self;
    inputField.returnKeyType = UIReturnKeySend;
    inputField.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    inputField.font = [UIFont systemFontOfSize:14];
    inputField.backgroundColor = [UIColor whiteColor];
    [inputBar addSubview:inputField];
    
    UIButton *sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sendButton.frame = CGRectMake(w - 48, 5, 40, 34);
    [sendButton setTitle:@"▶" forState:UIControlStateNormal];
    [sendButton setTitleColor:[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0] forState:UIControlStateNormal];
    sendButton.titleLabel.font = [UIFont systemFontOfSize:18];
    sendButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [sendButton addTarget:self action:@selector(sendCommentTapped) forControlEvents:UIControlEventTouchUpInside];
    [inputBar addSubview:sendButton];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self loadVideoURL];
    });
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    // Скрываем системный навбар мгновенно, чтобы не было двойного заголовка
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    // Возвращаем системный навбар мгновенно
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    if (moviePlayer) {
        [moviePlayer pause];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (moviePlayer) {
        [moviePlayer stop];
        moviePlayer = nil;
    }
    NSString *tempPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"ovk_video.mp4"];
    [[NSFileManager defaultManager] removeItemAtPath:tempPath error:nil];
}

#pragma mark - Info View (светлая)

- (void)setupInfoView {
    CGFloat w = scrollView.bounds.size.width;
    
    infoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, 172)];
    infoView.backgroundColor = [ThemeManager cellBackgroundColor];
    [scrollView addSubview:infoView];
    
    // Аватар автора
    authorAvatar = [[UIImageView alloc] initWithFrame:CGRectMake(12, 12, 56, 56)];
    authorAvatar.layer.cornerRadius = 4;
    authorAvatar.clipsToBounds = YES;
    authorAvatar.layer.borderWidth = 1;
    authorAvatar.layer.borderColor = [UIColor colorWithWhite:0.75 alpha:1.0].CGColor;
    authorAvatar.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    authorAvatar.image = [UIImage imageNamed:@"default_avatar"];
    authorAvatar.userInteractionEnabled = YES;
    [infoView addSubview:authorAvatar];
    
    authorTapButton = [UIButton buttonWithType:UIButtonTypeCustom];
    authorTapButton.frame = authorAvatar.frame;
    [authorTapButton addTarget:self action:@selector(authorTapped) forControlEvents:UIControlEventTouchUpInside];
    [infoView addSubview:authorTapButton];
    
    // Имя автора
    authorName = [[UILabel alloc] initWithFrame:CGRectMake(80, 16, w - 92, 20)];
    authorName.font = [UIFont boldSystemFontOfSize:15];
    authorName.textColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0];
    authorName.backgroundColor = [UIColor clearColor];
    authorName.text = @"Загрузка...";
    [infoView addSubview:authorName];
    
    // Статус автора
    authorStatus = [[UILabel alloc] initWithFrame:CGRectMake(80, 38, w - 92, 16)];
    authorStatus.font = [UIFont systemFontOfSize:11];
    authorStatus.textColor = [UIColor grayColor];
    authorStatus.backgroundColor = [UIColor clearColor];
    authorStatus.text = @"";
    [infoView addSubview:authorStatus];
    
    // Название видео
    videoTitle = [[UILabel alloc] initWithFrame:CGRectMake(12, 80, w - 24, 20)];
    videoTitle.font = [UIFont boldSystemFontOfSize:14];
    videoTitle.textColor = [ThemeManager cellTextColor];
    videoTitle.backgroundColor = [UIColor clearColor];
    videoTitle.numberOfLines = 2;
    videoTitle.text = @"";
    [infoView addSubview:videoTitle];
    
    // Мета-инфа
    metaLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 108, w - 24, 16)];
    metaLabel.font = [UIFont systemFontOfSize:11];
    metaLabel.textColor = [UIColor grayColor];
    metaLabel.backgroundColor = [UIColor clearColor];
    metaLabel.text = @"";
    [infoView addSubview:metaLabel];
    
    // Разделитель
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(0, 130, w, 1)];
    sep.backgroundColor = [ThemeManager separatorColor];
    sep.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [infoView addSubview:sep];
    
    // Кнопка лайка
    likeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    likeButton.frame = CGRectMake(12, 136, 130, 30);
    [likeButton setTitleColor:[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0]
                     forState:UIControlStateNormal];
    likeButton.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    likeButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    likeButton.layer.cornerRadius = 4;
    likeButton.layer.borderWidth = 1;
    likeButton.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
    likeButton.backgroundColor = [UIColor colorWithWhite:0.97 alpha:1.0];
    likeButton.titleEdgeInsets = UIEdgeInsetsMake(0, 8, 0, 0);
    [likeButton addTarget:self action:@selector(likeTapped) forControlEvents:UIControlEventTouchUpInside];
    [infoView addSubview:likeButton];
    
    // Кнопка комментариев
    commentsButton = [UIButton buttonWithType:UIButtonTypeCustom];
    commentsButton.frame = CGRectMake(150, 136, 160, 30);
    [commentsButton setTitleColor:[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0]
                         forState:UIControlStateNormal];
    commentsButton.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    commentsButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    commentsButton.layer.cornerRadius = 4;
    commentsButton.layer.borderWidth = 1;
    commentsButton.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
    commentsButton.backgroundColor = [UIColor colorWithWhite:0.97 alpha:1.0];
    commentsButton.titleEdgeInsets = UIEdgeInsetsMake(0, 8, 0, 0);
    [commentsButton addTarget:self action:@selector(commentsTapped) forControlEvents:UIControlEventTouchUpInside];
    [infoView addSubview:commentsButton];
}

- (void)setupCommentsArea {
    CGFloat w = scrollView.bounds.size.width;
    
    commentsHeaderLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 182, w - 24, 22)];
    commentsHeaderLabel.font = [UIFont boldSystemFontOfSize:13];
    commentsHeaderLabel.textColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0];
    commentsHeaderLabel.backgroundColor = [UIColor clearColor];
    commentsHeaderLabel.text = @"Комментарии";
    [scrollView addSubview:commentsHeaderLabel];
    
    commentsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 210, w, 60) style:UITableViewStylePlain];
    commentsTableView.backgroundColor = [ThemeManager cellBackgroundColor];
    commentsTableView.separatorColor = [ThemeManager separatorColor];
    commentsTableView.dataSource = self;
    commentsTableView.delegate = self;
    commentsTableView.scrollEnabled = NO;
    commentsTableView.rowHeight = 60;
    [scrollView addSubview:commentsTableView];
    
    [self updateScrollContentSize];
}

- (void)updateScrollContentSize {
    CGFloat w = scrollView.bounds.size.width;
    CGFloat tableHeight = comments.count * 60;
    if (tableHeight < 60) tableHeight = 60;
    
    CGRect f = commentsTableView.frame;
    f.size.height = tableHeight;
    commentsTableView.frame = f;
    
    CGFloat totalHeight = 210 + tableHeight + 20;
    scrollView.contentSize = CGSizeMake(w, totalHeight);
}

#pragma mark - Update header

- (void)updateHeaderWithVideoInfo:(NSDictionary *)video {
    NSString *title = [video objectForKey:@"title"] ?: @"";
    videoTitle.text = title;
    
    // Мета
    NSMutableArray *parts = [NSMutableArray array];
    NSNumber *dateNum = [video objectForKey:@"date"];
    if (dateNum) {
        NSDate *d = [NSDate dateWithTimeIntervalSince1970:[dateNum doubleValue]];
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateFormat = @"dd.MM.yyyy";
        [parts addObject:[df stringFromDate:d]];
    }
    NSNumber *duration = [video objectForKey:@"duration"];
    if (duration) {
        NSInteger secs = [duration integerValue];
        [parts addObject:[NSString stringWithFormat:@"%ld:%02ld", (long)(secs/60), (long)(secs%60)]];
    }
    NSNumber *views = [video objectForKey:@"views"];
    if (views) [parts addObject:[NSString stringWithFormat:@"👁 %@", views]];
    metaLabel.text = [parts componentsJoinedByString:@"  •  "];
    
    // Лайки
    NSDictionary *likes = [video objectForKey:@"likes"];
    likeCount = [[likes objectForKey:@"count"] integerValue];
    isLiked = [[likes objectForKey:@"user_likes"] boolValue];
    [self updateLikeButton];
    
    // Комментарии
    NSNumber *commentsNum = [video objectForKey:@"comments"];
    if ([commentsNum isKindOfClass:[NSNumber class]]) {
        commentCount = [commentsNum integerValue];
    } else if ([commentsNum isKindOfClass:[NSDictionary class]]) {
        commentCount = [[(NSDictionary *)commentsNum objectForKey:@"count"] integerValue];
    } else {
        commentCount = 0;
    }
    [commentsButton setTitle:[NSString stringWithFormat:@"💬  Комментарии (%ld)", (long)commentCount]
                    forState:UIControlStateNormal];
    commentsHeaderLabel.text = [NSString stringWithFormat:@"Комментарии (%ld)", (long)commentCount];
    
    // Автор
    NSNumber *ownerIdNum = [video objectForKey:@"owner_id"];
    NSInteger oid = [ownerIdNum integerValue];
    if (oid != 0) {
        if (oid > 0) {
            [[VKAPIClient sharedClient] profileGetInfoWithUserId:[NSString stringWithFormat:@"%ld", (long)oid]
                                                      completion:^(NSDictionary *userInfo, NSError *error) {
                                                          if (error || !userInfo) return;
                                                          NSString *fn = [userInfo objectForKey:@"first_name"] ?: @"";
                                                          NSString *ln = [userInfo objectForKey:@"last_name"] ?: @"";
                                                          authorName.text = [NSString stringWithFormat:@"%@ %@", fn, ln];
                                                          BOOL online = [[userInfo objectForKey:@"online"] boolValue];
                                                          authorStatus.text = online ? @"● онлайн" : @"";
                                                          authorStatus.textColor = online ? [UIColor colorWithRed:0.0 green:0.6 blue:0.0 alpha:1.0]
                                                          : [UIColor grayColor];
                                                          NSString *avatarURL = [userInfo objectForKey:@"photo_100"] ?: [userInfo objectForKey:@"photo_50"];
                                                          [self loadAvatar:avatarURL];
                                                      }];
        } else {
            NSString *gid = [NSString stringWithFormat:@"%ld", (long)(-oid)];
            NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
            NSString *urlString = [NSString stringWithFormat:
                                   @"%@groups.getById?group_id=%@&fields=photo_100,photo_50&access_token=%@&v=5.131",
                                   [[VKAPIClient sharedClient] baseURLString], gid, token];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                NSError *error = nil;
                NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSArray *groups = json[@"response"];
                    if ([groups isKindOfClass:[NSArray class]] && groups.count > 0) {
                        NSDictionary *g = groups[0];
                        authorName.text = [g objectForKey:@"name"] ?: @"Сообщество";
                        authorStatus.text = @"Сообщество";
                        NSString *avatarURL = [g objectForKey:@"photo_100"] ?: [g objectForKey:@"photo_50"];
                        [self loadAvatar:avatarURL];
                    }
                });
            });
        }
    }
}

- (void)loadAvatar:(NSString *)url {
    if (![url isKindOfClass:[NSString class]] || url.length == 0) return;
    UIImage *cached = [avatarCache objectForKey:url];
    if (cached) { authorAvatar.image = cached; return; }
    [[VKAPIClient sharedClient] downloadImageWithURL:url completion:^(UIImage *image) {
        if (image) {
            [avatarCache setObject:image forKey:url];
            dispatch_async(dispatch_get_main_queue(), ^{
                authorAvatar.image = image;
            });
        }
    }];
}

- (void)updateLikeButton {
    NSString *heart = isLiked ? @"❤" : @"♡";
    [likeButton setTitle:[NSString stringWithFormat:@"  %@  %ld", heart, (long)likeCount]
                forState:UIControlStateNormal];
    [likeButton setTitleColor:isLiked ? [UIColor colorWithRed:0.75 green:0.15 blue:0.15 alpha:1.0]
                             : [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0]
                     forState:UIControlStateNormal];
    likeButton.backgroundColor = isLiked ? [UIColor colorWithRed:1.0 green:0.95 blue:0.95 alpha:1.0]
    : [UIColor colorWithWhite:0.97 alpha:1.0];
    likeButton.layer.borderColor = isLiked ? [UIColor colorWithRed:0.9 green:0.7 blue:0.7 alpha:1.0].CGColor
    : [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
}

#pragma mark - Actions

- (void)authorTapped {
    if ([ownerId hasPrefix:@"-"]) {
        NSString *gid = [ownerId substringFromIndex:1];
        GroupWallViewController *wallVC = [[GroupWallViewController alloc] initWithGroupId:gid
                                                                                      name:authorName.text
                                                                                 avatarURL:nil];
        [self.navigationController pushViewController:wallVC animated:YES];
    } else {
        ProfileViewController *pvc = [[ProfileViewController alloc] initWithUserId:ownerId];
        [self.navigationController pushViewController:pvc animated:YES];
    }
}

- (void)likeTapped {
    NSString *method = isLiked ? @"likes.delete" : @"likes.add";
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *urlString = [NSString stringWithFormat:
                           @"%@%@?type=video&owner_id=%@&item_id=%@&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], method, ownerId, videoId, token];
    
    BOOL newLiked = !isLiked;
    isLiked = newLiked;
    likeCount += newLiked ? 1 : -1;
    if (likeCount < 0) likeCount = 0;
    [self updateLikeButton];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        BOOL success = (!error && ![json objectForKey:@"error"]);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!success) {
                isLiked = !newLiked;
                likeCount += newLiked ? -1 : 1;
                if (likeCount < 0) likeCount = 0;
                [self updateLikeButton];
            }
        });
    });
}

- (void)commentsTapped {
    [scrollView setContentOffset:CGPointMake(0, 182) animated:YES];
    [inputField becomeFirstResponder];
}

- (void)sendCommentTapped {
    NSString *text = inputField.text;
    if (text.length == 0) return;
    
    inputField.enabled = NO;
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *encoded = [text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlString = [NSString stringWithFormat:
                           @"%@video.createComment?owner_id=%@&video_id=%@&message=%@&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], ownerId, videoId, encoded, token];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            inputField.enabled = YES;
            if (error || json[@"error"]) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка"
                                                                message:@"Не удалось отправить комментарий"
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
                [alert show];
                return;
            }
            inputField.text = @"";
            [inputField resignFirstResponder];
            [self loadComments];
        });
    });
}

- (void)closeTapped {
    if (moviePlayer) {
        [moviePlayer stop];
        moviePlayer = nil;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Загрузка видео

- (void)loadVideoURL {
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *urlString = [NSString stringWithFormat:@"%@video.get?videos=%@_%@&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], ownerId, videoId, token];
    
    NSLog(@"🎬 [Video] Запрос: %@", urlString);
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || ![json isKindOfClass:[NSDictionary class]] || json[@"error"]) {
                [self showError:@"Ошибка загрузки данных"];
                return;
            }
            NSDictionary *response = json[@"response"];
            NSArray *items = response[@"items"];
            if (![items isKindOfClass:[NSArray class]] || items.count == 0) {
                [self showError:@"Видео не найдено"];
                return;
            }
            NSDictionary *video = items[0];
            [self updateHeaderWithVideoInfo:video];
            
            NSDictionary *files = video[@"files"];
            if (![files isKindOfClass:[NSDictionary class]]) {
                [self showError:@"Ссылка на видео недоступна"];
                return;
            }
            NSString *videoURL = [self bestVideoURLFromFiles:files];
            if (!videoURL) {
                [self showError:@"Нет доступного качества"];
                return;
            }
            NSLog(@"🎬 [Video] URL: %@", videoURL);
            [self downloadAndPlayVideo:videoURL];
        });
    });
}

- (NSString *)bestVideoURLFromFiles:(NSDictionary *)files {
    BOOL optimize = [[NSUserDefaults standardUserDefaults] boolForKey:@"OptimizeMode"];
    NSArray *keys = optimize
    ? @[@"mp4_240", @"mp4_360", @"mp4_480", @"mp4_720"]
    : @[@"mp4_480", @"mp4_720", @"mp4_360", @"mp4_240"];
    for (NSString *key in keys) {
        id url = files[key];
        if ([url isKindOfClass:[NSString class]] && [url length] > 0) return url;
    }
    for (NSString *key in @[@"external", @"mp4_144"]) {
        id url = files[key];
        if ([url isKindOfClass:[NSString class]] && [url length] > 0) return url;
    }
    return nil;
}

#pragma mark - Скачивание

- (void)downloadAndPlayVideo:(NSString *)urlString {
    if ([urlString hasPrefix:@"/"]) {
        urlString = [NSString stringWithFormat:@"https://api.openvk.org%@", urlString];
    }
    statusLabel.hidden = NO;
    statusLabel.text = @"Скачивание видео...";
    progressLabel.hidden = NO;
    progressLabel.text = @"0%";
    [spinner startAnimating];
    
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) { [self showError:@"Неверный URL"]; return; }
    
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url
                                                       cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                   timeoutInterval:60.0];
    [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
    [req setValue:@"https://openvk.org/" forHTTPHeaderField:@"Referer"];
    NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:url];
    if (cookies.count > 0) {
        NSDictionary *cookieHeaders = [NSHTTPCookie requestHeaderFieldsWithCookies:cookies];
        for (NSString *key in cookieHeaders) {
            [req setValue:cookieHeaders[key] forHTTPHeaderField:key];
        }
    }
    
    videoData = [NSMutableData data];
    receivedBytes = 0;
    expectedBytes = 0;
    
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:req delegate:self startImmediately:NO];
    [connection scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    [connection start];
}

#pragma mark - NSURLConnectionDataDelegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
        NSHTTPURLResponse *httpResp = (NSHTTPURLResponse *)response;
        expectedBytes = [httpResp expectedContentLength];
        NSLog(@"📥 [Video] HTTP %ld, size: %lld", (long)httpResp.statusCode, expectedBytes);
        if (httpResp.statusCode != 200) {
            [connection cancel];
            [self showError:[NSString stringWithFormat:@"Ошибка %ld", (long)httpResp.statusCode]];
            return;
        }
    }
    [videoData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [videoData appendData:data];
    receivedBytes += data.length;
    if (expectedBytes > 0) {
        CGFloat percent = (CGFloat)receivedBytes / (CGFloat)expectedBytes;
        dispatch_async(dispatch_get_main_queue(), ^{
            progressLabel.text = [NSString stringWithFormat:@"%.0f%%  (%.1f МБ)",
                                  percent * 100, receivedBytes / 1024.0 / 1024.0];
        });
    }
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSLog(@"✅ [Video] Скачано %lu байт", (unsigned long)videoData.length);
    if (videoData.length < 1000) {
        [self showError:@"Пустой ответ"];
        return;
    }
    NSString *tempPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"ovk_video.mp4"];
    [videoData writeToFile:tempPath atomically:YES];
    videoData = nil;
    
    [spinner stopAnimating];
    statusLabel.hidden = YES;
    progressLabel.hidden = YES;
    
    [self startEmbeddedPlayer:tempPath];
    [self loadComments];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"❌ [Video] Download error: %@", error);
    [self showError:[NSString stringWithFormat:@"Ошибка: %@", error.localizedDescription]];
}

#pragma mark - Встроенный плеер

- (void)startEmbeddedPlayer:(NSString *)path {
    NSError *error = nil;
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setCategory:AVAudioSessionCategoryPlayback error:&error];
    [session setActive:YES error:&error];
    
    NSURL *url = [NSURL fileURLWithPath:path];
    moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:url];
    moviePlayer.movieSourceType = MPMovieSourceTypeFile;
    moviePlayer.controlStyle = MPMovieControlStyleDefault;
    moviePlayer.shouldAutoplay = YES;
    moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    moviePlayer.view.frame = playerContainer.bounds;
    moviePlayer.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    if ([moviePlayer respondsToSelector:@selector(setUseApplicationAudioSession:)]) {
        moviePlayer.useApplicationAudioSession = NO;
    }
    
    [playerContainer addSubview:moviePlayer.view];
    
    [moviePlayer prepareToPlay];
    [moviePlayer play];
}

#pragma mark - Загрузка комментариев

- (void)loadComments {
    if (isLoadingComments) return;
    isLoadingComments = YES;
    
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *urlString = [NSString stringWithFormat:
                           @"%@video.getComments?owner_id=%@&video_id=%@&count=20&extended=1&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], ownerId, videoId, token];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            isLoadingComments = NO;
            if (error || ![json isKindOfClass:[NSDictionary class]] || json[@"error"]) {
                return;
            }
            NSDictionary *response = json[@"response"];
            NSArray *items = response[@"items"];
            if (![items isKindOfClass:[NSArray class]]) items = @[];
            [comments removeAllObjects];
            [comments addObjectsFromArray:items];
            
            NSArray *profilesArray = response[@"profiles"];
            if ([profilesArray isKindOfClass:[NSArray class]]) {
                for (NSDictionary *p in profilesArray) {
                    if (![p isKindOfClass:[NSDictionary class]]) continue;
                    id pid = [p objectForKey:@"id"];
                    if (pid) [profiles setObject:p forKey:[pid stringValue]];
                }
            }
            [commentsTableView reloadData];
            [self updateScrollContentSize];
        });
    });
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return comments.count;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"InlineCommentCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    UIImageView *commentAvatar;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        
        commentAvatar = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 40, 40)];
        commentAvatar.tag = 950;
        commentAvatar.contentMode = UIViewContentModeScaleAspectFill;
        commentAvatar.clipsToBounds = YES;
        commentAvatar.layer.cornerRadius = 4;
        commentAvatar.layer.borderWidth = 1;
        commentAvatar.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
        commentAvatar.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        [cell.contentView addSubview:commentAvatar];
        
        cell.textLabel.font = [UIFont boldSystemFontOfSize:12];
        cell.textLabel.textColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [ThemeManager cellTextColor];
        cell.detailTextLabel.numberOfLines = 3;
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        
        cell.indentationWidth = 55;
        cell.indentationLevel = 1;
    } else {
        commentAvatar = (UIImageView *)[cell.contentView viewWithTag:950];
    }
    
    commentAvatar.image = [UIImage imageNamed:@"default_avatar"];
    cell.textLabel.text = @"";
    cell.detailTextLabel.text = @"";
    
    if (indexPath.row >= comments.count) return cell;
    NSDictionary *comment = comments[indexPath.row];
    if (![comment isKindOfClass:[NSDictionary class]]) return cell;
    
    NSString *fromId = [[comment objectForKey:@"from_id"] stringValue];
    NSDictionary *profile = [profiles objectForKey:fromId];
    NSString *name = @"Пользователь";
    NSString *avatarURL = nil;
    if ([profile isKindOfClass:[NSDictionary class]]) {
        name = [NSString stringWithFormat:@"%@ %@",
                [profile objectForKey:@"first_name"] ?: @"",
                [profile objectForKey:@"last_name"] ?: @""];
        avatarURL = [profile objectForKey:@"photo_50"];
    }
    cell.textLabel.text = name;
    cell.detailTextLabel.text = [comment objectForKey:@"text"] ?: @"";
    
    if (avatarURL) {
        UIImage *cached = [avatarCache objectForKey:avatarURL];
        if (cached) commentAvatar.image = cached;
        else {
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    [avatarCache setObject:image forKey:avatarURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                        if (c) {
                            UIImageView *iv = (UIImageView *)[c.contentView viewWithTag:950];
                            if (iv) iv.image = image;
                        }
                    });
                }
            }];
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= comments.count) return;
    NSDictionary *comment = comments[indexPath.row];
    NSString *fromId = [[comment objectForKey:@"from_id"] stringValue];
    if (fromId.length > 0 && [fromId integerValue] > 0) {
        ProfileViewController *pvc = [[ProfileViewController alloc] initWithUserId:fromId];
        [self.navigationController pushViewController:pvc animated:YES];
    }
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self sendCommentTapped];
    return YES;
}

#pragma mark - Keyboard

- (void)keyboardWillShow:(NSNotification *)note {
    CGRect kbFrame = [[note.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat kbHeight = kbFrame.size.height;
    NSTimeInterval duration = [[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect f = inputBar.frame;
        f.origin.y = self.view.bounds.size.height - kbHeight - 44;
        inputBar.frame = f;
        CGRect sf = scrollView.frame;
        sf.size.height = self.view.bounds.size.height - sf.origin.y - 44 - kbHeight;
        scrollView.frame = sf;
    }];
}

- (void)keyboardWillHide:(NSNotification *)note {
    NSTimeInterval duration = [[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect f = inputBar.frame;
        f.origin.y = self.view.bounds.size.height - 44;
        inputBar.frame = f;
        CGRect sf = scrollView.frame;
        sf.size.height = self.view.bounds.size.height - sf.origin.y - 44;
        scrollView.frame = sf;
    }];
}

#pragma mark - Ошибки

- (void)showError:(NSString *)message {
    NSLog(@"❌ [Video] %@", message);
    [spinner stopAnimating];
    statusLabel.hidden = NO;
    statusLabel.text = message;
    progressLabel.hidden = YES;
}

@end