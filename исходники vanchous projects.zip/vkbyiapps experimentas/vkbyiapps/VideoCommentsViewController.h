// VideoCommentsViewController.h
#import <UIKit/UIKit.h>

@interface VideoCommentsViewController : UIViewController
- (instancetype)initWithOwnerId:(NSString *)ownerId videoId:(NSString *)videoId;
@end