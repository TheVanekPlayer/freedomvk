// PostDetailViewController.h
#import <UIKit/UIKit.h>

@class SideMenuViewController;

@interface PostDetailViewController : UIViewController
@property (nonatomic, unsafe_unretained) SideMenuViewController *sideMenuController;
@property (nonatomic, strong) NSDictionary *profiles;
- (instancetype)initWithPost:(NSDictionary *)post;
@end