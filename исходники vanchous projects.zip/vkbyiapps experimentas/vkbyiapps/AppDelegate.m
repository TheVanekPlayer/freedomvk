// AppDelegate.m
#import "AppDelegate.h"
#import "LoginViewController.h"
#import "SideMenuViewController.h"
#import "VKAPIClient.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>
#import <AVFoundation/AVFoundation.h>

@implementation NSURLRequest (IgnoreSSL)
+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host { return YES; }
@end

@interface AppDelegate ()
@property (strong, nonatomic) NSTimer *badgeTimer;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    // Настройка звука для всего приложения
    NSError *audioError = nil;
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayback error:&audioError];
    [audioSession setActive:YES error:&audioError];
    NSLog(@"🔊 AppDelegate: AudioSession category = %@", [audioSession category]);
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [ThemeManager applyThemeToWindow:self.window];
    
    // Стилизация навбара
    UIColor *topColor = [ThemeManager navigationBarTopColor];
    UIColor *bottomColor = [ThemeManager navigationBarBottomColor];
    UIImage *navBg = [self navigationBarBackgroundImageWithTopColor:topColor bottomColor:bottomColor];
    [[UINavigationBar appearance] setBackgroundImage:navBg forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
    [[UINavigationBar appearance] setTintColor:[ThemeManager navigationBarTintColor]];
    [[UINavigationBar appearance] setTitleTextAttributes:@{
                                                           UITextAttributeFont: [UIFont fontWithName:@"HelveticaNeue-Bold" size:20],
                                                           UITextAttributeTextColor: [ThemeManager navigationBarTitleColor],
                                                           UITextAttributeTextShadowColor: [UIColor colorWithWhite:0.0 alpha:0.5],
                                                           UITextAttributeTextShadowOffset: [NSValue valueWithUIOffset:UIOffsetMake(0, -1)]
                                                           }];
    [[UINavigationBar appearance] setBarStyle:UIBarStyleBlack];
    
    [[UITableView appearance] setBackgroundColor:[UIColor clearColor]];
    [[UITableView appearance] setBackgroundView:nil];
    
    // Стартовый экран
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    UIViewController *rootController;
    if (token.length > 0) {
        rootController = [[SideMenuViewController alloc] init];
    } else {
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        rootController = [[UINavigationController alloc] initWithRootViewController:loginVC];
    }
    self.window.rootViewController = rootController;
    [self.window makeKeyAndVisible];
    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound)];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
    
    [self updateBadgeCount];
    [self startBadgeTimer];
    
    return YES;
}

#pragma mark - Lifecycle

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [self updateBadgeCount];
    [self startBadgeTimer];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    [self stopBadgeTimer];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    [self updateBadgeCount];
    [self startBadgeTimer];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self stopBadgeTimer];
}

#pragma mark - Badge

- (void)startBadgeTimer {
    [self.badgeTimer invalidate];
    self.badgeTimer = [NSTimer scheduledTimerWithTimeInterval:30.0
                                                       target:self
                                                     selector:@selector(updateBadgeCount)
                                                     userInfo:nil
                                                      repeats:YES];
}

- (void)stopBadgeTimer {
    [self.badgeTimer invalidate];
    self.badgeTimer = nil;
}

- (void)updateBadgeCount {
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    if (!token) return;
    
    NSString *urlString = [NSString stringWithFormat:@"%@messages.getConversations?count=1&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!error && json[@"response"]) {
                NSInteger unread = [json[@"response"][@"unread_count"] integerValue];
                [UIApplication sharedApplication].applicationIconBadgeNumber = unread;
            }
        });
    });
}

#pragma mark - Theme

- (void)themeDidChange:(NSNotification *)notification {
    [ThemeManager applyThemeToWindow:self.window];
    UIColor *topColor = [ThemeManager navigationBarTopColor];
    UIColor *bottomColor = [ThemeManager navigationBarBottomColor];
    UIImage *navBg = [self navigationBarBackgroundImageWithTopColor:topColor bottomColor:bottomColor];
    [[UINavigationBar appearance] setBackgroundImage:navBg forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setTintColor:[ThemeManager navigationBarTintColor]];
    [[UINavigationBar appearance] setTitleTextAttributes:@{
                                                           UITextAttributeFont: [UIFont fontWithName:@"HelveticaNeue-Bold" size:20],
                                                           UITextAttributeTextColor: [ThemeManager navigationBarTitleColor],
                                                           UITextAttributeTextShadowColor: [UIColor colorWithWhite:0.0 alpha:0.5],
                                                           UITextAttributeTextShadowOffset: [NSValue valueWithUIOffset:UIOffsetMake(0, -1)]
                                                           }];
}

- (UIImage *)navigationBarBackgroundImageWithTopColor:(UIColor *)topColor bottomColor:(UIColor *)bottomColor {
    UIImage *headerImage = [UIImage imageNamed:@"header.png"];
    if (headerImage) {
        UIGraphicsBeginImageContextWithOptions(CGSizeMake(1, 44), NO, 0);
        [headerImage drawInRect:CGRectMake(0, 0, 1, 44)];
        UIImage *resized = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        return [resized resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    }
    
    CGRect rect = CGRectMake(0, 0, 1, 44);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGFloat locations[] = {0.0, 1.0};
    NSArray *colors = @[(id)topColor.CGColor, (id)bottomColor.CGColor];
    CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)colors, locations);
    CGContextDrawLinearGradient(context, gradient, CGPointMake(0, 0), CGPointMake(0, rect.size.height), 0);
    CGGradientRelease(gradient);
    CGColorSpaceRelease(colorSpace);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

#pragma mark - Push

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    const unsigned char *dataBuffer = (const unsigned char *)[deviceToken bytes];
    NSMutableString *hexString = [NSMutableString stringWithCapacity:([deviceToken length] * 2)];
    for (NSUInteger i = 0; i < [deviceToken length]; ++i) {
        [hexString appendFormat:@"%02x", dataBuffer[i]];
    }
    NSString *token = [hexString copy];
    [[VKAPIClient sharedClient] registerDeviceWithToken:token completion:^(BOOL success, NSError *error) {}];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"Push fail: %@", error);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    [self updateBadgeCount];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NewMessageNotification" object:nil];
}

@end