// FeedViewController.m
#import "FeedViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "PostDetailViewController.h"
#import "VideoPlayerViewController.h"
#import "CreatePostViewController.h"
#import "ProfileViewController.h"
#import "GroupWallViewController.h"
#import "FullscreenImageViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

@interface FeedViewController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *tableView;
    NSArray *posts;
    NSDictionary *profiles;
    NSDictionary *groups;
    UIActivityIndicatorView *spinner;
    NSMutableDictionary *imageCache;
    NSMutableDictionary *loadingURLs;
    BOOL optimizeMode;
}
@end

@implementation FeedViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Новости";
    self.view.backgroundColor = [ThemeManager backgroundColor];
    imageCache = [NSMutableDictionary dictionary];
    loadingURLs = [NSMutableDictionary dictionary];
    optimizeMode = [[NSUserDefaults standardUserDefaults] boolForKey:@"OptimizeMode"];
    
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:tableView];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    UIBarButtonItem *createBtn = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(createPostTapped)];
    self.navigationItem.rightBarButtonItem = createBtn;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
    
    [self loadFeed];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)themeDidChange:(NSNotification *)notification {
    self.view.backgroundColor = [ThemeManager backgroundColor];
    [tableView reloadData];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)createPostTapped {
    CreatePostViewController *postVC = [[CreatePostViewController alloc] init];
    [self.navigationController pushViewController:postVC animated:YES];
}

- (void)loadFeed {
    [spinner startAnimating];
    [[VKAPIClient sharedClient] getNewsfeedWithCompletion:^(NSArray *items, NSArray *profilesArray, NSArray *groupsArray, NSError *error) {
        [spinner stopAnimating];
        posts = [items isKindOfClass:[NSArray class]] ? items : @[];
        
        NSMutableDictionary *profDict = [NSMutableDictionary dictionary];
        for (NSDictionary *p in profilesArray) {
            if ([p isKindOfClass:[NSDictionary class]]) {
                id pid = [p objectForKey:@"id"];
                if (pid) [profDict setObject:p forKey:pid];
            }
        }
        profiles = profDict;
        
        NSMutableDictionary *groupDict = [NSMutableDictionary dictionary];
        for (NSDictionary *g in groupsArray) {
            if ([g isKindOfClass:[NSDictionary class]]) {
                id gid = [g objectForKey:@"id"];
                if (gid) [groupDict setObject:g forKey:gid];
            }
        }
        groups = groupDict;
        
        [loadingURLs removeAllObjects];
        [tableView reloadData];
    }];
}

#pragma mark - Вспомогательные

- (NSDictionary *)photoAttachmentFromPost:(NSDictionary *)post {
    if (![post isKindOfClass:[NSDictionary class]]) return nil;
    NSArray *attachments = [post objectForKey:@"attachments"];
    if ([attachments isKindOfClass:[NSArray class]]) {
        for (NSDictionary *att in attachments) {
            if (![att isKindOfClass:[NSDictionary class]]) continue;
            NSString *type = [att objectForKey:@"type"];
            if ([type isEqualToString:@"photo"] || [type isEqualToString:@"posted_photo"]) {
                NSDictionary *photo = [att objectForKey:@"photo"] ?: [att objectForKey:@"posted_photo"];
                if ([photo isKindOfClass:[NSDictionary class]]) return photo;
            }
        }
    }
    NSArray *copies = [post objectForKey:@"copy_history"];
    if ([copies isKindOfClass:[NSArray class]] && copies.count > 0) {
        return [self photoAttachmentFromPost:[copies objectAtIndex:0]];
    }
    NSDictionary *directPhoto = [post objectForKey:@"photo"];
    if ([directPhoto isKindOfClass:[NSDictionary class]]) return directPhoto;
    return nil;
}

- (NSDictionary *)videoAttachmentFromPost:(NSDictionary *)post {
    if (![post isKindOfClass:[NSDictionary class]]) return nil;
    NSArray *attachments = [post objectForKey:@"attachments"];
    if ([attachments isKindOfClass:[NSArray class]]) {
        for (NSDictionary *att in attachments) {
            if (![att isKindOfClass:[NSDictionary class]]) continue;
            if ([[att objectForKey:@"type"] isEqualToString:@"video"]) {
                return [att objectForKey:@"video"];
            }
        }
    }
    NSArray *copies = [post objectForKey:@"copy_history"];
    if ([copies isKindOfClass:[NSArray class]] && copies.count > 0) {
        return [self videoAttachmentFromPost:[copies objectAtIndex:0]];
    }
    return nil;
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return posts.count;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= posts.count) return 60;
    NSDictionary *post = [posts objectAtIndex:indexPath.row];
    NSString *text = [VKAPIClient postText:post];
    CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:14]
                       constrainedToSize:CGSizeMake(self.view.bounds.size.width - 80, CGFLOAT_MAX)
                           lineBreakMode:UILineBreakModeWordWrap];
    CGFloat height = 70 + textSize.height + 20;
    
    NSDictionary *photo = [self photoAttachmentFromPost:post];
    if (photo) height += 210;
    
    NSDictionary *video = [self videoAttachmentFromPost:post];
    if (video) height += 160;
    return height;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"PostCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    UIImageView *avatarView, *postImageView, *videoPreviewView;
    UILabel *sourceLabel, *textLabel, *timeLabel, *statsLabel;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        
        avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 50, 50)];
        avatarView.tag = 100;
        avatarView.contentMode = UIViewContentModeScaleAspectFill;
        avatarView.clipsToBounds = YES;
        avatarView.layer.cornerRadius = 4;
        avatarView.layer.borderWidth = 1;
        avatarView.layer.borderColor = [UIColor colorWithWhite:0.75 alpha:1.0].CGColor;
        avatarView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        avatarView.userInteractionEnabled = YES;
        UITapGestureRecognizer *avatarTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(avatarTapped:)];
        [avatarView addGestureRecognizer:avatarTap];
        [cell.contentView addSubview:avatarView];
        
        sourceLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 10, 220, 20)];
        sourceLabel.tag = 101;
        sourceLabel.font = [UIFont boldSystemFontOfSize:15];
        sourceLabel.textColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0];
        sourceLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:sourceLabel];
        
        timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 30, 120, 15)];
        timeLabel.tag = 102;
        timeLabel.font = [UIFont systemFontOfSize:11];
        timeLabel.textColor = [UIColor colorWithWhite:0.5 alpha:1.0];
        timeLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:timeLabel];
        
        statsLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.view.bounds.size.width - 120, 30, 110, 15)];
        statsLabel.tag = 103;
        statsLabel.font = [UIFont systemFontOfSize:11];
        statsLabel.textColor = [UIColor grayColor];
        statsLabel.backgroundColor = [UIColor clearColor];
        statsLabel.textAlignment = NSTextAlignmentRight;
        statsLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
        [cell.contentView addSubview:statsLabel];
        
        textLabel = [[UILabel alloc] init];
        textLabel.tag = 104;
        textLabel.numberOfLines = 0;
        textLabel.font = [UIFont systemFontOfSize:14];
        textLabel.textColor = [ThemeManager cellTextColor];
        textLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:textLabel];
        
        postImageView = [[UIImageView alloc] init];
        postImageView.tag = 105;
        postImageView.contentMode = UIViewContentModeScaleAspectFill;
        postImageView.clipsToBounds = YES;
        postImageView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        postImageView.layer.borderWidth = 1;
        postImageView.layer.borderColor = [UIColor colorWithWhite:0.75 alpha:1.0].CGColor;
        postImageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *photoTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoTapped:)];
        [postImageView addGestureRecognizer:photoTap];
        [cell.contentView addSubview:postImageView];
        
        videoPreviewView = [[UIImageView alloc] init];
        videoPreviewView.tag = 106;
        videoPreviewView.contentMode = UIViewContentModeScaleAspectFill;
        videoPreviewView.clipsToBounds = YES;
        videoPreviewView.userInteractionEnabled = YES;
        [cell.contentView addSubview:videoPreviewView];
        
        UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 1)];
        sep.tag = 900;
        sep.backgroundColor = [ThemeManager separatorColor];
        sep.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [cell.contentView addSubview:sep];
    } else {
        avatarView = (UIImageView *)[cell.contentView viewWithTag:100];
        sourceLabel = (UILabel *)[cell.contentView viewWithTag:101];
        timeLabel = (UILabel *)[cell.contentView viewWithTag:102];
        statsLabel = (UILabel *)[cell.contentView viewWithTag:103];
        textLabel = (UILabel *)[cell.contentView viewWithTag:104];
        postImageView = (UIImageView *)[cell.contentView viewWithTag:105];
        videoPreviewView = (UIImageView *)[cell.contentView viewWithTag:106];
    }
    
    // СБРОС
    postImageView.image = nil;
    postImageView.hidden = YES;
    videoPreviewView.image = nil;
    videoPreviewView.hidden = YES;
    avatarView.image = [UIImage imageNamed:@"default_avatar"];
    sourceLabel.text = @"";
    timeLabel.text = @"";
    statsLabel.text = @"";
    textLabel.text = @"";
    for (UIGestureRecognizer *gr in videoPreviewView.gestureRecognizers) {
        [videoPreviewView removeGestureRecognizer:gr];
    }
    
    if (indexPath.row >= posts.count) return cell;
    NSDictionary *post = [posts objectAtIndex:indexPath.row];
    if (![post isKindOfClass:[NSDictionary class]]) return cell;
    
    NSString *sourceName = @"";
    NSString *avatarURL = nil;
    NSInteger sourceId = [[post objectForKey:@"source_id"] integerValue];
    if (sourceId == 0) sourceId = [[post objectForKey:@"owner_id"] integerValue];
    
    if (sourceId > 0) {
        NSNumber *pid = [NSNumber numberWithInteger:sourceId];
        NSDictionary *profile = [profiles objectForKey:pid];
        if (!profile) profile = [profiles objectForKey:[NSNumber numberWithLongLong:sourceId]];
        if ([profile isKindOfClass:[NSDictionary class]]) {
            sourceName = [NSString stringWithFormat:@"%@ %@", [profile objectForKey:@"first_name"] ?: @"", [profile objectForKey:@"last_name"] ?: @""];
            avatarURL = [profile objectForKey:@"photo_100"] ?: [profile objectForKey:@"photo_50"] ?: [profile objectForKey:@"photo_200"];
        }
    } else if (sourceId < 0) {
        NSNumber *gid = [NSNumber numberWithInteger:-sourceId];
        NSDictionary *group = [groups objectForKey:gid];
        if ([group isKindOfClass:[NSDictionary class]]) {
            sourceName = [group objectForKey:@"name"] ?: @"Сообщество";
            avatarURL = [group objectForKey:@"photo_100"] ?: [group objectForKey:@"photo_50"] ?: [group objectForKey:@"photo_200"];
        }
    }
    sourceLabel.text = sourceName;
    
    if ([avatarURL isKindOfClass:[NSString class]] && avatarURL.length > 0) {
        UIImage *cached = [imageCache objectForKey:avatarURL];
        if (cached) {
            avatarView.image = cached;
        } else {
            NSString *cellURL = [avatarURL copy];
            NSString *cellName = [sourceName copy];
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    [imageCache setObject:image forKey:cellURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                        if (c) {
                            UILabel *sl = (UILabel *)[c.contentView viewWithTag:101];
                            if ([sl.text isEqualToString:cellName]) {
                                UIImageView *av = (UIImageView *)[c.contentView viewWithTag:100];
                                av.image = image;
                            }
                        }
                    });
                }
            }];
        }
    }
    
    NSTimeInterval ts = [[post objectForKey:@"date"] doubleValue];
    NSDate *d = [NSDate dateWithTimeIntervalSince1970:ts];
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    df.dateFormat = @"dd.MM HH:mm";
    timeLabel.text = [df stringFromDate:d];
    
    NSNumber *likes = [[post objectForKey:@"likes"] objectForKey:@"count"];
    NSNumber *comments = [[post objectForKey:@"comments"] objectForKey:@"count"];
    statsLabel.text = [NSString stringWithFormat:@"❤ %@  ✉ %@", likes ?: @"0", comments ?: @"0"];
    
    NSString *fullText = [VKAPIClient postText:post];
    textLabel.text = fullText;
    CGSize textSize = [fullText sizeWithFont:[UIFont systemFontOfSize:14]
                           constrainedToSize:CGSizeMake(self.view.bounds.size.width - 80, CGFLOAT_MAX)
                               lineBreakMode:UILineBreakModeWordWrap];
    textLabel.frame = CGRectMake(70, 50, self.view.bounds.size.width - 80, textSize.height);
    
    CGFloat attachmentY = 50 + textSize.height + 10;
    
    // ФОТО
    NSDictionary *photo = [self photoAttachmentFromPost:post];
    if (photo) {
        postImageView.hidden = NO;
        postImageView.frame = CGRectMake(70, attachmentY, self.view.bounds.size.width - 80, 200);
        NSString *photoURL = [VKAPIClient bestPhotoURL:photo];
        if ([photoURL isKindOfClass:[NSString class]] && photoURL.length > 0) {
            UIImage *cached = [imageCache objectForKey:photoURL];
            if (cached) {
                postImageView.image = cached;
            } else {
                [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                    if (image) {
                        [imageCache setObject:image forKey:photoURL];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                            if (c) {
                                UIImageView *iv = (UIImageView *)[c.contentView viewWithTag:105];
                                iv.image = image;
                            }
                        });
                    }
                }];
            }
        }
        attachmentY += 210;
    }
    
    // ВИДЕО
    NSDictionary *video = [self videoAttachmentFromPost:post];
    if (video) {
        videoPreviewView.hidden = NO;
        videoPreviewView.frame = CGRectMake(70, attachmentY, self.view.bounds.size.width - 80, 150);
        NSString *previewURL = [video objectForKey:@"photo_320"] ?: [video objectForKey:@"photo_130"];
        if ([previewURL isKindOfClass:[NSString class]] && previewURL.length > 0) {
            UIImage *cached = [imageCache objectForKey:previewURL];
            if (cached) {
                videoPreviewView.image = cached;
            } else {
                [[VKAPIClient sharedClient] downloadImageWithURL:previewURL completion:^(UIImage *image) {
                    if (image) {
                        [imageCache setObject:image forKey:previewURL];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                            if (c) {
                                UIImageView *iv = (UIImageView *)[c.contentView viewWithTag:106];
                                iv.image = image;
                            }
                        });
                    }
                }];
            }
        }
        UIImageView *playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"play_icon"]];
        playIcon.contentMode = UIViewContentModeCenter;
        playIcon.frame = videoPreviewView.bounds;
        [videoPreviewView addSubview:playIcon];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playVideoFromPost:)];
        objc_setAssociatedObject(tap, "ownerId", [video objectForKey:@"owner_id"], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(tap, "videoId", [video objectForKey:@"id"], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [videoPreviewView addGestureRecognizer:tap];
        attachmentY += 160;
    }
    
    UIView *sep = [cell.contentView viewWithTag:900];
    sep.frame = CGRectMake(0, attachmentY + 5, tableView.bounds.size.width, 1);
    
    return cell;
}

#pragma mark - Tap

- (void)avatarTapped:(UITapGestureRecognizer *)gesture {
    UIImageView *view = (UIImageView *)gesture.view;
    UITableViewCell *cell = (UITableViewCell *)[[view superview] superview];
    NSIndexPath *indexPath = [tableView indexPathForCell:cell];
    if (!indexPath || indexPath.row >= posts.count) return;
    NSDictionary *post = [posts objectAtIndex:indexPath.row];
    NSInteger sourceId = [[post objectForKey:@"source_id"] integerValue];
    if (sourceId == 0) sourceId = [[post objectForKey:@"owner_id"] integerValue];
    
    if (sourceId > 0) {
        ProfileViewController *pvc = [[ProfileViewController alloc] initWithUserId:[NSString stringWithFormat:@"%ld", (long)sourceId]];
        pvc.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:pvc animated:YES];
    } else if (sourceId < 0) {
        NSString *gid = [NSString stringWithFormat:@"%ld", (long)(-sourceId)];
        NSDictionary *group = [groups objectForKey:[NSNumber numberWithInteger:-sourceId]];
        NSString *name = [group objectForKey:@"name"] ?: @"Группа";
        NSString *avatarURL = [group objectForKey:@"photo_50"];
        GroupWallViewController *wallVC = [[GroupWallViewController alloc] initWithGroupId:gid name:name avatarURL:avatarURL];
        wallVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:wallVC animated:YES];
    }
}

- (void)photoTapped:(UITapGestureRecognizer *)gesture {
    UIImageView *iv = (UIImageView *)gesture.view;
    if (!iv.image) return;
    FullscreenImageViewController *fs = [[FullscreenImageViewController alloc] initWithImage:iv.image];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:fs];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)playVideoFromPost:(UITapGestureRecognizer *)gesture {
    NSString *ownerId = objc_getAssociatedObject(gesture, "ownerId");
    NSString *videoId = objc_getAssociatedObject(gesture, "videoId");
    if (!ownerId || !videoId) return;
    @try {
        VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
        [self.navigationController pushViewController:playerVC animated:YES];
    } @catch (NSException *e) {}
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= posts.count) return;
    NSDictionary *post = [posts objectAtIndex:indexPath.row];
    NSDictionary *video = [self videoAttachmentFromPost:post];
    if (video) {
        NSString *ownerId = [[video objectForKey:@"owner_id"] stringValue];
        NSString *videoId = [[video objectForKey:@"id"] stringValue];
        VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
        [self.navigationController pushViewController:playerVC animated:YES];
        return;
    }
    PostDetailViewController *detailVC = [[PostDetailViewController alloc] initWithPost:post];
    [self.navigationController pushViewController:detailVC animated:YES];
}

@end