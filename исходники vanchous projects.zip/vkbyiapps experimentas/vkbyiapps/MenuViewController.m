// MenuViewController.m
#import "MenuViewController.h"
#import "SideMenuViewController.h"
#import "VKAPIClient.h"
#import <QuartzCore/QuartzCore.h>

@interface MenuViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *menuItems;
@property (nonatomic, strong) NSArray *menuIcons;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UIImageView *avatarImageView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@end

@implementation MenuViewController

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor colorWithWhite:0.12 alpha:1.0];
    self.menuItems = @[@"Моя страница", @"Новости", @"Друзья", @"Фотографии", @"Видеозаписи", @"Аудиозаписи", @"Сообщения", @"Группы", @"Поиск", @"Настройки"];
    self.menuIcons = @[@"menu_profile", @"menu_news", @"menu_friends", @"menu_photos", @"menu_videos", @"menu_audio", @"menu_messages", @"menu_groups", @"menu_search", @"menu_settings"];
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorColor = [UIColor colorWithWhite:0.25 alpha:1.0];
    [self.view addSubview:self.tableView];
    
    [self setupHeaderView];
    [self loadUserInfo];
}

- (void)setupHeaderView {
    self.headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 80)];
    self.headerView.backgroundColor = [UIColor colorWithWhite:0.18 alpha:1.0];
    
    self.avatarImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 50, 50)];
    self.avatarImageView.layer.cornerRadius = 0;
    self.avatarImageView.clipsToBounds = YES;
    self.avatarImageView.backgroundColor = [UIColor lightGrayColor];
    self.avatarImageView.image = [UIImage imageNamed:@"default_avatar"];
    [self.headerView addSubview:self.avatarImageView];
    
    self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(75, 15, self.view.bounds.size.width - 90, 22)];
    self.nameLabel.font = [UIFont boldSystemFontOfSize:16];
    self.nameLabel.textColor = [UIColor whiteColor];
    self.nameLabel.shadowColor = [UIColor blackColor];
    self.nameLabel.shadowOffset = CGSizeMake(0, 1);
    self.nameLabel.backgroundColor = [UIColor clearColor];
    self.nameLabel.text = @"Загрузка...";
    [self.headerView addSubview:self.nameLabel];
    
    self.statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(75, 40, self.view.bounds.size.width - 90, 16)];
    self.statusLabel.font = [UIFont systemFontOfSize:12];
    self.statusLabel.textColor = [UIColor lightGrayColor];
    self.statusLabel.backgroundColor = [UIColor clearColor];
    self.statusLabel.text = @"";
    [self.headerView addSubview:self.statusLabel];
    
    self.tableView.tableHeaderView = self.headerView;
}

- (void)loadUserInfo {
    NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    if (!userId) return;
    [[VKAPIClient sharedClient] profileGetInfoWithUserId:userId completion:^(NSDictionary *userInfo, NSError *error) {
        if (error || !userInfo) return;
        NSString *firstName = userInfo[@"first_name"] ?: @"";
        NSString *lastName = userInfo[@"last_name"] ?: @"";
        self.nameLabel.text = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
        NSNumber *online = userInfo[@"online"];
        if ([online boolValue]) {
            self.statusLabel.text = @"онлайн";
            self.statusLabel.textColor = [UIColor colorWithRed:0.6 green:1.0 blue:0.6 alpha:1.0];
        } else {
            self.statusLabel.text = @"";
        }
        NSString *avatarURL = userInfo[@"photo_50"] ?: userInfo[@"photo_100"];
        if (avatarURL) {
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.avatarImageView.image = image;
                    });
                }
            }];
        }
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.menuItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"MenuCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
        cell.textLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.7];
        cell.textLabel.shadowOffset = CGSizeMake(0, 1);
        cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.frame = CGRectMake(0,0,30,30);
    }
    cell.textLabel.text = self.menuItems[indexPath.row];
    cell.imageView.image = [UIImage imageNamed:self.menuIcons[indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.sideMenuController switchToViewControllerAtIndex:indexPath.row];
}

@end