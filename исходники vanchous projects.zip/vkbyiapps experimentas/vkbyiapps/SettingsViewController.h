// SettingsViewController.h
#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end