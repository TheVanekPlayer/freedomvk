// MusicPlayerManager.m
#import "MusicPlayerManager.h"

@interface MusicPlayerManager () {
    AVAudioPlayer *audioPlayer;
    BOOL _isPlaying;
    NSTimer *progressTimer;
    BOOL _seeking;
    NSInteger _generation;   // счётчик поколений запросов
    NSString *currentLoadingPath;
}
@end

@implementation MusicPlayerManager

+ (instancetype)sharedManager {
    static MusicPlayerManager *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _currentIndex = -1;
        _isPlaying = NO;
        _playlist = @[];
        _generation = 0;
        
        NSError *sessionError = nil;
        AVAudioSession *session = [AVAudioSession sharedInstance];
        [session setCategory:AVAudioSessionCategoryPlayback error:&sessionError];
        [session setActive:YES error:&sessionError];
        if (sessionError) {
            NSLog(@"MusicPlayerManager audio session error: %@", sessionError);
        }
    }
    return self;
}

- (BOOL)isPlaying { return _isPlaying; }

- (NSDictionary *)currentTrack {
    if (_currentIndex >= 0 && _currentIndex < (NSInteger)self.playlist.count) {
        return [self.playlist objectAtIndex:_currentIndex];
    }
    return nil;
}

- (NSTimeInterval)currentTime {
    return audioPlayer ? audioPlayer.currentTime : 0;
}

- (NSTimeInterval)duration {
    return audioPlayer ? audioPlayer.duration : 0;
}

#pragma mark - Playback

- (void)playTrackAtIndex:(NSInteger)index playlist:(NSArray *)newPlaylist {
    if (![newPlaylist isKindOfClass:[NSArray class]]) return;
    if (index < 0 || index >= (NSInteger)newPlaylist.count) return;
    
    self.playlist = newPlaylist;
    _currentIndex = index;
    _generation++;                 // новое поколение — все старые загрузки невалидны
    NSInteger myGeneration = _generation;
    NSInteger myIndex = index;
    
    NSDictionary *track = [newPlaylist objectAtIndex:index];
    if (![track isKindOfClass:[NSDictionary class]]) return;
    
    NSString *urlString = [track objectForKey:@"url"] ?: [track objectForKey:@"src"];
    if (![urlString isKindOfClass:[NSString class]] || urlString.length == 0) {
        [self nextTrack];
        return;
    }
    if ([urlString hasPrefix:@"/"]) {
        urlString = [NSString stringWithFormat:@"https://api.openvk.org%@", urlString];
    }
    
    // Останавливаем то, что играло
    if (audioPlayer) {
        [audioPlayer stop];
        audioPlayer = nil;
    }
    [self stopProgressTimer];
    _isPlaying = NO;
    
    // Уведомляем delegate
    if ([self.delegate respondsToSelector:@selector(musicPlayerDidChangeTrack:)]) {
        [self.delegate musicPlayerDidChangeTrack:track];
    }
    // Уведомляем весь UI
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerTrackChanged"
                                                        object:nil
                                                      userInfo:@{@"track": track}];
    
    NSString *localURLString = [urlString copy];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSData *audioData = [NSData dataWithContentsOfURL:[NSURL URLWithString:localURLString]];
        
        // ==== Проверка поколения: если пока грузили — пришёл другой запрос, отменяемся ====
        if (self->_generation != myGeneration) {
            NSLog(@"🎵 [Music] Пропущена устаревшая загрузка (gen %ld -> %ld)",
                  (long)myGeneration, (long)self->_generation);
            return;
        }
        
        if (!audioData || audioData.length == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (self->_generation != myGeneration) return;
                [self nextTrack];
            });
            return;
        }
        
        // Уникальный путь с учётом поколения — чтобы две загрузки одного трека не пересекались
        NSString *tempPath = [NSTemporaryDirectory() stringByAppendingPathComponent:
                              [NSString stringWithFormat:@"ovk_track_gen%ld_idx%ld.mp3",
                               (long)myGeneration, (long)myIndex]];
        [audioData writeToFile:tempPath atomically:YES];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            // Повторная проверка на главном потоке
            if (self->_generation != myGeneration) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:nil];
                return;
            }
            
            // Останавливаем предыдущий плеер (если ещё остался)
            if (audioPlayer) {
                [audioPlayer stop];
                audioPlayer = nil;
            }
            
            NSError *error = nil;
            audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:tempPath]
                                                                 error:&error];
            if (error || !audioPlayer) {
                NSLog(@"MusicPlayer error: %@", error);
                [self nextTrack];
                return;
            }
            
            audioPlayer.delegate = self;
            [audioPlayer prepareToPlay];
            
            BOOL started = [audioPlayer play];
            if (!started) {
                NSLog(@"MusicPlayer: play() returned NO");
                [self nextTrack];
                return;
            }
            
            _isPlaying = YES;
            [self startProgressTimer];
            
            // Чистим старые временные файлы (кроме текущего)
            [self cleanupTempFilesExcept:tempPath];
            
            if ([self.delegate respondsToSelector:@selector(musicPlayerDidChangePlayState:)]) {
                [self.delegate musicPlayerDidChangePlayState:YES];
            }
            [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerPlayStateChanged"
                                                                object:nil
                                                              userInfo:@{@"isPlaying": @YES}];
        });
    });
}

- (void)togglePlayPause {
    if (!audioPlayer) return;
    if (_isPlaying) {
        [audioPlayer pause];
        _isPlaying = NO;
        [self stopProgressTimer];
    } else {
        [audioPlayer play];
        _isPlaying = YES;
        [self startProgressTimer];
    }
    
    if ([self.delegate respondsToSelector:@selector(musicPlayerDidChangePlayState:)]) {
        [self.delegate musicPlayerDidChangePlayState:_isPlaying];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerPlayStateChanged"
                                                        object:nil
                                                      userInfo:@{@"isPlaying": @(_isPlaying)}];
}

- (void)nextTrack {
    if (self.playlist.count == 0) return;
    NSInteger next = _currentIndex + 1;
    if (next >= (NSInteger)self.playlist.count) next = 0;
    [self playTrackAtIndex:next playlist:self.playlist];
}

- (void)previousTrack {
    if (self.playlist.count == 0) return;
    NSInteger prev = _currentIndex - 1;
    if (prev < 0) prev = self.playlist.count - 1;
    [self playTrackAtIndex:prev playlist:self.playlist];
}

- (void)stop {
    _generation++;   // инвалидируем все активные загрузки
    
    if (audioPlayer) {
        [audioPlayer stop];
        audioPlayer = nil;
    }
    [self stopProgressTimer];
    _isPlaying = NO;
    _currentIndex = -1;
    
    [self cleanupTempFilesExcept:nil];
    
    if ([self.delegate respondsToSelector:@selector(musicPlayerDidChangeTrack:)]) {
        [self.delegate musicPlayerDidChangeTrack:nil];
    }
    if ([self.delegate respondsToSelector:@selector(musicPlayerDidChangePlayState:)]) {
        [self.delegate musicPlayerDidChangePlayState:NO];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerTrackChanged"
                                                        object:nil
                                                      userInfo:@{@"track": [NSNull null]}];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerPlayStateChanged"
                                                        object:nil
                                                      userInfo:@{@"isPlaying": @NO}];
}

- (void)seekToProgress:(CGFloat)progress {
    if (!audioPlayer || audioPlayer.duration <= 0) return;
    if (progress < 0) progress = 0;
    if (progress > 1) progress = 1;
    
    _seeking = YES;
    audioPlayer.currentTime = progress * audioPlayer.duration;
    _seeking = NO;
    
    if ([self.delegate respondsToSelector:@selector(musicPlayerDidUpdateProgress:currentTime:duration:)]) {
        [self.delegate musicPlayerDidUpdateProgress:progress
                                        currentTime:audioPlayer.currentTime
                                           duration:audioPlayer.duration];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerProgressChanged"
                                                        object:nil
                                                      userInfo:@{@"progress": @(progress),
                                                                 @"current": @(audioPlayer.currentTime),
                                                                 @"duration": @(audioPlayer.duration)}];
}

#pragma mark - Temp files

- (void)cleanupTempFilesExcept:(NSString *)keepPath {
    NSString *tmp = NSTemporaryDirectory();
    NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:tmp error:nil];
    for (NSString *file in files) {
        if (![file hasPrefix:@"ovk_track_gen"]) continue;
        NSString *fullPath = [tmp stringByAppendingPathComponent:file];
        if (keepPath && [fullPath isEqualToString:keepPath]) continue;
        [[NSFileManager defaultManager] removeItemAtPath:fullPath error:nil];
    }
}

#pragma mark - Progress timer

- (void)startProgressTimer {
    [self stopProgressTimer];
    progressTimer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                                     target:self
                                                   selector:@selector(updateProgress)
                                                   userInfo:nil
                                                    repeats:YES];
}

- (void)stopProgressTimer {
    if (progressTimer) {
        [progressTimer invalidate];
        progressTimer = nil;
    }
}

- (void)updateProgress {
    if (!audioPlayer) return;
    if (audioPlayer.duration <= 0) return;
    if (_seeking) return;
    
    CGFloat progress = audioPlayer.currentTime / audioPlayer.duration;
    
    if ([self.delegate respondsToSelector:@selector(musicPlayerDidUpdateProgress:currentTime:duration:)]) {
        [self.delegate musicPlayerDidUpdateProgress:progress
                                        currentTime:audioPlayer.currentTime
                                           duration:audioPlayer.duration];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerProgressChanged"
                                                        object:nil
                                                      userInfo:@{@"progress": @(progress),
                                                                 @"current": @(audioPlayer.currentTime),
                                                                 @"duration": @(audioPlayer.duration)}];
}

#pragma mark - AVAudioPlayerDelegate

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
    [self stopProgressTimer];
    if (self.playlist.count > 1) {
        [self nextTrack];
    } else {
        _isPlaying = NO;
        if ([self.delegate respondsToSelector:@selector(musicPlayerDidChangePlayState:)]) {
            [self.delegate musicPlayerDidChangePlayState:NO];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicPlayerPlayStateChanged"
                                                            object:nil
                                                          userInfo:@{@"isPlaying": @NO}];
    }
}

- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error {
    NSLog(@"MusicPlayer decode error: %@", error);
    [self nextTrack];
}

@end