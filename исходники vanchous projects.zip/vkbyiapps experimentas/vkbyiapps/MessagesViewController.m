// MessagesViewController.m
#import "MessagesViewController.h"
#import "ChatViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface MessagesViewController () <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate> {
    UITableView *tableView;
    NSArray *conversations;
    NSDictionary *profiles;
    UIActivityIndicatorView *spinner;
    NSMutableDictionary *avatarCache;
    UIRefreshControl *refreshControl;
    UISearchBar *searchBar;
    NSArray *searchResults;
    BOOL isSearching;
}
@end

@implementation MessagesViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Сообщения";
    self.view.backgroundColor = [UIColor colorWithRed:0.93 green:0.94 blue:0.96 alpha:1.0];
    avatarCache = [NSMutableDictionary dictionary];
    isSearching = NO;
    conversations = @[];
    profiles = @{};
    searchResults = @[];
    
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 44)];
    searchBar.delegate = self;
    searchBar.placeholder = @"Поиск по сообщениям";
    searchBar.tintColor = [ThemeManager navigationBarTintColor];
    searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    searchBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    searchBar.backgroundImage = [[UIImage alloc] init];
    
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.rowHeight = 68;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.tableHeaderView = searchBar;
    [self.view addSubview:tableView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
    
    refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(loadConversations) forControlEvents:UIControlEventValueChanged];
    [tableView addSubview:refreshControl];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
    
    [self loadConversations];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)themeDidChange:(NSNotification *)notification {
    [tableView reloadData];
}

- (void)dismissKeyboard { [searchBar resignFirstResponder]; }

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

#pragma mark - Загрузка

- (void)loadConversations {
    [spinner startAnimating];
    [[VKAPIClient sharedClient] getConversationsWithCompletion:^(NSArray *items, NSDictionary *profs, NSError *error) {
        [spinner stopAnimating];
        [refreshControl endRefreshing];
        
        conversations = [items isKindOfClass:[NSArray class]] ? items : @[];
        profiles = [profs isKindOfClass:[NSDictionary class]] ? profs : @{};
        isSearching = NO;
        searchResults = @[];
        [tableView reloadData];
        
        if (conversations.count == 0) {
            UILabel *empty = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 100)];
            empty.text = @"Сообщений нет";
            empty.textAlignment = NSTextAlignmentCenter;
            empty.font = [UIFont systemFontOfSize:14];
            empty.textColor = [UIColor grayColor];
            empty.backgroundColor = [UIColor clearColor];
            tableView.backgroundView = empty;
        } else {
            tableView.backgroundView = nil;
        }
    }];
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)sb textDidChange:(NSString *)searchText {
    if (searchText.length == 0) {
        isSearching = NO;
        searchResults = @[];
        [tableView reloadData];
        return;
    }
    if (searchText.length < 3) return;
    isSearching = YES;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(doSearch:) object:nil];
    [self performSelector:@selector(doSearch:) withObject:searchText afterDelay:0.5];
}

- (void)doSearch:(NSString *)query {
    [[VKAPIClient sharedClient] searchMessagesWithQuery:query peerId:nil completion:^(NSArray *messages, NSError *error) {
        if (!error) {
            searchResults = [messages isKindOfClass:[NSArray class]] ? messages : @[];
            [tableView reloadData];
        }
    }];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)sb {
    [sb resignFirstResponder];
    if (sb.text.length > 0) [self doSearch:sb.text];
}

#pragma mark - Помощники

- (void)extractTitle:(NSString **)outTitle avatar:(NSString **)outAvatar fromConversation:(NSDictionary *)conv {
    NSString *title = @"Диалог";
    NSString *avatarURL = nil;
    
    NSDictionary *conversation = [conv objectForKey:@"conversation"];
    if (![conversation isKindOfClass:[NSDictionary class]]) {
        if (outTitle) *outTitle = title;
        if (outAvatar) *outAvatar = nil;
        return;
    }
    
    NSDictionary *chatSettings = [conversation objectForKey:@"chat_settings"];
    if ([chatSettings isKindOfClass:[NSDictionary class]]) {
        NSString *chatTitle = [chatSettings objectForKey:@"title"];
        if (chatTitle.length > 0) title = chatTitle;
        avatarURL = [chatSettings objectForKey:@"photo_100"]
        ?: [chatSettings objectForKey:@"photo_50"]
        ?: [chatSettings objectForKey:@"photo_200"];
    }
    
    NSDictionary *peer = [conversation objectForKey:@"peer"];
    if ([peer isKindOfClass:[NSDictionary class]]) {
        id uid = [peer objectForKey:@"id"];
        NSString *peerIdStr = nil;
        if ([uid isKindOfClass:[NSNumber class]]) peerIdStr = [uid stringValue];
        else if ([uid isKindOfClass:[NSString class]]) peerIdStr = uid;
        
        if (peerIdStr) {
            NSDictionary *profile = [profiles objectForKey:peerIdStr];
            if ([profile isKindOfClass:[NSDictionary class]]) {
                NSString *fn = [profile objectForKey:@"first_name"];
                NSString *ln = [profile objectForKey:@"last_name"];
                NSString *name = [profile objectForKey:@"name"];
                if (name.length > 0) {
                    title = name;
                } else if (fn || ln) {
                    title = [NSString stringWithFormat:@"%@ %@", fn ?: @"", ln ?: @""];
                }
                if (!avatarURL) {
                    avatarURL = [profile objectForKey:@"photo_100"]
                    ?: [profile objectForKey:@"photo_50"]
                    ?: [profile objectForKey:@"photo_200"];
                }
            }
        }
    }
    
    if (outTitle) *outTitle = title;
    if (outAvatar) *outAvatar = avatarURL;
}

- (NSString *)shortTimeForTimestamp:(NSTimeInterval)ts {
    if (ts <= 0) return @"";
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:ts];
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *components = [cal components:(NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit)
                                          fromDate:date
                                            toDate:[NSDate date]
                                           options:0];
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    if (components.day == 0) {
        df.dateFormat = @"HH:mm";
    } else if (components.day == 1) {
        return @"вчера";
    } else if (components.day < 7) {
        df.dateFormat = @"EEE";
    } else {
        df.dateFormat = @"dd.MM.yy";
    }
    return [df stringFromDate:date];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    if (isSearching) return searchResults.count;
    return conversations.count;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 68;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"ConversationCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellId];
    UIImageView *avatarView;
    UILabel *nameLabel;
    UILabel *msgLabel;
    UILabel *timeLabel;
    UIView *separator;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        
        // Аватар — квадратный со скруглением (как в VK 2010)
        avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 9, 50, 50)];
        avatarView.tag = 900;
        avatarView.contentMode = UIViewContentModeScaleAspectFill;
        avatarView.clipsToBounds = YES;
        avatarView.layer.cornerRadius = 4;
        avatarView.layer.borderWidth = 1;
        avatarView.layer.borderColor = [UIColor colorWithWhite:0.82 alpha:1.0].CGColor;
        avatarView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        [cell.contentView addSubview:avatarView];
        
        // Имя / название беседы (синее, жирное)
        nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 10, self.view.bounds.size.width - 130, 20)];
        nameLabel.tag = 901;
        nameLabel.font = [UIFont boldSystemFontOfSize:15];
        nameLabel.textColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0];
        nameLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:nameLabel];
        
        // Превью последнего сообщения
        msgLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 34, self.view.bounds.size.width - 130, 18)];
        msgLabel.tag = 902;
        msgLabel.font = [UIFont systemFontOfSize:12];
        msgLabel.textColor = [UIColor grayColor];
        msgLabel.backgroundColor = [UIColor clearColor];
        msgLabel.numberOfLines = 1;
        [cell.contentView addSubview:msgLabel];
        
        // Время справа сверху
        timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.view.bounds.size.width - 70, 10, 60, 16)];
        timeLabel.tag = 903;
        timeLabel.font = [UIFont systemFontOfSize:11];
        timeLabel.textColor = [UIColor colorWithWhite:0.55 alpha:1.0];
        timeLabel.textAlignment = NSTextAlignmentRight;
        timeLabel.backgroundColor = [UIColor clearColor];
        timeLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
        [cell.contentView addSubview:timeLabel];
        
        // Тонкий разделитель внизу
        separator = [[UIView alloc] initWithFrame:CGRectMake(10, 67, self.view.bounds.size.width - 10, 1)];
        separator.tag = 904;
        separator.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        separator.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [cell.contentView addSubview:separator];
    } else {
        avatarView = (UIImageView *)[cell.contentView viewWithTag:900];
        nameLabel = (UILabel *)[cell.contentView viewWithTag:901];
        msgLabel = (UILabel *)[cell.contentView viewWithTag:902];
        timeLabel = (UILabel *)[cell.contentView viewWithTag:903];
        separator = [cell.contentView viewWithTag:904];
    }
    
    // Сброс
    avatarView.image = [UIImage imageNamed:@"default_avatar"];
    nameLabel.text = @"";
    msgLabel.text = @"";
    timeLabel.text = @"";
    separator.hidden = NO;
    cell.accessoryView = nil;
    
    if (isSearching) {
        if (indexPath.row >= searchResults.count) return cell;
        NSDictionary *item = [searchResults objectAtIndex:indexPath.row];
        if (![item isKindOfClass:[NSDictionary class]]) return cell;
        nameLabel.text = [item objectForKey:@"text"] ?: @"[Вложение]";
        msgLabel.text = @"Сообщение";
        return cell;
    }
    
    if (indexPath.row >= conversations.count) return cell;
    NSDictionary *conv = [conversations objectAtIndex:indexPath.row];
    if (![conv isKindOfClass:[NSDictionary class]]) return cell;
    
    NSString *title = nil;
    NSString *avatarURL = nil;
    [self extractTitle:&title avatar:&avatarURL fromConversation:conv];
    nameLabel.text = title;
    
    // Последнее сообщение
    NSDictionary *lastMessage = [conv objectForKey:@"last_message"];
    if ([lastMessage isKindOfClass:[NSDictionary class]]) {
        NSString *text = [lastMessage objectForKey:@"text"];
        BOOL isOut = [[lastMessage objectForKey:@"out"] boolValue];
        if (text.length == 0) {
            NSArray *atts = [lastMessage objectForKey:@"attachments"];
            if ([atts isKindOfClass:[NSArray class]] && atts.count > 0) {
                NSDictionary *a = atts[0];
                NSString *type = [a objectForKey:@"type"];
                if ([type isEqualToString:@"photo"]) text = @"📷 Фотография";
                else if ([type isEqualToString:@"video"]) text = @"🎬 Видео";
                else if ([type isEqualToString:@"audio"]) text = @"🎵 Аудио";
                else if ([type isEqualToString:@"doc"]) text = @"📎 Документ";
                else if ([type isEqualToString:@"sticker"]) text = @"Стикер";
                else text = @"[Вложение]";
            } else {
                text = @"";
            }
        }
        if (isOut && text.length > 0) {
            msgLabel.text = [NSString stringWithFormat:@"Вы: %@", text];
        } else {
            msgLabel.text = text;
        }
        
        NSTimeInterval ts = [[lastMessage objectForKey:@"date"] doubleValue];
        timeLabel.text = [self shortTimeForTimestamp:ts];
    }
    
    // Непрочитанные
    NSDictionary *conversation = [conv objectForKey:@"conversation"];
    NSInteger unread = [[conversation objectForKey:@"unread_count"] integerValue];
    if (unread > 0) {
        UILabel *badge = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 28, 24)];
        badge.backgroundColor = [UIColor colorWithRed:0.35 green:0.55 blue:0.78 alpha:1.0];
        badge.textColor = [UIColor whiteColor];
        badge.textAlignment = NSTextAlignmentCenter;
        badge.font = [UIFont boldSystemFontOfSize:12];
        badge.text = [NSString stringWithFormat:@"%ld", (long)unread];
        badge.layer.cornerRadius = 4;
        badge.clipsToBounds = YES;
        cell.accessoryView = badge;
    }
    
    // Аватар
    if ([avatarURL isKindOfClass:[NSString class]] && avatarURL.length > 0) {
        UIImage *cached = [avatarCache objectForKey:avatarURL];
        if (cached) {
            avatarView.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    [avatarCache setObject:image forKey:avatarURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [aTableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) {
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:900];
                            if (iv) iv.image = image;
                        }
                    });
                }
            }];
        }
    }
    
    return cell;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (isSearching) {
        if (indexPath.row >= searchResults.count) return;
        NSDictionary *msg = [searchResults objectAtIndex:indexPath.row];
        if (![msg isKindOfClass:[NSDictionary class]]) return;
        NSString *pid = [[msg objectForKey:@"peer_id"] stringValue];
        ChatViewController *chatVC = [[ChatViewController alloc] initWithPeerId:pid title:@"Диалог"];
        [self.navigationController pushViewController:chatVC animated:YES];
        return;
    }
    
    if (indexPath.row >= conversations.count) return;
    NSDictionary *conv = [conversations objectAtIndex:indexPath.row];
    if (![conv isKindOfClass:[NSDictionary class]]) return;
    
    NSDictionary *conversation = [conv objectForKey:@"conversation"];
    NSDictionary *peer = [conversation objectForKey:@"peer"];
    NSString *pid = [[peer objectForKey:@"id"] stringValue];
    
    NSString *title = nil;
    NSString *avatarURL = nil;
    [self extractTitle:&title avatar:&avatarURL fromConversation:conv];
    
    ChatViewController *chatVC = [[ChatViewController alloc] initWithPeerId:pid title:title];
    [self.navigationController pushViewController:chatVC animated:YES];
}

@end