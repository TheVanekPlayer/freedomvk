// StickersViewController.h
#import <UIKit/UIKit.h>

@interface StickersViewController : UIViewController
@property (nonatomic, copy) void(^stickerSelectedBlock)(NSString *stickerId);
@end