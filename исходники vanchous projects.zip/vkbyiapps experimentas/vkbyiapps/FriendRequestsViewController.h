// FriendRequestsViewController.h
#import <UIKit/UIKit.h>

@class SideMenuViewController;

@interface FriendRequestsViewController : UIViewController
@property (nonatomic, unsafe_unretained) SideMenuViewController *sideMenuController;
@end