// FriendRequestsViewController.m
#import "FriendRequestsViewController.h"
#import "VKAPIClient.h"
#import "ProfileViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface FriendRequestsViewController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *tableView;
    NSArray *requests;
    NSDictionary *profiles;
    UIActivityIndicatorView *spinner;
    NSMutableDictionary *avatarCache;
    UILabel *emptyLabel;
}
@end

@implementation FriendRequestsViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Заявки в друзья";
    self.view.backgroundColor = [ThemeManager backgroundColor];
    avatarCache = [NSMutableDictionary dictionary];
    requests = @[];
    profiles = @{};
    
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.rowHeight = 64;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorColor = [ThemeManager separatorColor];
    [self.view addSubview:tableView];
    
    emptyLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height/2 - 40, self.view.bounds.size.width, 80)];
    emptyLabel.text = @"Нет новых заявок";
    emptyLabel.textAlignment = NSTextAlignmentCenter;
    emptyLabel.font = [UIFont systemFontOfSize:15];
    emptyLabel.textColor = [UIColor grayColor];
    emptyLabel.backgroundColor = [UIColor clearColor];
    emptyLabel.hidden = YES;
    [self.view addSubview:emptyLabel];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    [self loadRequests];
}

- (void)loadRequests {
    [spinner startAnimating];
    [[VKAPIClient sharedClient] getFriendRequestsWithCompletion:^(NSArray *reqs, NSArray *profs, NSError *error) {
        requests = [reqs isKindOfClass:[NSArray class]] ? reqs : @[];
        
        // Собираем все userId
        NSMutableArray *userIds = [NSMutableArray array];
        for (id item in requests) {
            NSString *uid = nil;
            if ([item isKindOfClass:[NSNumber class]]) uid = [item stringValue];
            else if ([item isKindOfClass:[NSDictionary class]]) uid = [[item objectForKey:@"user_id"] stringValue];
            else if ([item isKindOfClass:[NSString class]]) uid = item;
            if (uid && ![userIds containsObject:uid]) [userIds addObject:uid];
        }
        
        // Сначала берём то что пришло
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        for (NSDictionary *p in profs) {
            if (![p isKindOfClass:[NSDictionary class]]) continue;
            id pid = [p objectForKey:@"id"];
            if (pid) [dict setObject:p forKey:[pid stringValue]];
        }
        
        // Проверяем — все ли профили есть
        BOOL needFetch = NO;
        for (NSString *uid in userIds) {
            if (![dict objectForKey:uid]) { needFetch = YES; break; }
        }
        
        if (needFetch && userIds.count > 0) {
            // Дозагружаем через users.get
            [[VKAPIClient sharedClient] getUsersByIds:userIds completion:^(NSDictionary *usersById, NSError *err) {
                [spinner stopAnimating];
                NSMutableDictionary *merged = [NSMutableDictionary dictionaryWithDictionary:dict];
                if ([usersById isKindOfClass:[NSDictionary class]]) {
                    [merged addEntriesFromDictionary:usersById];
                }
                profiles = [merged copy];
                [tableView reloadData];
                if (requests.count == 0) emptyLabel.hidden = NO;
            }];
        } else {
            [spinner stopAnimating];
            profiles = [dict copy];
            [tableView reloadData];
            if (requests.count == 0) emptyLabel.hidden = NO;
        }
    }];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return requests.count;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"RequestCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
        cell.textLabel.textColor = [ThemeManager cellTextColor];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:11];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = 4;
        cell.imageView.layer.borderWidth = 1;
        cell.imageView.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
        cell.imageView.frame = CGRectMake(0, 0, 46, 46);
        cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
    }
    
    cell.accessoryView = nil;
    cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
    cell.textLabel.text = @"";
    cell.detailTextLabel.text = @"";
    
    if (indexPath.row >= requests.count) return cell;
    id reqItem = [requests objectAtIndex:indexPath.row];
    
    NSString *userId = nil;
    if ([reqItem isKindOfClass:[NSNumber class]]) userId = [reqItem stringValue];
    else if ([reqItem isKindOfClass:[NSDictionary class]]) userId = [[reqItem objectForKey:@"user_id"] stringValue];
    else if ([reqItem isKindOfClass:[NSString class]]) userId = reqItem;
    
    if (!userId) return cell;
    
    // Ищем профиль по строковому ключу
    NSDictionary *profile = [profiles objectForKey:userId];
    
    if (profile && [profile isKindOfClass:[NSDictionary class]]) {
        NSString *fn = [profile objectForKey:@"first_name"] ?: @"";
        NSString *ln = [profile objectForKey:@"last_name"] ?: @"";
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", fn, ln];
        NSNumber *online = [profile objectForKey:@"online"];
        cell.detailTextLabel.text = [online boolValue] ? @"● онлайн" : @"";
        
        NSString *avatarURL = [profile objectForKey:@"photo_100"] ?: [profile objectForKey:@"photo_50"];
        if ([avatarURL isKindOfClass:[NSString class]] && avatarURL.length > 0) {
            UIImage *cached = [avatarCache objectForKey:avatarURL];
            if (cached) {
                cell.imageView.image = cached;
            } else {
                NSString *cellURL = [avatarURL copy];
                [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                    if (image) {
                        [avatarCache setObject:image forKey:cellURL];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                            if (c) c.imageView.image = image;
                        });
                    }
                }];
            }
        }
    } else {
        cell.textLabel.text = @"Заявка в друзья";
        cell.detailTextLabel.text = @"";
    }
    
    // Кнопки принять/отклонить
    UIView *accessory = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 110, 40)];
    
    UIButton *acceptBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    acceptBtn.frame = CGRectMake(0, 6, 50, 30);
    [acceptBtn setTitle:@"✓" forState:UIControlStateNormal];
    [acceptBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    acceptBtn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    acceptBtn.backgroundColor = [UIColor colorWithRed:0.2 green:0.65 blue:0.2 alpha:1.0];
    acceptBtn.layer.cornerRadius = 4;
    acceptBtn.tag = indexPath.row;
    [acceptBtn addTarget:self action:@selector(acceptTapped:) forControlEvents:UIControlEventTouchUpInside];
    [accessory addSubview:acceptBtn];
    
    UIButton *declineBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    declineBtn.frame = CGRectMake(58, 6, 50, 30);
    [declineBtn setTitle:@"✕" forState:UIControlStateNormal];
    [declineBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    declineBtn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    declineBtn.backgroundColor = [UIColor colorWithRed:0.75 green:0.2 blue:0.2 alpha:1.0];
    declineBtn.layer.cornerRadius = 4;
    declineBtn.tag = indexPath.row;
    [declineBtn addTarget:self action:@selector(declineTapped:) forControlEvents:UIControlEventTouchUpInside];
    [accessory addSubview:declineBtn];
    
    cell.accessoryView = accessory;
    
    return cell;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= requests.count) return;
    id reqItem = [requests objectAtIndex:indexPath.row];
    NSString *userId = nil;
    if ([reqItem isKindOfClass:[NSNumber class]]) userId = [reqItem stringValue];
    else if ([reqItem isKindOfClass:[NSDictionary class]]) userId = [[reqItem objectForKey:@"user_id"] stringValue];
    else if ([reqItem isKindOfClass:[NSString class]]) userId = reqItem;
    if (!userId) return;
    
    ProfileViewController *pvc = [[ProfileViewController alloc] initWithUserId:userId];
    pvc.sideMenuController = self.sideMenuController;
    [self.navigationController pushViewController:pvc animated:YES];
}

#pragma mark - Accept / Decline

- (void)acceptTapped:(UIButton *)sender {
    NSInteger row = sender.tag;
    if (row < 0 || row >= requests.count) return;
    id reqItem = [requests objectAtIndex:row];
    NSString *userId = nil;
    if ([reqItem isKindOfClass:[NSNumber class]]) userId = [reqItem stringValue];
    else if ([reqItem isKindOfClass:[NSDictionary class]]) userId = [[reqItem objectForKey:@"user_id"] stringValue];
    else if ([reqItem isKindOfClass:[NSString class]]) userId = reqItem;
    if (!userId) return;
    
    [[VKAPIClient sharedClient] acceptFriendRequest:userId completion:^(BOOL success, NSError *error) {
        if (success) {
            NSMutableArray *newReqs = [NSMutableArray arrayWithArray:requests];
            if (row < newReqs.count) [newReqs removeObjectAtIndex:row];
            requests = [newReqs copy];
            [tableView reloadData];
            if (requests.count == 0) emptyLabel.hidden = NO;
        }
    }];
}

- (void)declineTapped:(UIButton *)sender {
    NSInteger row = sender.tag;
    if (row < 0 || row >= requests.count) return;
    id reqItem = [requests objectAtIndex:row];
    NSString *userId = nil;
    if ([reqItem isKindOfClass:[NSNumber class]]) userId = [reqItem stringValue];
    else if ([reqItem isKindOfClass:[NSDictionary class]]) userId = [[reqItem objectForKey:@"user_id"] stringValue];
    else if ([reqItem isKindOfClass:[NSString class]]) userId = reqItem;
    if (!userId) return;
    
    [[VKAPIClient sharedClient] declineFriendRequest:userId completion:^(BOOL success, NSError *error) {
        if (success) {
            NSMutableArray *newReqs = [NSMutableArray arrayWithArray:requests];
            if (row < newReqs.count) [newReqs removeObjectAtIndex:row];
            requests = [newReqs copy];
            [tableView reloadData];
            if (requests.count == 0) emptyLabel.hidden = NO;
        }
    }];
}

@end