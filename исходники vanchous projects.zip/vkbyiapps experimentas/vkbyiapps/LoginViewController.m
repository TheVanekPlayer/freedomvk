// LoginViewController.m
#import "LoginViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "UIButton+Glossy.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface LoginViewController () {
    UITextField *usernameField;
    UITextField *passwordField;
    UIButton *loginButton;
    UIActivityIndicatorView *spinner;
    UILabel *statusLabel;
    UIImageView *logoImageView;
}
@end

@implementation LoginViewController

- (void)loadView {
    [super loadView];
    
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = self.view.bounds;
    gradient.colors = @[
                        (id)[UIColor colorWithRed:0.22 green:0.40 blue:0.65 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.12 green:0.25 blue:0.45 alpha:1.0].CGColor
                        ];
    gradient.locations = @[@0.0, @1.0];
    [self.view.layer insertSublayer:gradient atIndex:0];
    
    logoImageView = [[UIImageView alloc] init];
    UIImage *logo = [UIImage imageNamed:@"Login_Logo.png"];
    if (logo) {
        logoImageView.image = logo;
        logoImageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.view addSubview:logoImageView];
    } else {
        UILabel *fallback = [[UILabel alloc] init];
        fallback.text = @"OpenVK";
        fallback.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:48];
        fallback.textColor = [UIColor whiteColor];
        fallback.textAlignment = NSTextAlignmentCenter;
        fallback.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.4];
        fallback.shadowOffset = CGSizeMake(0, -2);
        fallback.backgroundColor = [UIColor clearColor];
        [self.view addSubview:fallback];
    }
    
    usernameField = [[UITextField alloc] init];
    usernameField.placeholder = @"Email или телефон";
    usernameField.borderStyle = UITextBorderStyleRoundedRect;
    usernameField.font = [UIFont systemFontOfSize:16];
    usernameField.backgroundColor = [UIColor whiteColor];
    usernameField.textColor = [UIColor darkTextColor];
    usernameField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    usernameField.autocorrectionType = UITextAutocorrectionTypeNo;
    usernameField.keyboardType = UIKeyboardTypeEmailAddress;
    usernameField.layer.cornerRadius = 10.0;
    usernameField.layer.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.3].CGColor;
    usernameField.layer.shadowOffset = CGSizeMake(0, 2);
    usernameField.layer.shadowOpacity = 1.0;
    usernameField.layer.shadowRadius = 4.0;
    usernameField.layer.borderWidth = 0.5;
    usernameField.layer.borderColor = [UIColor colorWithWhite:0.7 alpha:1.0].CGColor;
    [self.view addSubview:usernameField];
    
    passwordField = [[UITextField alloc] init];
    passwordField.placeholder = @"Пароль";
    passwordField.borderStyle = UITextBorderStyleRoundedRect;
    passwordField.font = [UIFont systemFontOfSize:16];
    passwordField.backgroundColor = [UIColor whiteColor];
    passwordField.textColor = [UIColor darkTextColor];
    passwordField.secureTextEntry = YES;
    passwordField.layer.cornerRadius = 10.0;
    passwordField.layer.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.3].CGColor;
    passwordField.layer.shadowOffset = CGSizeMake(0, 2);
    passwordField.layer.shadowOpacity = 1.0;
    passwordField.layer.shadowRadius = 4.0;
    passwordField.layer.borderWidth = 0.5;
    passwordField.layer.borderColor = [UIColor colorWithWhite:0.7 alpha:1.0].CGColor;
    [self.view addSubview:passwordField];
    
    loginButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [loginButton setTitle:@"Войти" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    [loginButton makeGlossy];
    [loginButton addTarget:self action:@selector(loginTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
    statusLabel = [[UILabel alloc] init];
    statusLabel.textAlignment = NSTextAlignmentCenter;
    statusLabel.font = [UIFont systemFontOfSize:14];
    statusLabel.textColor = [UIColor whiteColor];
    statusLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    statusLabel.shadowOffset = CGSizeMake(0, -1);
    statusLabel.backgroundColor = [UIColor clearColor];
    statusLabel.numberOfLines = 0;
    statusLabel.text = @"Введите данные от OpenVK";
    [self.view addSubview:statusLabel];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [self.view addSubview:spinner];
    
    CGFloat w = self.view.bounds.size.width;
    CGFloat centerX = w / 2;
    CGFloat y = 80;
    
    if (logoImageView.image) {
        logoImageView.frame = CGRectMake(centerX - 100, y, 200, 100);
        y += 130;
    } else {
        UILabel *fl = (UILabel *)[self.view.subviews lastObject];
        fl.frame = CGRectMake(0, y, w, 80);
        y += 100;
    }
    
    usernameField.frame = CGRectMake(30, y, w - 60, 44);
    y += 60;
    passwordField.frame = CGRectMake(30, y, w - 60, 44);
    y += 60;
    loginButton.frame = CGRectMake(30, y, w - 60, 44);
    y += 60;
    statusLabel.frame = CGRectMake(20, y, w - 40, 40);
    y += 50;
    spinner.center = CGPointMake(centerX, y);
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)dismissKeyboard {
    [usernameField resignFirstResponder];
    [passwordField resignFirstResponder];
}

- (void)loginTapped {
    [self dismissKeyboard];
    NSString *username = usernameField.text;
    NSString *password = passwordField.text;
    
    if (!username.length || !password.length) {
        statusLabel.text = @"Заполните все поля!";
        statusLabel.textColor = [UIColor redColor];
        return;
    }
    
    [spinner startAnimating];
    loginButton.enabled = NO;
    statusLabel.text = @"Вход...";
    statusLabel.textColor = [UIColor yellowColor];
    
    [[VKAPIClient sharedClient] authenticateWithUsername:username password:password completion:^(BOOL success, NSString *token, NSString *userId, NSError *error) {
        [spinner stopAnimating];
        loginButton.enabled = YES;
        
        if (success && token && userId) {
            [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"VKAccessToken"];
            [[NSUserDefaults standardUserDefaults] setObject:userId forKey:@"VKUserId"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            statusLabel.text = @"✅ Успешно!";
            statusLabel.textColor = [UIColor greenColor];
            
            SideMenuViewController *sideMenu = [[SideMenuViewController alloc] init];
            self.view.window.rootViewController = sideMenu;
            [UIView transitionWithView:self.view.window duration:0.4 options:UIViewAnimationOptionTransitionFlipFromRight animations:nil completion:nil];
        } else {
            statusLabel.text = error.localizedDescription ?: @"Ошибка входа";
            statusLabel.textColor = [UIColor redColor];
        }
    }];
}

@end