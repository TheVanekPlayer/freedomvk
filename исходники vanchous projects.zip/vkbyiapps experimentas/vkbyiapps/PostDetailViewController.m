// PostDetailViewController.m
#import "PostDetailViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "ProfileViewController.h"
#import "GroupWallViewController.h"
#import "VideoPlayerViewController.h"
#import "FullscreenImageViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

@interface PostDetailViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate> {
    UITableView *tableView;
    NSArray *comments;
    UIActivityIndicatorView *spinner;
    NSMutableDictionary *imageCache;
    UIView *inputBar;
    UITextField *commentField;
    UIButton *sendButton;
    BOOL postLiked;
    NSInteger postLikesCount;
    NSString *authorName;
    NSString *authorAvatarURL;
    NSInteger authorId;
    BOOL authorIsGroup;
    NSDictionary *post;
}
@end

@implementation PostDetailViewController
@synthesize sideMenuController, profiles;

- (instancetype)initWithPost:(NSDictionary *)aPost {
    self = [super init];
    if (self) {
        post = aPost;
        NSDictionary *likes = [aPost objectForKey:@"likes"];
        postLikesCount = [[likes objectForKey:@"count"] integerValue];
        postLiked = [[aPost objectForKey:@"user_likes"] boolValue];
        self.hidesBottomBarWhenPushed = YES;
        imageCache = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [ThemeManager backgroundColor];
    self.title = @"Пост";
    
    [self loadAuthorInfo];
    
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tableView];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    inputBar = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44)];
    inputBar.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1.0];
    inputBar.layer.borderWidth = 0.5;
    inputBar.layer.borderColor = [UIColor lightGrayColor].CGColor;
    inputBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [self.view addSubview:inputBar];
    
    commentField = [[UITextField alloc] initWithFrame:CGRectMake(8, 4, self.view.bounds.size.width - 70, 36)];
    commentField.borderStyle = UITextBorderStyleRoundedRect;
    commentField.placeholder = @"Написать комментарий...";
    commentField.delegate = self;
    commentField.returnKeyType = UIReturnKeySend;
    commentField.backgroundColor = [UIColor whiteColor];
    [inputBar addSubview:commentField];
    
    sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sendButton.frame = CGRectMake(self.view.bounds.size.width - 60, 4, 50, 36);
    [sendButton setTitle:@"Отпр." forState:UIControlStateNormal];
    [sendButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    sendButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    sendButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0];
    sendButton.layer.cornerRadius = 5;
    [sendButton addTarget:self action:@selector(sendComment) forControlEvents:UIControlEventTouchUpInside];
    [inputBar addSubview:sendButton];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    [self loadComments];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Загрузка автора

- (void)loadAuthorInfo {
    NSInteger sourceId = [[post objectForKey:@"source_id"] integerValue];
    if (sourceId == 0) {
        sourceId = [[post objectForKey:@"owner_id"] integerValue];
    }
    // ВАЖНО: НЕ используем from_id — это ID текущего пользователя
    
    if (sourceId == 0) {
        authorName = @"Автор";
        [tableView reloadData];
        return;
    }
    
    authorId = sourceId;
    authorIsGroup = (sourceId < 0);
    
    if (authorIsGroup) {
        NSInteger gid = -sourceId;
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@groups.getById?group_id=%ld&fields=photo_50,photo_100,name&access_token=%@&v=5.131",
                               [[VKAPIClient sharedClient] baseURLString], (long)gid, token];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSError *error = nil;
            NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
            if (!error && json[@"response"]) {
                NSArray *groups = json[@"response"];
                if ([groups isKindOfClass:[NSArray class]] && groups.count > 0) {
                    NSDictionary *g = groups[0];
                    authorName = [g objectForKey:@"name"];
                    authorAvatarURL = [g objectForKey:@"photo_100"] ?: [g objectForKey:@"photo_50"];
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [tableView reloadData];
            });
        });
    } else {
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        NSString *urlString = [NSString stringWithFormat:@"%@users.get?user_ids=%ld&fields=photo_50,photo_100&access_token=%@&v=5.131",
                               [[VKAPIClient sharedClient] baseURLString], (long)sourceId, token];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSError *error = nil;
            NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
            if (!error && json[@"response"]) {
                NSArray *users = json[@"response"];
                if ([users isKindOfClass:[NSArray class]] && users.count > 0) {
                    NSDictionary *u = users[0];
                    NSString *fn = [u objectForKey:@"first_name"] ?: @"";
                    NSString *ln = [u objectForKey:@"last_name"] ?: @"";
                    authorName = [NSString stringWithFormat:@"%@ %@", fn, ln];
                    authorAvatarURL = [u objectForKey:@"photo_100"] ?: [u objectForKey:@"photo_50"];
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [tableView reloadData];
            });
        });
    }
}

#pragma mark - Загрузка комментариев

- (void)loadComments {
    [spinner startAnimating];
    NSString *ownerId = [[post objectForKey:@"source_id"] stringValue] ?: @"";
    id postIdObj = [post objectForKey:@"post_id"] ?: [post objectForKey:@"id"];
    NSString *postId = [postIdObj stringValue] ?: @"";
    
    [[VKAPIClient sharedClient] getCommentsForPostWithOwnerId:ownerId postId:postId completion:^(NSArray *cmts, NSError *error) {
        [spinner stopAnimating];
        comments = [cmts isKindOfClass:[NSArray class]] ? cmts : @[];
        
        // Собираем все from_id
        NSMutableArray *userIds = [NSMutableArray array];
        for (NSDictionary *c in comments) {
            if (![c isKindOfClass:[NSDictionary class]]) continue;
            id fid = [c objectForKey:@"from_id"];
            if (fid) {
                NSString *fidStr = [fid stringValue];
                if (![userIds containsObject:fidStr]) [userIds addObject:fidStr];
            }
        }
        
        if (userIds.count > 0) {
            [[VKAPIClient sharedClient] getUsersByIds:userIds completion:^(NSDictionary *usersById, NSError *err) {
                self.profiles = usersById;
                [tableView reloadData];
            }];
        } else {
            [tableView reloadData];
        }
    }];
}

#pragma mark - Отправка комментария

- (void)sendComment {
    NSString *text = commentField.text;
    if (!text.length) return;
    commentField.text = @"";
    [commentField resignFirstResponder];
    
    NSString *ownerId = [[post objectForKey:@"source_id"] stringValue] ?: @"";
    id postIdObj = [post objectForKey:@"post_id"] ?: [post objectForKey:@"id"];
    NSString *postId = [postIdObj stringValue] ?: @"";
    
    if (!ownerId.length || !postId.length) return;
    
    [spinner startAnimating];
    [[VKAPIClient sharedClient] createComment:text forOwnerId:ownerId postId:postId completion:^(BOOL success, NSError *error) {
        [spinner stopAnimating];
        if (success) [self loadComments];
    }];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self sendComment];
    return YES;
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 2; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) return 1;
    return comments.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 1 && comments.count > 0) return 30;
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 1 && comments.count > 0) {
        UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)];
        header.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 5, 200, 20)];
        label.text = @"Комментарии";
        label.font = [UIFont boldSystemFontOfSize:14];
        label.textColor = [UIColor darkGrayColor];
        label.backgroundColor = [UIColor clearColor];
        [header addSubview:label];
        return header;
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        static NSString *postCellID = @"PostDetailCell";
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:postCellID];
        UIImageView *avatarView;
        UILabel *nameLabel, *postTextLabel, *statsLabel, *dateLabel;
        UIImageView *postImageView;
        UIButton *likeBtn;
        
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:postCellID];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundColor = [ThemeManager cellBackgroundColor];
            cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
            
            avatarView = [[UIImageView alloc] init];
            avatarView.tag = 100;
            avatarView.contentMode = UIViewContentModeScaleAspectFill;
            avatarView.clipsToBounds = YES;
            avatarView.layer.cornerRadius = 4;
            avatarView.layer.borderWidth = 1;
            avatarView.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
            avatarView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
            avatarView.userInteractionEnabled = YES;
            [cell.contentView addSubview:avatarView];
            
            nameLabel = [[UILabel alloc] init];
            nameLabel.tag = 101;
            nameLabel.font = [UIFont boldSystemFontOfSize:15];
            nameLabel.textColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
            nameLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:nameLabel];
            
            postTextLabel = [[UILabel alloc] init];
            postTextLabel.tag = 102;
            postTextLabel.numberOfLines = 0;
            postTextLabel.font = [UIFont systemFontOfSize:15];
            postTextLabel.textColor = [ThemeManager cellTextColor];
            postTextLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:postTextLabel];
            
            postImageView = [[UIImageView alloc] init];
            postImageView.tag = 103;
            postImageView.contentMode = UIViewContentModeScaleAspectFill;
            postImageView.clipsToBounds = YES;
            postImageView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
            postImageView.userInteractionEnabled = YES;
            postImageView.layer.cornerRadius = 4;
            [cell.contentView addSubview:postImageView];
            
            statsLabel = [[UILabel alloc] init];
            statsLabel.tag = 104;
            statsLabel.font = [UIFont systemFontOfSize:13];
            statsLabel.textColor = [UIColor darkGrayColor];
            statsLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:statsLabel];
            
            likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            likeBtn.tag = 105;
            likeBtn.titleLabel.font = [UIFont systemFontOfSize:14];
            [likeBtn setTitleColor:[UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0] forState:UIControlStateNormal];
            [likeBtn addTarget:self action:@selector(likePost) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:likeBtn];
            
            dateLabel = [[UILabel alloc] init];
            dateLabel.tag = 106;
            dateLabel.font = [UIFont systemFontOfSize:11];
            dateLabel.textColor = [UIColor grayColor];
            dateLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:dateLabel];
        } else {
            avatarView = (UIImageView *)[cell.contentView viewWithTag:100];
            nameLabel = (UILabel *)[cell.contentView viewWithTag:101];
            postTextLabel = (UILabel *)[cell.contentView viewWithTag:102];
            postImageView = (UIImageView *)[cell.contentView viewWithTag:103];
            statsLabel = (UILabel *)[cell.contentView viewWithTag:104];
            likeBtn = (UIButton *)[cell.contentView viewWithTag:105];
            dateLabel = (UILabel *)[cell.contentView viewWithTag:106];
        }
        
        nameLabel.text = authorName ?: @"Загрузка...";
        avatarView.image = [UIImage imageNamed:@"default_avatar"];
        
        if ([authorAvatarURL isKindOfClass:[NSString class]] && authorAvatarURL.length > 0) {
            UIImage *cached = [imageCache objectForKey:authorAvatarURL];
            if (cached) {
                avatarView.image = cached;
            } else {
                NSString *cellURL = [authorAvatarURL copy];
                [[VKAPIClient sharedClient] downloadImageWithURL:authorAvatarURL completion:^(UIImage *image) {
                    if (image) {
                        [imageCache setObject:image forKey:cellURL];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            avatarView.image = image;
                        });
                    }
                }];
            }
        }
        
        for (UIGestureRecognizer *gr in avatarView.gestureRecognizers) {
            [avatarView removeGestureRecognizer:gr];
        }
        UITapGestureRecognizer *avatarTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openAuthorProfile)];
        [avatarView addGestureRecognizer:avatarTap];
        
        postTextLabel.text = [post objectForKey:@"text"] ?: @"";
        postImageView.image = nil;
        postImageView.hidden = YES;
        
        NSArray *attachments = [post objectForKey:@"attachments"];
        if ([attachments isKindOfClass:[NSArray class]] && attachments.count > 0) {
            NSDictionary *first = attachments[0];
            if ([[first objectForKey:@"type"] isEqualToString:@"photo"]) {
                NSDictionary *photo = [first objectForKey:@"photo"];
                NSString *photoURL = [VKAPIClient bestPhotoURL:photo];
                if ([photoURL isKindOfClass:[NSString class]] && photoURL.length > 0) {
                    postImageView.hidden = NO;
                    UIImage *cached = [imageCache objectForKey:photoURL];
                    if (cached) {
                        postImageView.image = cached;
                    } else {
                        NSString *pURL = [photoURL copy];
                        [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                            if (image) {
                                [imageCache setObject:image forKey:pURL];
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    postImageView.image = image;
                                });
                            }
                        }];
                    }
                }
            }
        }
        
        for (UIGestureRecognizer *gr in postImageView.gestureRecognizers) {
            [postImageView removeGestureRecognizer:gr];
        }
        UITapGestureRecognizer *photoTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(postPhotoTapped:)];
        [postImageView addGestureRecognizer:photoTap];
        
        statsLabel.text = [NSString stringWithFormat:@"❤ %ld", (long)postLikesCount];
        [likeBtn setTitle:postLiked ? @"Убрать лайк" : @"Мне нравится" forState:UIControlStateNormal];
        
        NSTimeInterval ts = [[post objectForKey:@"date"] doubleValue];
        NSDate *d = [NSDate dateWithTimeIntervalSince1970:ts];
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateFormat = @"dd.MM.yyyy HH:mm";
        dateLabel.text = [df stringFromDate:d];
        
        CGFloat width = aTableView.bounds.size.width;
        CGFloat y = 10;
        avatarView.frame = CGRectMake(10, y, 44, 44);
        nameLabel.frame = CGRectMake(64, y + 2, width - 74, 22);
        y += 58;
        CGSize textSize = [postTextLabel.text sizeWithFont:[UIFont systemFontOfSize:15]
                                         constrainedToSize:CGSizeMake(width - 20, CGFLOAT_MAX)
                                             lineBreakMode:UILineBreakModeWordWrap];
        postTextLabel.frame = CGRectMake(10, y, width - 20, textSize.height);
        y += textSize.height + 10;
        if (!postImageView.hidden) {
            postImageView.frame = CGRectMake(10, y, width - 20, 200);
            y += 210;
        }
        statsLabel.frame = CGRectMake(10, y, 100, 25);
        likeBtn.frame = CGRectMake(width - 150, y, 140, 25);
        y += 30;
        dateLabel.frame = CGRectMake(10, y, width - 20, 16);
        y += 20;
        
        UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(10, y, width - 20, 1)];
        sep.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:sep];
        
        return cell;
    } else {
        static NSString *commentCellID = @"CommentCell";
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:commentCellID];
        UIImageView *avatar;
        UILabel *textLabel, *nameLabel, *likeLabel;
        
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:commentCellID];
            cell.backgroundColor = [ThemeManager cellBackgroundColor];
            cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            avatar = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 36, 36)];
            avatar.tag = 200;
            avatar.contentMode = UIViewContentModeScaleAspectFill;
            avatar.clipsToBounds = YES;
            avatar.layer.cornerRadius = 4;
            avatar.layer.borderWidth = 1;
            avatar.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
            avatar.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
            [cell.contentView addSubview:avatar];
            
            nameLabel = [[UILabel alloc] init];
            nameLabel.tag = 201;
            nameLabel.font = [UIFont boldSystemFontOfSize:13];
            nameLabel.textColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
            nameLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:nameLabel];
            
            textLabel = [[UILabel alloc] init];
            textLabel.tag = 202;
            textLabel.numberOfLines = 0;
            textLabel.font = [UIFont systemFontOfSize:14];
            textLabel.textColor = [ThemeManager cellTextColor];
            textLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:textLabel];
            
            likeLabel = [[UILabel alloc] init];
            likeLabel.tag = 203;
            likeLabel.font = [UIFont systemFontOfSize:12];
            likeLabel.textColor = [UIColor grayColor];
            likeLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:likeLabel];
        } else {
            avatar = (UIImageView *)[cell.contentView viewWithTag:200];
            nameLabel = (UILabel *)[cell.contentView viewWithTag:201];
            textLabel = (UILabel *)[cell.contentView viewWithTag:202];
            likeLabel = (UILabel *)[cell.contentView viewWithTag:203];
        }
        
        if (indexPath.row >= comments.count) return cell;
        NSDictionary *comment = [comments objectAtIndex:indexPath.row];
        
        NSString *fromId = [[comment objectForKey:@"from_id"] stringValue];
        NSString *cName = @"Пользователь";
        NSString *cAvatarURL = nil;
        
        if (fromId && self.profiles) {
            NSDictionary *profile = [self.profiles objectForKey:fromId];
            if ([profile isKindOfClass:[NSDictionary class]]) {
                NSString *fn = [profile objectForKey:@"first_name"] ?: @"";
                NSString *ln = [profile objectForKey:@"last_name"] ?: @"";
                cName = [NSString stringWithFormat:@"%@ %@", fn, ln];
                cAvatarURL = [profile objectForKey:@"photo_50"] ?: [profile objectForKey:@"photo_100"];
            }
        }
        
        nameLabel.text = cName;
        avatar.image = [UIImage imageNamed:@"default_avatar"];
        
        if ([cAvatarURL isKindOfClass:[NSString class]] && cAvatarURL.length > 0) {
            UIImage *cached = [imageCache objectForKey:cAvatarURL];
            if (cached) {
                avatar.image = cached;
            } else {
                NSString *cURL = [cAvatarURL copy];
                [[VKAPIClient sharedClient] downloadImageWithURL:cAvatarURL completion:^(UIImage *image) {
                    if (image) {
                        [imageCache setObject:image forKey:cURL];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            UITableViewCell *c = [aTableView cellForRowAtIndexPath:indexPath];
                            if (c) {
                                UIImageView *iv = (UIImageView *)[c.contentView viewWithTag:200];
                                iv.image = image;
                            }
                        });
                    }
                }];
            }
        }
        
        NSString *text = [comment objectForKey:@"text"] ?: @"";
        textLabel.text = text;
        
        NSNumber *likes = [[comment objectForKey:@"likes"] objectForKey:@"count"];
        likeLabel.text = [NSString stringWithFormat:@"❤ %@", likes ?: @"0"];
        
        CGFloat width = aTableView.bounds.size.width;
        CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:14]
                           constrainedToSize:CGSizeMake(width - 70, CGFLOAT_MAX)
                               lineBreakMode:UILineBreakModeWordWrap];
        nameLabel.frame = CGRectMake(54, 6, width - 64, 16);
        textLabel.frame = CGRectMake(54, 24, width - 64, textSize.height);
        likeLabel.frame = CGRectMake(54, 24 + textSize.height + 2, 100, 14);
        
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        NSString *text = [post objectForKey:@"text"] ?: @"";
        CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:15]
                           constrainedToSize:CGSizeMake(aTableView.bounds.size.width - 20, CGFLOAT_MAX)
                               lineBreakMode:UILineBreakModeWordWrap];
        CGFloat h = 68 + textSize.height + 10;
        NSArray *attachments = [post objectForKey:@"attachments"];
        if ([attachments isKindOfClass:[NSArray class]] && attachments.count > 0) {
            NSDictionary *first = attachments[0];
            if ([[first objectForKey:@"type"] isEqualToString:@"photo"]) h += 210;
        }
        h += 80;
        return h;
    } else {
        if (indexPath.row >= comments.count) return 50;
        NSString *text = [[comments objectAtIndex:indexPath.row] objectForKey:@"text"] ?: @"";
        CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:14]
                           constrainedToSize:CGSizeMake(aTableView.bounds.size.width - 70, CGFLOAT_MAX)
                               lineBreakMode:UILineBreakModeWordWrap];
        return textSize.height + 46;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)likePost {
    if (postLiked) return;
    NSString *ownerId = [[post objectForKey:@"source_id"] stringValue] ?: @"";
    id postIdObj = [post objectForKey:@"post_id"] ?: [post objectForKey:@"id"];
    NSString *postId = [postIdObj stringValue] ?: @"";
    [[VKAPIClient sharedClient] addLikeForOwnerId:ownerId itemId:postId type:@"post" completion:^(BOOL success, NSError *error) {
        if (success) {
            postLiked = YES;
            postLikesCount++;
            dispatch_async(dispatch_get_main_queue(), ^{
                [tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            });
        }
    }];
}

- (void)postPhotoTapped:(UITapGestureRecognizer *)gesture {
    UIImageView *iv = (UIImageView *)gesture.view;
    if (!iv.image) return;
    FullscreenImageViewController *fs = [[FullscreenImageViewController alloc] initWithImage:iv.image];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:fs];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)openAuthorProfile {
    if (authorIsGroup) {
        GroupWallViewController *groupVC = [[GroupWallViewController alloc] initWithGroupId:[NSString stringWithFormat:@"-%ld", (long)authorId]
                                                                                       name:authorName
                                                                                  avatarURL:authorAvatarURL];
        groupVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:groupVC animated:YES];
    } else {
        ProfileViewController *pvc = [[ProfileViewController alloc] initWithUserId:[NSString stringWithFormat:@"%ld", (long)authorId]];
        pvc.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:pvc animated:YES];
    }
}

#pragma mark - Keyboard

- (void)keyboardWillShow:(NSNotification *)notification {
    CGRect kbFrame = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat h = kbFrame.size.height;
    NSTimeInterval d = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:d animations:^{
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - h - 44, self.view.bounds.size.width, 44);
        tableView.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - h - 44);
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSTimeInterval d = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:d animations:^{
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44);
        tableView.frame = self.view.bounds;
    }];
}

@end