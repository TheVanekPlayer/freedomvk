// FeedViewController.h
#import <UIKit/UIKit.h>

@class SideMenuViewController;

@interface FeedViewController : UIViewController
@property (nonatomic, unsafe_unretained) SideMenuViewController *sideMenuController;
@end