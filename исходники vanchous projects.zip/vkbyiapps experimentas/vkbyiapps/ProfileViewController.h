// ProfileViewController.h
#import <UIKit/UIKit.h>

@interface ProfileViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
- (instancetype)initWithUserId:(NSString *)userId;
- (instancetype)initWithCurrentUser;
@end