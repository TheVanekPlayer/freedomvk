#import <UIKit/UIKit.h>

@interface MusicViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end