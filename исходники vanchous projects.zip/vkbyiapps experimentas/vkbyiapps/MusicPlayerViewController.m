// MusicPlayerViewController.m
#import "MusicPlayerViewController.h"
#import "MusicPlayerManager.h"
#import "VKAPIClient.h"
#import <QuartzCore/QuartzCore.h>

@interface MusicPlayerViewController () {
    UIView *artworkFrame;
    UIImageView *artworkView;
    
    UIView *titleContainer;
    UILabel *titleLabel;
    BOOL titleAnimationRunning;
    
    UILabel *artistLabel;
    
    UIView *progressTrack;
    UIView *progressFill;
    UIView *progressThumb;
    UILabel *currentTimeLabel;
    UILabel *durationLabel;
    BOOL isDraggingProgress;
    
    UIButton *prevButton;
    UIButton *playPauseButton;
    UIImageView *playIconView;
    UILabel *playFallbackLabel;
    UIButton *nextButton;
    
    UILabel *counterLabel;
    
    NSMutableDictionary *artworkCache;
    NSTimer *uiTimer;
    
    CGFloat artworkSize;
    UIBarButtonItem *addButton;
    CGSize lastLayoutSize;
}
@end

@implementation MusicPlayerViewController

#pragma mark - Placeholder

+ (UIImage *)placeholderImage {
    static UIImage *img = nil;
    if (img) return img;
    CGSize size = CGSizeMake(200, 200);
    UIGraphicsBeginImageContextWithOptions(size, YES, 0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(ctx, [UIColor colorWithWhite:0.88 alpha:1.0].CGColor);
    CGContextFillRect(ctx, CGRectMake(0, 0, size.width, size.height));
    UIFont *font = [UIFont systemFontOfSize:80];
    NSString *note = @"♪";
    CGSize noteSize = [note sizeWithFont:font];
    [[UIColor colorWithWhite:0.55 alpha:1.0] set];
    [note drawAtPoint:CGPointMake((size.width - noteSize.width)/2, (size.height - noteSize.height)/2)
             withFont:font];
    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Аудиоплеер";
    UIImage *texture = [UIImage imageNamed:@"linen_soft.png"];
    self.view.backgroundColor = texture ? [UIColor colorWithPatternImage:texture]
    : [UIColor colorWithWhite:0.91 alpha:1.0];
    
    artworkCache = [NSMutableDictionary dictionary];
    lastLayoutSize = CGSizeZero;
    
    addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                              target:self
                                                              action:@selector(addTapped)];
    self.navigationItem.rightBarButtonItem = addButton;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onTrackChanged:) name:@"MusicPlayerTrackChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onPlayStateChanged:) name:@"MusicPlayerPlayStateChanged" object:nil];
    
    [self layoutUI];
    [self refreshUI];
    
    uiTimer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                               target:self
                                             selector:@selector(refreshProgress)
                                             userInfo:nil
                                              repeats:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    [self refreshUI];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [uiTimer invalidate];
    uiTimer = nil;
    titleAnimationRunning = NO;
    [titleLabel.layer removeAllAnimations];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGSize s = self.view.bounds.size;
    if (fabs(s.width - lastLayoutSize.width) > 0.5 || fabs(s.height - lastLayoutSize.height) > 0.5) {
        lastLayoutSize = s;
        [self layoutUI];
        [self refreshUI];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [uiTimer invalidate];
    uiTimer = nil;
}

#pragma mark - Notifications

- (void)onTrackChanged:(NSNotification *)note {
    [self refreshUI];
}

- (void)onPlayStateChanged:(NSNotification *)note {
    [self updatePlayIcon];
}

#pragma mark - Layout

- (void)layoutUI {
    for (UIView *v in [self.view.subviews copy]) {
        [v removeFromSuperview];
    }
    titleAnimationRunning = NO;
    
    CGFloat w = self.view.bounds.size.width;
    CGFloat h = self.view.bounds.size.height;
    
    CGFloat reserved = 230;
    artworkSize = h - reserved;
    if (artworkSize > 280) artworkSize = 280;
    if (artworkSize < 100) artworkSize = 100;
    if (artworkSize > w - 50) artworkSize = w - 50;
    
    CGFloat y = 12;
    
    // ===== ОБЛОЖКА =====
    artworkFrame = [[UIView alloc] initWithFrame:CGRectMake((w - artworkSize - 12) / 2, y, artworkSize + 12, artworkSize + 12)];
    artworkFrame.backgroundColor = [UIColor whiteColor];
    artworkFrame.layer.cornerRadius = 4;
    artworkFrame.layer.borderWidth = 1;
    artworkFrame.layer.borderColor = [UIColor colorWithWhite:0.75 alpha:1.0].CGColor;
    artworkFrame.layer.shadowColor = [UIColor blackColor].CGColor;
    artworkFrame.layer.shadowOffset = CGSizeMake(0, 2);
    artworkFrame.layer.shadowOpacity = 0.25;
    artworkFrame.layer.shadowRadius = 3;
    [self.view addSubview:artworkFrame];
    
    artworkView = [[UIImageView alloc] initWithFrame:CGRectMake(6, 6, artworkSize, artworkSize)];
    artworkView.backgroundColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    artworkView.contentMode = UIViewContentModeScaleAspectFill;
    artworkView.clipsToBounds = YES;
    artworkView.layer.cornerRadius = 2;
    artworkView.image = [MusicPlayerViewController placeholderImage];
    [artworkFrame addSubview:artworkView];
    
    y = CGRectGetMaxY(artworkFrame.frame) + 8;
    
    // ===== НАЗВАНИЕ =====
    titleContainer = [[UIView alloc] initWithFrame:CGRectMake(15, y, w - 30, 22)];
    titleContainer.backgroundColor = [UIColor clearColor];
    titleContainer.clipsToBounds = YES;
    [self.view addSubview:titleContainer];
    
    titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, w - 30, 22)];
    titleLabel.font = [UIFont boldSystemFontOfSize:16];
    titleLabel.textColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"Ничего не играет";
    [titleContainer addSubview:titleLabel];
    
    y += 22;
    
    // ===== АРТИСТ =====
    artistLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, y, w - 30, 18)];
    artistLabel.font = [UIFont systemFontOfSize:13];
    artistLabel.textColor = [UIColor grayColor];
    artistLabel.textAlignment = NSTextAlignmentCenter;
    artistLabel.backgroundColor = [UIColor clearColor];
    artistLabel.text = @"";
    [self.view addSubview:artistLabel];
    
    y += 18 + 8;
    
    // ===== ПРОГРЕСС =====
    progressTrack = [[UIView alloc] initWithFrame:CGRectMake(15, y + 8, w - 30, 10)];
    progressTrack.backgroundColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    progressTrack.layer.cornerRadius = 5;
    progressTrack.layer.borderWidth = 1;
    progressTrack.layer.borderColor = [UIColor colorWithWhite:0.7 alpha:1.0].CGColor;
    progressTrack.clipsToBounds = NO;
    [self.view addSubview:progressTrack];
    
    UIView *innerShadow = [[UIView alloc] initWithFrame:CGRectMake(1, 1, w - 32, 3)];
    innerShadow.backgroundColor = [UIColor colorWithWhite:0.78 alpha:0.7];
    innerShadow.layer.cornerRadius = 4;
    [progressTrack addSubview:innerShadow];
    
    progressFill = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 10)];
    progressFill.backgroundColor = [UIColor colorWithRed:0.35 green:0.55 blue:0.8 alpha:1.0];
    progressFill.layer.cornerRadius = 5;
    [progressTrack addSubview:progressFill];
    
    progressThumb = [[UIView alloc] initWithFrame:CGRectMake(-8, -3, 16, 16)];
    progressThumb.backgroundColor = [UIColor colorWithWhite:0.95 alpha:1.0];
    progressThumb.layer.cornerRadius = 8;
    progressThumb.layer.borderWidth = 1;
    progressThumb.layer.borderColor = [UIColor colorWithWhite:0.55 alpha:1.0].CGColor;
    progressThumb.layer.shadowColor = [UIColor blackColor].CGColor;
    progressThumb.layer.shadowOffset = CGSizeMake(0, 1);
    progressThumb.layer.shadowOpacity = 0.35;
    progressThumb.layer.shadowRadius = 1.5;
    [progressTrack addSubview:progressThumb];
    
    UITapGestureRecognizer *progressTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(progressTapped:)];
    [progressTrack addGestureRecognizer:progressTap];
    
    UIPanGestureRecognizer *progressPan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(progressPanned:)];
    [progressTrack addGestureRecognizer:progressPan];
    
    currentTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, y + 22, 60, 14)];
    currentTimeLabel.font = [UIFont systemFontOfSize:11];
    currentTimeLabel.textColor = [UIColor grayColor];
    currentTimeLabel.backgroundColor = [UIColor clearColor];
    currentTimeLabel.text = @"0:00";
    [self.view addSubview:currentTimeLabel];
    
    durationLabel = [[UILabel alloc] initWithFrame:CGRectMake(w - 75, y + 22, 60, 14)];
    durationLabel.font = [UIFont systemFontOfSize:11];
    durationLabel.textColor = [UIColor grayColor];
    durationLabel.textAlignment = NSTextAlignmentRight;
    durationLabel.backgroundColor = [UIColor clearColor];
    durationLabel.text = @"0:00";
    [self.view addSubview:durationLabel];
    
    y += 44;
    
    // ===== КНОПКИ =====
    CGFloat centerX = w / 2;
    CGFloat playSize = 64;
    CGFloat sideSize = 50;
    CGFloat gap = 18;
    
    // PLAY
    playPauseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    playPauseButton.frame = CGRectMake(centerX - playSize/2, y, playSize, playSize);
    playPauseButton.backgroundColor = [UIColor colorWithRed:0.28 green:0.48 blue:0.72 alpha:1.0];
    playPauseButton.layer.cornerRadius = 8;
    playPauseButton.layer.borderWidth = 1;
    playPauseButton.layer.borderColor = [UIColor colorWithRed:0.15 green:0.28 blue:0.5 alpha:1.0].CGColor;
    playPauseButton.layer.shadowColor = [UIColor blackColor].CGColor;
    playPauseButton.layer.shadowOffset = CGSizeMake(0, 2);
    playPauseButton.layer.shadowOpacity = 0.35;
    playPauseButton.layer.shadowRadius = 3;
    [playPauseButton addTarget:self action:@selector(playPauseTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:playPauseButton];
    
    CAGradientLayer *playGrad = [CAGradientLayer layer];
    playGrad.frame = playPauseButton.bounds;
    playGrad.colors = @[(id)[UIColor colorWithRed:0.44 green:0.64 blue:0.87 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0].CGColor];
    playGrad.cornerRadius = 8;
    playGrad.masksToBounds = YES;
    [playPauseButton.layer insertSublayer:playGrad atIndex:0];
    
    UIView *gloss = [[UIView alloc] initWithFrame:CGRectMake(1, 1, playSize - 2, playSize / 2 - 1)];
    gloss.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.18];
    gloss.layer.cornerRadius = 7;
    gloss.userInteractionEnabled = NO;
    [playPauseButton addSubview:gloss];
    
    UIImage *playImg = [UIImage imageNamed:@"player_play.png"];
    if (playImg && playImg.size.width >= 4 && playImg.size.height >= 4) {
        CGFloat iconSize = 28;
        playIconView = [[UIImageView alloc] initWithFrame:CGRectMake((playSize - iconSize) / 2,
                                                                     (playSize - iconSize) / 2,
                                                                     iconSize, iconSize)];
        playIconView.contentMode = UIViewContentModeScaleAspectFit;
        playIconView.image = playImg;
        playIconView.userInteractionEnabled = NO;
        [playPauseButton addSubview:playIconView];
        playFallbackLabel = nil;
    } else {
        playFallbackLabel = [[UILabel alloc] initWithFrame:playPauseButton.bounds];
        playFallbackLabel.text = @"▶";
        playFallbackLabel.textColor = [UIColor whiteColor];
        playFallbackLabel.font = [UIFont systemFontOfSize:32];
        playFallbackLabel.textAlignment = NSTextAlignmentCenter;
        playFallbackLabel.backgroundColor = [UIColor clearColor];
        playFallbackLabel.userInteractionEnabled = NO;
        [playPauseButton addSubview:playFallbackLabel];
        playIconView = nil;
    }
    
    // PREV
    CGFloat prevX = centerX - playSize/2 - gap - sideSize;
    CGFloat sideY = y + (playSize - sideSize) / 2;
    
    prevButton = [UIButton buttonWithType:UIButtonTypeCustom];
    prevButton.frame = CGRectMake(prevX, sideY, sideSize, sideSize);
    prevButton.backgroundColor = [UIColor clearColor];
    prevButton.showsTouchWhenHighlighted = YES;
    [prevButton addTarget:self action:@selector(prevTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:prevButton];
    
    UIImage *prevImg = [UIImage imageNamed:@"player_left.png"];
    BOOL prevValid = (prevImg && prevImg.size.width >= 4 && prevImg.size.height >= 4);
    if (prevValid) {
        UIImageView *prevIcon = [[UIImageView alloc] initWithFrame:prevButton.bounds];
        prevIcon.image = prevImg;
        prevIcon.contentMode = UIViewContentModeScaleAspectFit;
        prevIcon.userInteractionEnabled = NO;
        [prevButton addSubview:prevIcon];
    } else {
        [prevButton setTitle:@"◀◀" forState:UIControlStateNormal];
        [prevButton setTitleColor:[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0] forState:UIControlStateNormal];
        prevButton.titleLabel.font = [UIFont boldSystemFontOfSize:20];
    }
    
    // NEXT
    CGFloat nextX = centerX + playSize/2 + gap;
    
    nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    nextButton.frame = CGRectMake(nextX, sideY, sideSize, sideSize);
    nextButton.backgroundColor = [UIColor clearColor];
    nextButton.showsTouchWhenHighlighted = YES;
    [nextButton addTarget:self action:@selector(nextTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:nextButton];
    
    UIImage *nextImg = [UIImage imageNamed:@"player_next.png"];
    BOOL nextValid = (nextImg && nextImg.size.width >= 4 && nextImg.size.height >= 4);
    if (nextValid) {
        UIImageView *nextIcon = [[UIImageView alloc] initWithFrame:nextButton.bounds];
        nextIcon.image = nextImg;
        nextIcon.contentMode = UIViewContentModeScaleAspectFit;
        nextIcon.userInteractionEnabled = NO;
        [nextButton addSubview:nextIcon];
    } else {
        [nextButton setTitle:@"▶▶" forState:UIControlStateNormal];
        [nextButton setTitleColor:[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0] forState:UIControlStateNormal];
        nextButton.titleLabel.font = [UIFont boldSystemFontOfSize:20];
    }
    
    y += playSize + 6;
    
    // ===== СЧЁТЧИК =====
    counterLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, y, w - 30, 14)];
    counterLabel.font = [UIFont systemFontOfSize:11];
    counterLabel.textColor = [UIColor colorWithWhite:0.5 alpha:1.0];
    counterLabel.textAlignment = NSTextAlignmentCenter;
    counterLabel.backgroundColor = [UIColor clearColor];
    counterLabel.text = @"";
    [self.view addSubview:counterLabel];
}

#pragma mark - Marquee

- (void)startTitleAnimation {
    [titleLabel.layer removeAllAnimations];
    titleAnimationRunning = NO;
    
    CGFloat containerW = titleContainer.bounds.size.width;
    CGSize textSize = [titleLabel.text sizeWithFont:titleLabel.font];
    
    if (textSize.width <= containerW) {
        titleLabel.frame = CGRectMake(0, 0, containerW, 22);
        titleLabel.textAlignment = NSTextAlignmentCenter;
        return;
    }
    
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.frame = CGRectMake(0, 0, textSize.width + 4, 22);
    titleAnimationRunning = YES;
    [self performTitleScrollForward];
}

- (void)performTitleScrollForward {
    if (!titleAnimationRunning) return;
    CGFloat containerW = titleContainer.bounds.size.width;
    CGSize textSize = [titleLabel.text sizeWithFont:titleLabel.font];
    CGFloat labelW = textSize.width + 4;
    
    [UIView animateWithDuration:0.4 delay:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        CGRect f = titleLabel.frame;
        f.origin.x = containerW - labelW;
        titleLabel.frame = f;
    } completion:^(BOOL finished) {
        if (!finished || !self->titleAnimationRunning) return;
        [self performTitleScrollBack];
    }];
}

- (void)performTitleScrollBack {
    if (!titleAnimationRunning) return;
    [UIView animateWithDuration:0.4 delay:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        titleLabel.frame = CGRectMake(0, 0, self->titleLabel.frame.size.width, 22);
    } completion:^(BOOL finished) {
        if (!finished || !self->titleAnimationRunning) return;
        [self performTitleScrollForward];
    }];
}

#pragma mark - UI Helper

- (NSString *)formatTime:(NSTimeInterval)time {
    if (time < 0 || time != time) return @"0:00";
    NSInteger secs = (NSInteger)time;
    return [NSString stringWithFormat:@"%ld:%02ld", (long)(secs/60), (long)(secs%60)];
}

- (void)refreshUI {
    MusicPlayerManager *mgr = [MusicPlayerManager sharedManager];
    NSDictionary *track = mgr.currentTrack;
    if (!track) {
        titleLabel.text = @"Ничего не играет";
        artistLabel.text = @"";
        addButton.enabled = NO;
        addButton.tintColor = [UIColor clearColor];
        [self startTitleAnimation];
        return;
    }
    
    titleLabel.text = [track objectForKey:@"title"] ?: @"Без названия";
    artistLabel.text = [track objectForKey:@"artist"] ?: @"Неизвестен";
    
    NSInteger idx = mgr.currentIndex;
    NSInteger total = mgr.playlist.count;
    if (idx >= 0 && total > 0) {
        counterLabel.text = [NSString stringWithFormat:@"%ld из %ld", (long)(idx + 1), (long)total];
    } else {
        counterLabel.text = @"";
    }
    
    NSString *currentUserId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    NSString *trackOwnerId = [[track objectForKey:@"owner_id"] stringValue];
    BOOL isOwnTrack = (trackOwnerId && currentUserId && [trackOwnerId isEqualToString:currentUserId]);
    if (isOwnTrack) {
        addButton.enabled = NO;
        addButton.tintColor = [UIColor clearColor];
    } else {
        addButton.enabled = YES;
        addButton.tintColor = nil;
    }
    
    [self updatePlayIcon];
    [self startTitleAnimation];
    
    NSString *artURL = [track objectForKey:@"photo_270"]
    ?: [track objectForKey:@"photo_135"]
    ?: [track objectForKey:@"album_thumb"]
    ?: [track objectForKey:@"cover"];
    [self loadArtwork:artURL];
    
    [self refreshProgress];
}

- (void)updatePlayIcon {
    MusicPlayerManager *mgr = [MusicPlayerManager sharedManager];
    if (playIconView) {
        UIImage *img = [UIImage imageNamed:@"player_play.png"];
        if (img) playIconView.image = img;
        playIconView.alpha = mgr.isPlaying ? 0.55 : 1.0;
    } else if (playFallbackLabel) {
        playFallbackLabel.text = mgr.isPlaying ? @"❚❚" : @"▶";
    }
}

- (void)refreshProgress {
    MusicPlayerManager *mgr = [MusicPlayerManager sharedManager];
    if (isDraggingProgress) return;
    NSTimeInterval cur = mgr.currentTime;
    NSTimeInterval dur = mgr.duration;
    
    if (dur > 0) {
        CGFloat progress = cur / dur;
        if (progress < 0) progress = 0;
        if (progress > 1) progress = 1;
        [self setProgress:progress];
        currentTimeLabel.text = [self formatTime:cur];
        durationLabel.text = [self formatTime:dur];
    } else {
        [self setProgress:0];
        currentTimeLabel.text = @"0:00";
        durationLabel.text = @"0:00";
    }
}

- (void)setProgress:(CGFloat)progress {
    if (!progressTrack) return;
    CGFloat trackW = progressTrack.bounds.size.width;
    CGFloat fillW = trackW * progress;
    
    CGRect f = progressFill.frame;
    f.size.width = fillW;
    progressFill.frame = f;
    
    CGRect tf = progressThumb.frame;
    tf.origin.x = fillW - tf.size.width / 2;
    progressThumb.frame = tf;
}

- (void)loadArtwork:(NSString *)url {
    if (![url isKindOfClass:[NSString class]] || url.length == 0) {
        artworkView.image = [MusicPlayerViewController placeholderImage];
        return;
    }
    UIImage *cached = [artworkCache objectForKey:url];
    if (cached) {
        artworkView.image = cached;
        return;
    }
    artworkView.image = [MusicPlayerViewController placeholderImage];
    [[VKAPIClient sharedClient] downloadImageWithURL:url completion:^(UIImage *image) {
        if (image) {
            [artworkCache setObject:image forKey:url];
            dispatch_async(dispatch_get_main_queue(), ^{
                artworkView.image = image;
            });
        }
    }];
}

#pragma mark - Actions

- (void)playPauseTapped {
    [[MusicPlayerManager sharedManager] togglePlayPause];
    [self updatePlayIcon];
}

- (void)nextTapped {
    [[MusicPlayerManager sharedManager] nextTrack];
}

- (void)prevTapped {
    [[MusicPlayerManager sharedManager] previousTrack];
}

- (void)addTapped {
    MusicPlayerManager *mgr = [MusicPlayerManager sharedManager];
    NSDictionary *track = mgr.currentTrack;
    if (!track) return;
    
    NSNumber *audioIdNum = [track objectForKey:@"id"];
    NSNumber *ownerIdNum = [track objectForKey:@"owner_id"];
    if (!audioIdNum || !ownerIdNum) return;
    
    NSString *audioId = [audioIdNum stringValue];
    NSString *ownerId = [ownerIdNum stringValue];
    
    addButton.enabled = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;
    
    [[VKAPIClient sharedClient] addAudioWithId:audioId ownerId:ownerId completion:^(BOOL success, NSError *error) {
        self.navigationItem.rightBarButtonItem.enabled = YES;
        if (success) {
            self->addButton.tintColor = [UIColor clearColor];
            self->addButton.enabled = NO;
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                            message:@"Добавлено в мои аудиозаписи"
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка"
                                                            message:@"Не удалось добавить аудиозапись"
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
        }
    }];
}

- (void)progressTapped:(UITapGestureRecognizer *)tap {
    CGPoint p = [tap locationInView:progressTrack];
    CGFloat w = progressTrack.bounds.size.width;
    CGFloat progress = p.x / w;
    if (progress < 0) progress = 0;
    if (progress > 1) progress = 1;
    [[MusicPlayerManager sharedManager] seekToProgress:progress];
    [self setProgress:progress];
}

- (void)progressPanned:(UIPanGestureRecognizer *)pan {
    CGPoint p = [pan locationInView:progressTrack];
    CGFloat w = progressTrack.bounds.size.width;
    CGFloat progress = p.x / w;
    if (progress < 0) progress = 0;
    if (progress > 1) progress = 1;
    
    if (pan.state == UIGestureRecognizerStateBegan) {
        isDraggingProgress = YES;
    }
    [self setProgress:progress];
    
    MusicPlayerManager *mgr = [MusicPlayerManager sharedManager];
    NSTimeInterval dur = mgr.duration;
    if (dur > 0) {
        currentTimeLabel.text = [self formatTime:progress * dur];
    }
    
    if (pan.state == UIGestureRecognizerStateEnded ||
        pan.state == UIGestureRecognizerStateCancelled) {
        isDraggingProgress = NO;
        [[MusicPlayerManager sharedManager] seekToProgress:progress];
    }
}

@end