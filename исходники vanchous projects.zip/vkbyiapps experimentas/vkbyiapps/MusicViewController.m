// MusicViewController.m
#import "MusicViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "MusicPlayerManager.h"
#import "MusicPlayerViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

static UIImage *gPlaceholder = nil;

@interface MusicViewController () <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate> {
    UITableView *tableView;
    NSArray *audios;
    UIActivityIndicatorView *spinner;
    UISegmentedControl *typeSegmented;
    UISearchBar *searchBar;
    NSMutableDictionary *artworkCache;
    BOOL isSearchMode;
    
    UIView *miniPlayer;
    UIImageView *miniArtwork;
    UILabel *miniTitle;
    UILabel *miniArtist;
    UIButton *miniPrevBtn;
    UIButton *miniPlayBtn;
    UIButton *miniNextBtn;
    UIButton *miniCloseBtn;
}
@end

@implementation MusicViewController
@synthesize sideMenuController;

#pragma mark - Placeholder

+ (UIImage *)placeholderImage {
    if (gPlaceholder) return gPlaceholder;
    CGSize size = CGSizeMake(100, 100);
    UIGraphicsBeginImageContextWithOptions(size, YES, 0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(ctx, [UIColor colorWithWhite:0.88 alpha:1.0].CGColor);
    CGContextFillRect(ctx, CGRectMake(0, 0, size.width, size.height));
    CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithWhite:0.75 alpha:1.0].CGColor);
    CGContextSetLineWidth(ctx, 1);
    CGContextStrokeRect(ctx, CGRectMake(0.5, 0.5, size.width-1, size.height-1));
    UIFont *font = [UIFont systemFontOfSize:44];
    NSString *note = @"♪";
    CGSize noteSize = [note sizeWithFont:font];
    [[UIColor colorWithWhite:0.55 alpha:1.0] set];
    [note drawAtPoint:CGPointMake((size.width - noteSize.width)/2, (size.height - noteSize.height)/2)
             withFont:font];
    gPlaceholder = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return gPlaceholder;
}

#pragma mark - Lifecycle

- (void)loadView {
    [super loadView];
    self.title = @"Аудиозаписи";
    UIImage *texture = [UIImage imageNamed:@"linen_soft.png"];
    self.view.backgroundColor = texture ? [UIColor colorWithPatternImage:texture] : [UIColor colorWithWhite:0.94 alpha:1.0];
    artworkCache = [NSMutableDictionary dictionary];
    isSearchMode = NO;
    
    // Searchbar
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 44)];
    searchBar.delegate = self;
    searchBar.placeholder = @"Поиск музыки";
    searchBar.tintColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
    searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    searchBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:searchBar];
    
    // Сегмент
    typeSegmented = [[UISegmentedControl alloc] initWithItems:@[@"Моя музыка", @"Поиск"]];
    typeSegmented.frame = CGRectMake(10, 50, self.view.bounds.size.width - 20, 30);
    typeSegmented.selectedSegmentIndex = 0;
    typeSegmented.tintColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
    typeSegmented.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [typeSegmented addTarget:self action:@selector(segmentChanged) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:typeSegmented];
    
    // Таблица
    tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 90, self.view.bounds.size.width, self.view.bounds.size.height - 90) style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.rowHeight = 60;
    tableView.separatorColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    [self.view addSubview:tableView];
    
    // Спиннер
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    // Навигация
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    // Mini player
    [self setupMiniPlayer];
    
    // Подписки на notifications
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onTrackChanged:) name:@"MusicPlayerTrackChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onPlayStateChanged:) name:@"MusicPlayerPlayStateChanged" object:nil];
    
    [self loadMyMusic];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    [self layoutMiniPlayer];
    [self updateMiniPlayer];
    [tableView reloadData];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self layoutMiniPlayer];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Notifications

- (void)onTrackChanged:(NSNotification *)note {
    [self layoutMiniPlayer];
    [self updateMiniPlayer];
    [tableView reloadData];
}

- (void)onPlayStateChanged:(NSNotification *)note {
    [self updateMiniPlayer];
    [tableView reloadData];
}

#pragma mark - Mini player

- (void)setupMiniPlayer {
    miniPlayer = [[UIView alloc] initWithFrame:CGRectZero];
    miniPlayer.backgroundColor = [UIColor colorWithWhite:0.18 alpha:0.97];
    miniPlayer.layer.borderColor = [UIColor colorWithWhite:0.3 alpha:1.0].CGColor;
    miniPlayer.layer.borderWidth = 1;
    miniPlayer.hidden = YES;
    miniPlayer.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [self.view addSubview:miniPlayer];
    
    miniArtwork = [[UIImageView alloc] initWithFrame:CGRectZero];
    miniArtwork.backgroundColor = [UIColor colorWithWhite:0.3 alpha:1.0];
    miniArtwork.contentMode = UIViewContentModeScaleAspectFill;
    miniArtwork.clipsToBounds = YES;
    miniArtwork.layer.cornerRadius = 3;
    miniArtwork.image = [MusicViewController placeholderImage];
    miniArtwork.userInteractionEnabled = YES;
    [miniPlayer addSubview:miniArtwork];
    
    miniTitle = [[UILabel alloc] initWithFrame:CGRectZero];
    miniTitle.font = [UIFont boldSystemFontOfSize:13];
    miniTitle.textColor = [UIColor whiteColor];
    miniTitle.backgroundColor = [UIColor clearColor];
    miniTitle.numberOfLines = 1;
    miniTitle.userInteractionEnabled = YES;
    [miniPlayer addSubview:miniTitle];
    
    miniArtist = [[UILabel alloc] initWithFrame:CGRectZero];
    miniArtist.font = [UIFont systemFontOfSize:11];
    miniArtist.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    miniArtist.backgroundColor = [UIColor clearColor];
    miniArtist.numberOfLines = 1;
    miniArtist.userInteractionEnabled = YES;
    [miniPlayer addSubview:miniArtist];
    
    UIColor *btnColor = [UIColor colorWithWhite:0.95 alpha:1.0];
    
    miniPrevBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [miniPrevBtn setTitle:@"⏮" forState:UIControlStateNormal];
    [miniPrevBtn setTitleColor:btnColor forState:UIControlStateNormal];
    miniPrevBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    [miniPrevBtn addTarget:self action:@selector(miniPrevTapped) forControlEvents:UIControlEventTouchUpInside];
    [miniPlayer addSubview:miniPrevBtn];
    
    miniPlayBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [miniPlayBtn setTitle:@"▶" forState:UIControlStateNormal];
    [miniPlayBtn setTitleColor:btnColor forState:UIControlStateNormal];
    miniPlayBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    [miniPlayBtn addTarget:self action:@selector(miniPlayTapped) forControlEvents:UIControlEventTouchUpInside];
    [miniPlayer addSubview:miniPlayBtn];
    
    miniNextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [miniNextBtn setTitle:@"⏭" forState:UIControlStateNormal];
    [miniNextBtn setTitleColor:btnColor forState:UIControlStateNormal];
    miniNextBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    [miniNextBtn addTarget:self action:@selector(miniNextTapped) forControlEvents:UIControlEventTouchUpInside];
    [miniPlayer addSubview:miniNextBtn];
    
    miniCloseBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [miniCloseBtn setTitle:@"✕" forState:UIControlStateNormal];
    [miniCloseBtn setTitleColor:[UIColor colorWithWhite:0.7 alpha:1.0] forState:UIControlStateNormal];
    miniCloseBtn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [miniCloseBtn addTarget:self action:@selector(miniCloseTapped) forControlEvents:UIControlEventTouchUpInside];
    [miniPlayer addSubview:miniCloseBtn];
    
    // Тап по обложке/названию → открыть полный плеер
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(miniOpenFullPlayer)];
    [miniArtwork addGestureRecognizer:tap1];
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(miniOpenFullPlayer)];
    [miniTitle addGestureRecognizer:tap2];
    UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(miniOpenFullPlayer)];
    [miniArtist addGestureRecognizer:tap3];
}

- (void)layoutMiniPlayer {
    CGFloat w = self.view.bounds.size.width;
    CGFloat h = self.view.bounds.size.height;
    
    BOOL visible = ([MusicPlayerManager sharedManager].currentTrack != nil);
    CGFloat miniH = visible ? 56.0 : 0.0;
    
    miniPlayer.hidden = !visible;
    miniPlayer.frame = CGRectMake(0, h - miniH, w, miniH);
    
    CGFloat pad = 6;
    miniArtwork.frame = CGRectMake(pad, pad, miniH - pad*2, miniH - pad*2);
    
    CGFloat btnW = 32;
    CGFloat rightBlockW = 4 * btnW + 4;
    CGFloat textX = miniArtwork.frame.origin.x + miniArtwork.frame.size.width + 8;
    CGFloat textW = w - textX - rightBlockW - 4;
    if (textW < 60) textW = 60;
    miniTitle.frame = CGRectMake(textX, pad, textW, 20);
    miniArtist.frame = CGRectMake(textX, pad + 20, textW, 16);
    
    CGFloat bx = w - rightBlockW;
    CGFloat by = (miniH - btnW) / 2;
    miniPrevBtn.frame = CGRectMake(bx, by, btnW, btnW);
    miniPlayBtn.frame = CGRectMake(bx + btnW, by, btnW, btnW);
    miniNextBtn.frame = CGRectMake(bx + btnW*2, by, btnW, btnW);
    miniCloseBtn.frame = CGRectMake(bx + btnW*3, by, btnW, btnW);
    
    tableView.scrollIndicatorInsets = UIEdgeInsetsMake(0, 0, miniH, 0);
    
    [self.view bringSubviewToFront:miniPlayer];
    [self.view bringSubviewToFront:spinner];
}

- (void)updateMiniPlayer {
    MusicPlayerManager *mgr = [MusicPlayerManager sharedManager];
    NSDictionary *track = mgr.currentTrack;
    if (!track) {
        miniPlayer.hidden = YES;
        [self layoutMiniPlayer];
        return;
    }
    
    miniPlayer.hidden = NO;
    miniTitle.text = [track objectForKey:@"title"] ?: @"Без названия";
    miniArtist.text = [track objectForKey:@"artist"] ?: @"Неизвестен";
    [miniPlayBtn setTitle:mgr.isPlaying ? @"❚❚" : @"▶" forState:UIControlStateNormal];
    
    NSString *url = [track objectForKey:@"photo_135"]
    ?: [track objectForKey:@"photo_270"]
    ?: [track objectForKey:@"album_thumb"]
    ?: [track objectForKey:@"cover"];
    miniArtwork.image = [MusicViewController placeholderImage];
    if ([url isKindOfClass:[NSString class]] && url.length > 0) {
        UIImage *cached = [artworkCache objectForKey:url];
        if (cached) {
            miniArtwork.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:url completion:^(UIImage *image) {
                if (image) {
                    [artworkCache setObject:image forKey:url];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        miniArtwork.image = image;
                    });
                }
            }];
        }
    }
    
    [self layoutMiniPlayer];
}

#pragma mark - Mini player actions

- (void)miniPlayTapped {
    [[MusicPlayerManager sharedManager] togglePlayPause];
    [self updateMiniPlayer];
}

- (void)miniPrevTapped {
    [[MusicPlayerManager sharedManager] previousTrack];
    [self updateMiniPlayer];
}

- (void)miniNextTapped {
    [[MusicPlayerManager sharedManager] nextTrack];
    [self updateMiniPlayer];
}

- (void)miniCloseTapped {
    [[MusicPlayerManager sharedManager] stop];
    miniPlayer.hidden = YES;
    [self layoutMiniPlayer];
    [tableView reloadData];
}

- (void)miniOpenFullPlayer {
    if (![MusicPlayerManager sharedManager].currentTrack) return;
    MusicPlayerViewController *playerVC = [[MusicPlayerViewController alloc] init];
    [self.navigationController pushViewController:playerVC animated:YES];
}

#pragma mark - Navigation

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)segmentChanged {
    if (typeSegmented.selectedSegmentIndex == 0) {
        isSearchMode = NO;
        searchBar.text = @"";
        [searchBar resignFirstResponder];
        [self loadMyMusic];
    } else {
        isSearchMode = YES;
        audios = @[];
        [tableView reloadData];
        [searchBar becomeFirstResponder];
    }
}

#pragma mark - Загрузка

- (void)loadMyMusic {
    [spinner startAnimating];
    [[VKAPIClient sharedClient] getAudioWithCompletion:^(NSArray *items, NSError *error) {
        [spinner stopAnimating];
        if (self->isSearchMode) return;
        self->audios = (error || ![items isKindOfClass:[NSArray class]]) ? @[] : items;
        [self->tableView reloadData];
        if (self->audios.count == 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Инфо" message:@"Аудиозаписей нет" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }
    }];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)sb {
    [sb resignFirstResponder];
    if (sb.text.length == 0) return;
    if (typeSegmented.selectedSegmentIndex == 0) {
        typeSegmented.selectedSegmentIndex = 1;
        isSearchMode = YES;
    }
    [spinner startAnimating];
    NSString *query = [sb.text copy];
    [[VKAPIClient sharedClient] searchAudioWithQuery:query completion:^(NSArray *items, NSError *error) {
        [spinner stopAnimating];
        if (!self->isSearchMode) return;
        self->audios = (error || ![items isKindOfClass:[NSArray class]]) ? @[] : items;
        [self->tableView reloadData];
    }];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return audios.count;
}

- (NSString *)artworkURLForAudio:(NSDictionary *)audio {
    NSArray *keys = @[@"photo_135", @"photo_270", @"album_thumb", @"cover", @"thumb"];
    for (NSString *k in keys) {
        id v = [audio objectForKey:k];
        if ([v isKindOfClass:[NSString class]] && [v length] > 0) return v;
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"MusicCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.85];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.frame = CGRectMake(0, 0, 50, 50);
        cell.imageView.layer.cornerRadius = 4;
        cell.imageView.layer.borderWidth = 1;
        cell.imageView.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
    }
    
    NSDictionary *audio = [audios objectAtIndex:indexPath.row];
    NSString *artist = [audio objectForKey:@"artist"] ?: @"Неизвестен";
    NSString *title = [audio objectForKey:@"title"] ?: @"Без названия";
    cell.textLabel.text = title;
    NSInteger duration = [[audio objectForKey:@"duration"] integerValue];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ • %ld:%02ld", artist, (long)duration/60, (long)duration%60];
    
    cell.imageView.image = [MusicViewController placeholderImage];
    NSString *artworkURL = [self artworkURLForAudio:audio];
    if (artworkURL) {
        UIImage *cached = [artworkCache objectForKey:artworkURL];
        if (cached) {
            cell.imageView.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:artworkURL completion:^(UIImage *image) {
                if (image) {
                    [artworkCache setObject:image forKey:artworkURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *c = [tableView cellForRowAtIndexPath:indexPath];
                        if (c) c.imageView.image = image;
                    });
                }
            }];
        }
    }
    
    MusicPlayerManager *mgr = [MusicPlayerManager sharedManager];
    NSDictionary *current = mgr.currentTrack;
    BOOL isCurrent = NO;
    if (current) {
        id aId = [audio objectForKey:@"id"];
        id cId = [current objectForKey:@"id"];
        id aOwn = [audio objectForKey:@"owner_id"];
        id cOwn = [current objectForKey:@"owner_id"];
        if (aId && cId && aOwn && cOwn && [aId isEqual:cId] && [aOwn isEqual:cOwn]) {
            isCurrent = YES;
        }
    }
    if (isCurrent) {
        cell.contentView.backgroundColor = [UIColor colorWithRed:0.85 green:0.92 blue:1.0 alpha:1.0];
    } else {
        cell.contentView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.85];
    }
    return cell;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *track = [audios objectAtIndex:indexPath.row];
    NSArray *playlist = [audios copy];
    [[MusicPlayerManager sharedManager] playTrackAtIndex:indexPath.row playlist:playlist];
    
    [self updateMiniPlayer];
    [tableView reloadData];
    
    MusicPlayerViewController *playerVC = [[MusicPlayerViewController alloc] init];
    [self.navigationController pushViewController:playerVC animated:YES];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [searchBar resignFirstResponder];
}

@end