// ThemeManager.m
#import "ThemeManager.h"

NSString * const ThemeDidChangeNotification = @"ThemeDidChangeNotification";

@implementation ThemeManager

+ (BOOL)isDarkTheme {
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"DarkTheme"];
}

+ (BOOL)isOptimizedMode {
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"OptimizeMode"];
}

+ (void)setDarkTheme:(BOOL)dark {
    [[NSUserDefaults standardUserDefaults] setBool:dark forKey:@"DarkTheme"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:ThemeDidChangeNotification object:nil];
}

+ (void)applyThemeToWindow:(UIWindow *)window {
    if ([self isDarkTheme]) {
        window.backgroundColor = [UIColor colorWithWhite:0.12 alpha:1.0];
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    } else {
        UIImage *bg = [self backgroundImage];
        window.backgroundColor = bg ? [UIColor colorWithPatternImage:bg] : [UIColor colorWithWhite:0.92 alpha:1.0];
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    }
}

+ (UIImage *)backgroundImage {
    if ([self isDarkTheme]) return nil;
    return [UIImage imageNamed:@"linen_soft.png"];
}

+ (UIColor *)backgroundColor {
    if ([self isDarkTheme]) return [UIColor colorWithWhite:0.12 alpha:1.0];
    UIImage *bg = [self backgroundImage];
    return bg ? [UIColor colorWithPatternImage:bg] : [UIColor colorWithWhite:0.92 alpha:1.0];
}

+ (UIColor *)cellBackgroundColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.18 alpha:1.0] : [UIColor whiteColor];
}

+ (UIColor *)cellTextColor {
    return [self isDarkTheme] ? [UIColor whiteColor] : [UIColor blackColor];
}

+ (UIColor *)textColor {
    return [self isDarkTheme] ? [UIColor whiteColor] : [UIColor blackColor];
}

+ (UIColor *)separatorColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.3 alpha:1.0] : [UIColor colorWithWhite:0.85 alpha:1.0];
}

+ (UIColor *)navigationBarTopColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.22 alpha:1.0] : [UIColor colorWithRed:0.22 green:0.40 blue:0.65 alpha:1.0];
}

+ (UIColor *)navigationBarBottomColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.12 alpha:1.0] : [UIColor colorWithRed:0.12 green:0.25 blue:0.45 alpha:1.0];
}

+ (UIColor *)navigationBarTintColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.4 alpha:1.0] : [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
}

+ (UIColor *)navigationBarTitleColor {
    return [UIColor whiteColor];
}

+ (UIColor *)searchBarTintColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.3 alpha:1.0] : [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
}

@end