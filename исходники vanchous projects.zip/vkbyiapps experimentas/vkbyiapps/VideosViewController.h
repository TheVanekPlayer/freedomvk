// VideosViewController.h
#import <UIKit/UIKit.h>

@interface VideosViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end