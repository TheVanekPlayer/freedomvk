// ProfileViewController.m
#import "ProfileViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "ChatViewController.h"
#import "PostDetailViewController.h"
#import "FullscreenImageViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface ProfileViewController () <UITableViewDelegate, UITableViewDataSource> {
    NSString *userId;
    NSDictionary *userInfo;
    NSMutableArray *wallPosts;
    NSMutableDictionary *imageCache;
    UIScrollView *scrollView;
    UIView *headerView;
    UIImageView *avatarView;
    UILabel *nameLabel;
    UILabel *statusLabel;
    UILabel *lastSeenLabel;
    UIView *countersBar;
    UIButton *messageButton;
    UITableView *wallTableView;
    UIActivityIndicatorView *spinner;
    BOOL optimizeMode;
    BOOL isLoadingWall;
    UILabel *wallHeaderLabel;
}
@end

@implementation ProfileViewController
@synthesize sideMenuController;

#pragma mark - Init

- (instancetype)initWithUserId:(NSString *)aUserId {
    self = [super init];
    if (self) {
        userId = aUserId;
        imageCache = [NSMutableDictionary dictionary];
        wallPosts = [NSMutableArray array];
    }
    return self;
}

- (instancetype)initWithCurrentUser {
    return [self initWithUserId:[[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"]];
}

#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Профиль";
    self.view.backgroundColor = [UIColor colorWithWhite:0.90 alpha:1.0];
    optimizeMode = [[NSUserDefaults standardUserDefaults] boolForKey:@"OptimizeMode"];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    UIBarButtonItem *infoBtn = [[UIBarButtonItem alloc] initWithTitle:@"Инфо" style:UIBarButtonItemStylePlain target:self action:@selector(infoTapped)];
    self.navigationItem.rightBarButtonItem = infoBtn;
    
    [self setupUI];
    [self loadProfile];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)themeDidChange:(NSNotification *)notification {
    [self.view setNeedsDisplay];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

#pragma mark - UI

- (void)setupUI {
    scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.backgroundColor = [UIColor colorWithWhite:0.92 alpha:1.0];
    [self.view addSubview:scrollView];
    
    CGFloat w = self.view.bounds.size.width;
    
    // ===== ШАПКА ПРОФИЛЯ =====
    headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, 175)];
    headerView.backgroundColor = [UIColor colorWithRed:0.15 green:0.28 blue:0.5 alpha:1.0];
    headerView.clipsToBounds = YES;
    
    // Градиент
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = headerView.bounds;
    gradient.colors = @[
                        (id)[UIColor colorWithRed:0.35 green:0.52 blue:0.75 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.10 green:0.20 blue:0.40 alpha:1.0].CGColor
                        ];
    gradient.locations = @[@0.0, @1.0];
    [headerView.layer insertSublayer:gradient atIndex:0];
    
    // Тень снизу
    UIView *shadowLine = [[UIView alloc] initWithFrame:CGRectMake(0, 173, w, 2)];
    shadowLine.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];
    [headerView addSubview:shadowLine];
    
    [scrollView addSubview:headerView];
    
    // ===== АВАТАР — квадратный с белой рамкой =====
    avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 100, 100)];
    avatarView.layer.borderWidth = 3;
    avatarView.layer.borderColor = [UIColor whiteColor].CGColor;
    avatarView.clipsToBounds = YES;
    avatarView.backgroundColor = [UIColor colorWithWhite:0.3 alpha:1.0];
    avatarView.contentMode = UIViewContentModeScaleAspectFill;
    avatarView.userInteractionEnabled = YES;
    UITapGestureRecognizer *avatarTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(avatarTapped)];
    [avatarView addGestureRecognizer:avatarTap];
    [headerView addSubview:avatarView];
    
    // ===== ИМЯ =====
    nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(128, 20, w - 140, 26)];
    nameLabel.font = [UIFont boldSystemFontOfSize:19];
    nameLabel.textColor = [UIColor whiteColor];
    nameLabel.shadowColor = [UIColor blackColor];
    nameLabel.shadowOffset = CGSizeMake(0, -1);
    nameLabel.backgroundColor = [UIColor clearColor];
    [headerView addSubview:nameLabel];
    
    // ===== СТАТУС =====
    statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(128, 48, w - 140, 20)];
    statusLabel.font = [UIFont systemFontOfSize:13];
    statusLabel.textColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    statusLabel.shadowColor = [UIColor blackColor];
    statusLabel.shadowOffset = CGSizeMake(0, -1);
    statusLabel.backgroundColor = [UIColor clearColor];
    [headerView addSubview:statusLabel];
    
    // ===== ПОСЛЕДНИЙ ВИЗИТ =====
    lastSeenLabel = [[UILabel alloc] initWithFrame:CGRectMake(128, 70, w - 140, 18)];
    lastSeenLabel.font = [UIFont systemFontOfSize:11];
    lastSeenLabel.textColor = [UIColor colorWithWhite:0.75 alpha:1.0];
    lastSeenLabel.shadowColor = [UIColor blackColor];
    lastSeenLabel.shadowOffset = CGSizeMake(0, -1);
    lastSeenLabel.backgroundColor = [UIColor clearColor];
    [headerView addSubview:lastSeenLabel];
    
    // ===== КНОПКА "НАПИСАТЬ СООБЩЕНИЕ" =====
    messageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    messageButton.frame = CGRectMake(128, 95, w - 143, 30);
    [messageButton setTitle:@"✉ Написать сообщение" forState:UIControlStateNormal];
    [messageButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    messageButton.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    messageButton.layer.cornerRadius = 5;
    messageButton.layer.borderWidth = 1;
    messageButton.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.5].CGColor;
    messageButton.layer.masksToBounds = YES;
    messageButton.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    [messageButton addTarget:self action:@selector(sendMessageTapped) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:messageButton];
    
    // ===== СЧЁТЧИКИ =====
    countersBar = [[UIView alloc] initWithFrame:CGRectMake(0, 175, w, 50)];
    countersBar.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.97];
    countersBar.layer.borderWidth = 0.5;
    countersBar.layer.borderColor = [UIColor colorWithWhite:0.85 alpha:1.0].CGColor;
    [scrollView addSubview:countersBar];
    
    // ===== ЗАГОЛОВОК "СТЕНА" =====
    UIView *wallHeader = [[UIView alloc] initWithFrame:CGRectMake(0, 225, w, 24)];
    wallHeader.backgroundColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    wallHeaderLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 2, w - 20, 20)];
    wallHeaderLabel.text = @"Стена";
    wallHeaderLabel.font = [UIFont boldSystemFontOfSize:12];
    wallHeaderLabel.textColor = [UIColor colorWithWhite:0.3 alpha:1.0];
    wallHeaderLabel.backgroundColor = [UIColor clearColor];
    [wallHeader addSubview:wallHeaderLabel];
    [scrollView addSubview:wallHeader];
    
    // ===== СТЕНА =====
    wallTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 249, w, 0) style:UITableViewStylePlain];
    wallTableView.delegate = self;
    wallTableView.dataSource = self;
    wallTableView.backgroundColor = [UIColor clearColor];
    wallTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    wallTableView.separatorColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    wallTableView.scrollEnabled = NO;
    wallTableView.rowHeight = 70;
    [scrollView addSubview:wallTableView];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
}

#pragma mark - Счётчики

- (void)setupCountersWithUser:(NSDictionary *)user {
    for (UIView *v in countersBar.subviews) [v removeFromSuperview];
    
    NSDictionary *counters = [user objectForKey:@"counters"];
    if (![counters isKindOfClass:[NSDictionary class]]) {
        counters = @{};
    }
    
    NSArray *items = @[
                       @{@"icon": @"👥", @"val": [counters objectForKey:@"friends"] ?: @0, @"name": @"друзья"},
                       @{@"icon": @"📷", @"val": [counters objectForKey:@"photos"] ?: @0, @"name": @"фото"},
                       @{@"icon": @"🎬", @"val": [counters objectForKey:@"videos"] ?: @0, @"name": @"видео"},
                       @{@"icon": @"🎵", @"val": [counters objectForKey:@"audios"] ?: @0, @"name": @"аудио"},
                       @{@"icon": @"💬", @"val": [counters objectForKey:@"groups"] ?: @0, @"name": @"группы"}
                       ];
    
    CGFloat w = countersBar.bounds.size.width;
    CGFloat cellW = w / 5;
    
    for (NSInteger i = 0; i < items.count; i++) {
        NSDictionary *item = [items objectAtIndex:i];
        UIView *cell = [[UIView alloc] initWithFrame:CGRectMake(i * cellW, 0, cellW, 50)];
        cell.backgroundColor = [UIColor clearColor];
        
        // Иконка
        UILabel *iconLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, cellW, 16)];
        iconLabel.text = [item objectForKey:@"icon"];
        iconLabel.textAlignment = NSTextAlignmentCenter;
        iconLabel.font = [UIFont systemFontOfSize:14];
        iconLabel.backgroundColor = [UIColor clearColor];
        [cell addSubview:iconLabel];
        
        // Значение
        UILabel *val = [[UILabel alloc] initWithFrame:CGRectMake(0, 22, cellW, 16)];
        val.text = [NSString stringWithFormat:@"%@", [item objectForKey:@"val"]];
        val.textAlignment = NSTextAlignmentCenter;
        val.font = [UIFont boldSystemFontOfSize:13];
        val.textColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
        val.backgroundColor = [UIColor clearColor];
        [cell addSubview:val];
        
        // Название
        UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(0, 38, cellW, 11)];
        name.text = [item objectForKey:@"name"];
        name.textAlignment = NSTextAlignmentCenter;
        name.font = [UIFont systemFontOfSize:9];
        name.textColor = [UIColor grayColor];
        name.backgroundColor = [UIColor clearColor];
        [cell addSubview:name];
        
        [countersBar addSubview:cell];
        
        if (i < items.count - 1) {
            UIView *sep = [[UIView alloc] initWithFrame:CGRectMake((i+1)*cellW - 0.5, 8, 1, 34)];
            sep.backgroundColor = [UIColor colorWithWhite:0.85 alpha:1.0];
            [countersBar addSubview:sep];
        }
    }
}

#pragma mark - Загрузка

- (void)loadProfile {
    [spinner startAnimating];
    [[VKAPIClient sharedClient] profileGetInfoWithUserId:userId completion:^(NSDictionary *aUserInfo, NSError *error) {
        if (error || ![aUserInfo isKindOfClass:[NSDictionary class]]) {
            [spinner stopAnimating];
            return;
        }
        userInfo = aUserInfo;
        [self updateUI];
        [self setupCountersWithUser:userInfo];
        [self loadWall];
    }];
}

- (void)loadWall {
    if (isLoadingWall) return;
    isLoadingWall = YES;
    [[VKAPIClient sharedClient] getWallPostsWithOwnerId:userId completion:^(NSArray *posts, NSError *wallError) {
        [spinner stopAnimating];
        isLoadingWall = NO;
        [wallPosts removeAllObjects];
        if ([posts isKindOfClass:[NSArray class]]) {
            [wallPosts addObjectsFromArray:posts];
        }
        [wallTableView reloadData];
        [self adjustScrollViewHeight];
    }];
}

#pragma mark - UI Update

- (void)updateUI {
    NSString *firstName = [userInfo objectForKey:@"first_name"] ?: @"";
    NSString *lastName = [userInfo objectForKey:@"last_name"] ?: @"";
    nameLabel.text = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
    
    NSString *status = [userInfo objectForKey:@"status"];
    if (status.length > 0) {
        statusLabel.text = status;
        statusLabel.textColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    } else {
        statusLabel.text = @"";
    }
    
    NSNumber *online = [userInfo objectForKey:@"online"];
    if ([online boolValue]) {
        lastSeenLabel.text = @"● онлайн";
        lastSeenLabel.textColor = [UIColor colorWithRed:0.6 green:1.0 blue:0.6 alpha:1.0];
    } else {
        NSDictionary *lastSeen = [userInfo objectForKey:@"last_seen"];
        NSInteger last = [[lastSeen objectForKey:@"time"] integerValue];
        if (last) {
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:last];
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            df.dateFormat = @"dd.MM.yyyy HH:mm";
            lastSeenLabel.text = [NSString stringWithFormat:@"был(а) %@", [df stringFromDate:date]];
        } else {
            lastSeenLabel.text = @"не в сети";
        }
        lastSeenLabel.textColor = [UIColor colorWithWhite:0.75 alpha:1.0];
    }
    
    NSString *avatarURL = [userInfo objectForKey:@"photo_200"]
    ?: [userInfo objectForKey:@"photo_100"]
    ?: [userInfo objectForKey:@"photo_50"];
    if ([avatarURL isKindOfClass:[NSString class]] && avatarURL.length > 0) {
        UIImage *cached = [imageCache objectForKey:avatarURL];
        if (cached) {
            avatarView.image = cached;
        } else {
            NSString *cellURL = [avatarURL copy];
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    [imageCache setObject:image forKey:cellURL];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        avatarView.image = image;
                    });
                }
            }];
        }
    }
    
    // Кнопка "Написать сообщение" — только для чужого профиля
    NSString *currentUserId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    if ([userId isEqualToString:currentUserId]) {
        messageButton.hidden = YES;
    } else {
        messageButton.hidden = NO;
    }
}

#pragma mark - Actions

- (void)avatarTapped {
    NSString *avatarURL = [userInfo objectForKey:@"photo_200"] ?: [userInfo objectForKey:@"photo_100"];
    if (!avatarURL) return;
    FullscreenImageViewController *fs = [[FullscreenImageViewController alloc] initWithImageURL:avatarURL];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:fs];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)sendMessageTapped {
    ChatViewController *chatVC = [[ChatViewController alloc] initWithPeerId:userId title:nameLabel.text];
    [self.navigationController pushViewController:chatVC animated:YES];
}

#pragma mark - Info

- (void)infoTapped {
    if (!userInfo) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Информация" message:@"Загрузка..." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    NSMutableString *info = [NSMutableString string];
    
    NSString *firstName = [userInfo objectForKey:@"first_name"] ?: @"";
    NSString *lastName = [userInfo objectForKey:@"last_name"] ?: @"";
    NSString *status = [userInfo objectForKey:@"status"];
    NSString *bdate = [userInfo objectForKey:@"bdate"];
    NSDictionary *cityDict = [userInfo objectForKey:@"city"];
    NSString *city = [cityDict objectForKey:@"title"];
    NSString *site = [userInfo objectForKey:@"site"];
    NSString *mobilePhone = [userInfo objectForKey:@"mobile_phone"];
    NSString *homePhone = [userInfo objectForKey:@"home_phone"];
    NSString *skype = [userInfo objectForKey:@"skype"];
    NSString *instagram = [userInfo objectForKey:@"instagram"];
    NSString *twitter = [userInfo objectForKey:@"twitter"];
    NSString *facebook = [userInfo objectForKey:@"facebook"];
    NSNumber *online = [userInfo objectForKey:@"online"];
    
    [info appendFormat:@"%@ %@\n\n", firstName, lastName];
    
    if (status.length > 0) [info appendFormat:@"📝 %@\n\n", status];
    if ([online boolValue]) {
        [info appendString:@"🟢 онлайн\n\n"];
    }
    if (bdate.length > 0) [info appendFormat:@"🎂 %@\n", bdate];
    if (city.length > 0) [info appendFormat:@"📍 %@\n", city];
    if (mobilePhone.length > 0) [info appendFormat:@"📱 %@\n", mobilePhone];
    if (homePhone.length > 0) [info appendFormat:@"☎ %@\n", homePhone];
    if (site.length > 0) [info appendFormat:@"🌐 %@\n", site];
    if (skype.length > 0) [info appendFormat:@"💬 Skype: %@\n", skype];
    if (instagram.length > 0) [info appendFormat:@"📷 Instagram: %@\n", instagram];
    if (twitter.length > 0) [info appendFormat:@"🐦 Twitter: %@\n", twitter];
    if (facebook.length > 0) [info appendFormat:@"📘 Facebook: %@\n", facebook];
    
    NSString *result = [info stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (result.length == 0) {
        result = @"Информация скрыта или недоступна";
    }
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Информация"
                                                    message:result
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return wallPosts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"WallCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont systemFontOfSize:13];
        cell.textLabel.numberOfLines = 0;
        cell.textLabel.textColor = [UIColor blackColor];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:11];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
    }
    
    if (indexPath.row >= wallPosts.count) return cell;
    NSDictionary *post = [wallPosts objectAtIndex:indexPath.row];
    if (![post isKindOfClass:[NSDictionary class]]) return cell;
    
    NSString *text = [VKAPIClient postText:post];
    if (text.length > 140) text = [[text substringToIndex:140] stringByAppendingString:@"..."];
    cell.textLabel.text = text;
    
    NSNumber *likes = [[post objectForKey:@"likes"] objectForKey:@"count"];
    NSNumber *comments = [[post objectForKey:@"comments"] objectForKey:@"count"];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"❤ %@  ✉ %@", likes ?: @"0", comments ?: @"0"];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= wallPosts.count) return 50;
    NSDictionary *post = [wallPosts objectAtIndex:indexPath.row];
    NSString *text = [VKAPIClient postText:post];
    if (text.length > 140) text = [[text substringToIndex:140] stringByAppendingString:@"..."];
    CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:13]
                   constrainedToSize:CGSizeMake(self.view.bounds.size.width - 30, CGFLOAT_MAX)
                       lineBreakMode:UILineBreakModeWordWrap];
    return MAX(size.height + 35, 50);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= wallPosts.count) return;
    NSDictionary *post = [wallPosts objectAtIndex:indexPath.row];
    PostDetailViewController *detailVC = [[PostDetailViewController alloc] initWithPost:post];
    [self.navigationController pushViewController:detailVC animated:YES];
}

- (void)adjustScrollViewHeight {
    CGFloat tableHeight = wallTableView.contentSize.height;
    if (tableHeight < 100) tableHeight = 100;
    CGRect frame = wallTableView.frame;
    frame.size.height = tableHeight;
    wallTableView.frame = frame;
    scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, frame.origin.y + frame.size.height + 20);
}

@end