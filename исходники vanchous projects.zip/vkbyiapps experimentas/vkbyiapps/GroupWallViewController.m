// GroupWallViewController.m
#import "GroupWallViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "PostDetailViewController.h"
#import "VideoPlayerViewController.h"
#import <objc/runtime.h>
#import <QuartzCore/QuartzCore.h>

@interface GroupWallViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *posts;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSMutableDictionary *imageCache;
@property (nonatomic, copy) NSString *groupId;
@property (nonatomic, copy) NSString *groupName;
@property (nonatomic, copy) NSString *groupAvatarURL;
@property (nonatomic, strong) NSMutableArray *expandedRows;
@property (nonatomic, strong) NSDictionary *groupInfo;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UIImageView *avatarView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *followButton;
@end

@implementation GroupWallViewController

- (instancetype)initWithGroupId:(NSString *)groupId name:(NSString *)name avatarURL:(NSString *)avatarURL {
    self = [super init];
    if (self) {
        _groupId = groupId;
        _groupName = name;
        _groupAvatarURL = avatarURL;
        _imageCache = [NSMutableDictionary dictionary];
        _expandedRows = [NSMutableArray array];
    }
    return self;
}

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor colorWithWhite:0.88 alpha:1.0];
    self.title = self.groupName ?: @"Сообщество";
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    [self.view addSubview:self.tableView];
    
    [self setupHeaderView];
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [self loadGroupInfo];
    [self loadWall];
}

- (void)setupHeaderView {
    self.headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 120)];
    self.headerView.backgroundColor = [UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0];
    
    // Градиент (скевоморфизм)
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = self.headerView.bounds;
    gradient.colors = @[(id)[UIColor colorWithRed:0.3 green:0.45 blue:0.7 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0].CGColor];
    [self.headerView.layer insertSublayer:gradient atIndex:0];
    
    self.headerView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.headerView.layer.shadowOffset = CGSizeMake(0, 2);
    self.headerView.layer.shadowOpacity = 0.3;
    self.headerView.layer.shadowRadius = 3;
    
    // Аватар
    self.avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 20, 70, 70)];
    self.avatarView.layer.cornerRadius = 5;
    self.avatarView.layer.borderWidth = 3;
    self.avatarView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.avatarView.clipsToBounds = YES;
    self.avatarView.backgroundColor = [UIColor lightGrayColor];
    self.avatarView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.avatarView.layer.shadowOffset = CGSizeMake(0, 1);
    self.avatarView.layer.shadowOpacity = 0.3;
    self.avatarView.layer.shadowRadius = 2;
    self.avatarView.contentMode = UIViewContentModeScaleAspectFill;
    [self.headerView addSubview:self.avatarView];
    
    // Имя
    self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 20, self.view.bounds.size.width - 120, 24)];
    self.nameLabel.font = [UIFont boldSystemFontOfSize:19];
    self.nameLabel.textColor = [UIColor whiteColor];
    self.nameLabel.shadowColor = [UIColor blackColor];
    self.nameLabel.shadowOffset = CGSizeMake(0, -1);
    self.nameLabel.backgroundColor = [UIColor clearColor];
    self.nameLabel.text = self.groupName ?: @"Загрузка...";
    [self.headerView addSubview:self.nameLabel];
    
    // Статус
    self.statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 50, self.view.bounds.size.width - 120, 18)];
    self.statusLabel.font = [UIFont systemFontOfSize:13];
    self.statusLabel.textColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    self.statusLabel.shadowColor = [UIColor blackColor];
    self.statusLabel.shadowOffset = CGSizeMake(0, -1);
    self.statusLabel.backgroundColor = [UIColor clearColor];
    self.statusLabel.text = @"Загрузка...";
    [self.headerView addSubview:self.statusLabel];
    
    // Кнопка подписки/отписки
    self.followButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.followButton.frame = CGRectMake(100, 75, 100, 28);
    [self.followButton setTitle:@"Подписаться" forState:UIControlStateNormal];
    [self.followButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.followButton.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    self.followButton.layer.cornerRadius = 5;
    self.followButton.layer.masksToBounds = YES;
    self.followButton.layer.shadowColor = [UIColor blackColor].CGColor;
    self.followButton.layer.shadowOffset = CGSizeMake(0, 1);
    self.followButton.layer.shadowOpacity = 0.3;
    self.followButton.layer.shadowRadius = 2;
    [self.followButton addTarget:self action:@selector(followTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.headerView addSubview:self.followButton];
    
    if (self.groupAvatarURL) {
        UIImage *cached = self.imageCache[self.groupAvatarURL];
        if (cached) {
            self.avatarView.image = cached;
        } else {
            [[VKAPIClient sharedClient] downloadImageWithURL:self.groupAvatarURL completion:^(UIImage *image) {
                if (image) {
                    self.imageCache[self.groupAvatarURL] = image;
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.avatarView.image = image;
                    });
                }
            }];
        }
    }
    
    self.tableView.tableHeaderView = self.headerView;
}

- (void)loadGroupInfo {
    NSString *groupIdStr = self.groupId;
    if ([groupIdStr hasPrefix:@"-"]) {
        groupIdStr = [groupIdStr substringFromIndex:1];
    }
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *urlString = [NSString stringWithFormat:@"%@groups.getById?group_id=%@&fields=photo_50,members_count,status,is_member&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], groupIdStr, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || !json[@"response"]) {
                self.statusLabel.text = @"Информация недоступна";
                return;
            }
            NSArray *groups = json[@"response"];
            if (groups.count > 0) {
                self.groupInfo = groups[0];
                [self updateHeaderWithGroupInfo:self.groupInfo];
            }
        });
    });
}

- (void)updateHeaderWithGroupInfo:(NSDictionary *)info {
    NSString *name = info[@"name"] ?: self.groupName;
    self.nameLabel.text = name;
    
    NSString *type = info[@"type"];
    NSString *typeText = @"";
    if ([type isEqualToString:@"group"]) typeText = @"Группа";
    else if ([type isEqualToString:@"page"]) typeText = @"Публичная страница";
    else if ([type isEqualToString:@"event"]) typeText = @"Мероприятие";
    else typeText = @"Сообщество";
    
    NSNumber *members = info[@"members_count"];
    NSString *membersText = members ? [NSString stringWithFormat:@"Участников: %@", members] : @"";
    self.statusLabel.text = membersText.length > 0 ? [NSString stringWithFormat:@"%@ • %@", typeText, membersText] : typeText;
    
    NSString *avatarURL = info[@"photo_50"] ?: self.groupAvatarURL;
    if (avatarURL && ![self.imageCache objectForKey:avatarURL]) {
        [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
            if (image) {
                self.imageCache[avatarURL] = image;
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.avatarView.image = image;
                });
            }
        }];
    }
    self.title = name;
    
    // Определяем членство
    BOOL isMember = NO;
    id isMemberValue = info[@"is_member"];
    if (isMemberValue && ![isMemberValue isKindOfClass:[NSNull class]]) {
        if ([isMemberValue isKindOfClass:[NSNumber class]]) {
            isMember = [isMemberValue boolValue];
        } else if ([isMemberValue isKindOfClass:[NSString class]]) {
            isMember = [isMemberValue boolValue];
        }
    }
    if (isMember) {
        [self.followButton setTitle:@"Отписаться" forState:UIControlStateNormal];
        self.followButton.backgroundColor = [UIColor colorWithRed:0.8 green:0.3 blue:0.3 alpha:1.0];
    } else {
        [self.followButton setTitle:@"Подписаться" forState:UIControlStateNormal];
        self.followButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.6 blue:0.2 alpha:1.0];
    }
}

- (void)followTapped {
    BOOL isMember = NO;
    id isMemberValue = self.groupInfo[@"is_member"];
    if (isMemberValue && ![isMemberValue isKindOfClass:[NSNull class]]) {
        if ([isMemberValue isKindOfClass:[NSNumber class]]) {
            isMember = [isMemberValue boolValue];
        } else if ([isMemberValue isKindOfClass:[NSString class]]) {
            isMember = [isMemberValue boolValue];
        }
    }
    
    // Передаём groupId как есть – клиент сам очистит
    if (isMember) {
        [[VKAPIClient sharedClient] leaveGroup:self.groupId completion:^(BOOL success, NSError *error) {
            if (success) {
                NSMutableDictionary *newInfo = [self.groupInfo mutableCopy];
                newInfo[@"is_member"] = @NO;
                self.groupInfo = newInfo;
                [self updateHeaderWithGroupInfo:self.groupInfo];
            } else {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    } else {
        [[VKAPIClient sharedClient] joinGroup:self.groupId completion:^(BOOL success, NSError *error) {
            if (success) {
                NSMutableDictionary *newInfo = [self.groupInfo mutableCopy];
                newInfo[@"is_member"] = @YES;
                self.groupInfo = newInfo;
                [self updateHeaderWithGroupInfo:self.groupInfo];
            } else {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    }
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadWall {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] getWallPostsWithOwnerId:self.groupId completion:^(NSArray *posts, NSError *error) {
        [self.spinner stopAnimating];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        self.posts = posts;
        [self.tableView reloadData];
    }];
}

- (void)toggleTextExpand:(UIButton *)sender {
    NSIndexPath *indexPath = (NSIndexPath *)objc_getAssociatedObject(sender, "indexPath");
    if (indexPath) {
        if ([self.expandedRows containsObject:indexPath]) [self.expandedRows removeObject:indexPath];
        else [self.expandedRows addObject:indexPath];
        [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.posts.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *post = self.posts[indexPath.row];
    NSString *text = post[@"text"] ?: @"";
    BOOL isExpanded = [self.expandedRows containsObject:indexPath];
    if (!isExpanded && text.length > 100) text = [[text substringToIndex:100] stringByAppendingString:@"..."];
    CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(self.view.bounds.size.width - 40, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
    CGFloat height = textSize.height + 50;
    NSArray *attachments = post[@"attachments"];
    if (attachments.count) {
        if ([attachments[0][@"type"] isEqualToString:@"photo"]) height += 200;
        else if ([attachments[0][@"type"] isEqualToString:@"video"]) height += 150;
    }
    if (!isExpanded && text.length > 100) height += 30;
    return height;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"GroupWallCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    UILabel *textLabel, *statsLabel;
    UIImageView *postImageView, *videoPreviewView;
    UIButton *expandButton;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.layer.shadowColor = [UIColor blackColor].CGColor;
        cell.layer.shadowOffset = CGSizeMake(0, 1);
        cell.layer.shadowOpacity = 0.1;
        cell.layer.shadowRadius = 1;
        cell.layer.masksToBounds = NO;
        
        textLabel = [[UILabel alloc] init]; textLabel.tag = 10; textLabel.numberOfLines = 0; textLabel.font = [UIFont systemFontOfSize:14]; textLabel.backgroundColor = [UIColor clearColor]; textLabel.textColor = [UIColor blackColor]; [cell.contentView addSubview:textLabel];
        statsLabel = [[UILabel alloc] init]; statsLabel.tag = 11; statsLabel.font = [UIFont systemFontOfSize:12]; statsLabel.textColor = [UIColor grayColor]; statsLabel.backgroundColor = [UIColor clearColor]; [cell.contentView addSubview:statsLabel];
        postImageView = [[UIImageView alloc] init]; postImageView.tag = 12; postImageView.contentMode = UIViewContentModeScaleAspectFit; postImageView.backgroundColor = [UIColor clearColor]; [cell.contentView addSubview:postImageView];
        videoPreviewView = [[UIImageView alloc] init]; videoPreviewView.tag = 13; videoPreviewView.contentMode = UIViewContentModeScaleAspectFill; videoPreviewView.clipsToBounds = YES; videoPreviewView.userInteractionEnabled = YES; videoPreviewView.backgroundColor = [UIColor clearColor]; [cell.contentView addSubview:videoPreviewView];
        expandButton = [UIButton buttonWithType:UIButtonTypeCustom]; expandButton.tag = 14; [expandButton setTitle:@"Показать больше" forState:UIControlStateNormal]; [expandButton setTitleColor:[UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0] forState:UIControlStateNormal]; expandButton.titleLabel.font = [UIFont boldSystemFontOfSize:12]; expandButton.backgroundColor = [UIColor clearColor]; [expandButton addTarget:self action:@selector(toggleTextExpand:) forControlEvents:UIControlEventTouchUpInside]; [cell.contentView addSubview:expandButton];
    } else {
        textLabel = (UILabel *)[cell.contentView viewWithTag:10];
        statsLabel = (UILabel *)[cell.contentView viewWithTag:11];
        postImageView = (UIImageView *)[cell.contentView viewWithTag:12];
        videoPreviewView = (UIImageView *)[cell.contentView viewWithTag:13];
        expandButton = (UIButton *)[cell.contentView viewWithTag:14];
    }
    
    NSDictionary *post = self.posts[indexPath.row];
    NSString *fullText = post[@"text"] ?: @"";
    BOOL isExpanded = [self.expandedRows containsObject:indexPath];
    if (isExpanded || fullText.length <= 100) {
        textLabel.text = fullText;
        expandButton.hidden = YES;
    } else {
        textLabel.text = [[fullText substringToIndex:100] stringByAppendingString:@"..."];
        expandButton.hidden = NO;
        objc_setAssociatedObject(expandButton, "indexPath", indexPath, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    CGSize textSize = [textLabel.text sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(self.view.bounds.size.width - 40, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
    textLabel.frame = CGRectMake(10, 8, self.view.bounds.size.width - 20, textSize.height);
    
    NSNumber *likes = post[@"likes"][@"count"];
    NSNumber *comments = post[@"comments"][@"count"];
    statsLabel.frame = CGRectMake(10, textSize.height + 12, 200, 16);
    statsLabel.text = [NSString stringWithFormat:@"❤️ %@  💬 %@", likes ?: @"0", comments ?: @"0"];
    if (!expandButton.hidden) expandButton.frame = CGRectMake(10, textSize.height + 32, 120, 28);
    
    postImageView.hidden = YES;
    videoPreviewView.hidden = YES;
    NSArray *attachments = post[@"attachments"];
    CGFloat offsetY = textSize.height + (expandButton.hidden ? 30 : 60);
    if (attachments.count) {
        NSDictionary *first = attachments[0];
        if ([first[@"type"] isEqualToString:@"photo"]) {
            postImageView.hidden = NO;
            postImageView.frame = CGRectMake(10, offsetY, self.view.bounds.size.width - 20, 200);
            NSString *photoURL = first[@"photo"][@"photo_604"] ?: first[@"photo"][@"photo_130"];
            if (photoURL) {
                UIImage *cached = self.imageCache[photoURL];
                if (cached) postImageView.image = cached;
                else {
                    [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                        if (image) { self.imageCache[photoURL] = image; dispatch_async(dispatch_get_main_queue(), ^{ postImageView.image = image; }); }
                    }];
                }
            }
        } else if ([first[@"type"] isEqualToString:@"video"]) {
            videoPreviewView.hidden = NO;
            videoPreviewView.frame = CGRectMake(10, offsetY, self.view.bounds.size.width - 20, 150);
            NSString *previewURL = first[@"video"][@"photo_320"] ?: first[@"video"][@"photo_130"];
            if (previewURL) {
                UIImage *cached = self.imageCache[previewURL];
                if (cached) videoPreviewView.image = cached;
                else {
                    [[VKAPIClient sharedClient] downloadImageWithURL:previewURL completion:^(UIImage *image) {
                        if (image) { self.imageCache[previewURL] = image; dispatch_async(dispatch_get_main_queue(), ^{ videoPreviewView.image = image; }); }
                    }];
                }
            }
            UIImageView *playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"play_icon"]];
            playIcon.contentMode = UIViewContentModeCenter;
            playIcon.frame = videoPreviewView.bounds;
            [videoPreviewView addSubview:playIcon];
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playVideoFromPost:)];
            objc_setAssociatedObject(tap, "ownerId", [first[@"video"][@"owner_id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            objc_setAssociatedObject(tap, "videoId", [first[@"video"][@"id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [videoPreviewView addGestureRecognizer:tap];
        }
    }
    return cell;
}

- (void)playVideoFromPost:(UITapGestureRecognizer *)gesture {
    NSString *ownerId = objc_getAssociatedObject(gesture, "ownerId");
    NSString *videoId = objc_getAssociatedObject(gesture, "videoId");
    [self playVideoWithOwnerId:ownerId videoId:videoId];
}

- (void)playVideoWithOwnerId:(NSString *)ownerId videoId:(NSString *)videoId {
    VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
    [self.navigationController pushViewController:playerVC animated:YES];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *post = self.posts[indexPath.row];
    PostDetailViewController *detailVC = [[PostDetailViewController alloc] initWithPost:post];
    detailVC.sideMenuController = self.sideMenuController;
    [self.navigationController pushViewController:detailVC animated:YES];
}

@end