#import <UIKit/UIKit.h>

@interface SideMenuViewController : UIViewController
- (void)showMenu;
- (void)switchToViewControllerAtIndex:(NSInteger)index;
@end