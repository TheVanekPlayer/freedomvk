// SearchViewController.h
#import <UIKit/UIKit.h>

@class SideMenuViewController;

@interface SearchViewController : UIViewController
@property (nonatomic, unsafe_unretained) SideMenuViewController *sideMenuController;
@end