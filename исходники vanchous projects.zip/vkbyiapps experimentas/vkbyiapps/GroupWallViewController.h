// GroupWallViewController.h
#import <UIKit/UIKit.h>

@class SideMenuViewController;

@interface GroupWallViewController : UIViewController
@property (nonatomic, unsafe_unretained) SideMenuViewController *sideMenuController;
- (instancetype)initWithGroupId:(NSString *)groupId name:(NSString *)name avatarURL:(NSString *)avatarURL;
@end