// MessagesViewController.h
#import <UIKit/UIKit.h>

@interface MessagesViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end