// ChatViewController.m
#import "ChatViewController.h"
#import "VKAPIClient.h"
#import <AudioToolbox/AudioToolbox.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

#define kMessagesPerPage 30

@interface ChatViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UIAlertViewDelegate, UIActionSheetDelegate> {
    UITableView *tableView;
    NSMutableArray *messages;
    UITextField *inputField;
    UIButton *sendButton;
    UIButton *emojiButton;
    UIView *emojiPanel;
    UIActivityIndicatorView *spinner;
    NSDictionary *userInfo;
    NSInteger loadedOffset;
    BOOL isLoadingMore;
    BOOL noMoreMessages;
    UIActivityIndicatorView *loadingMoreSpinner;
    NSNumber *replyingToMessageId;
    NSNumber *editingMessageId;
    NSNumber *deletingMessageId;
    NSString *peerId;
    BOOL isEmojiMode;
    
    // Данные выбранного долгим тапом сообщения
    NSString *selectedMessageText;
    NSNumber *selectedMessageId;
    NSIndexPath *selectedIndexPath;
    BOOL selectedIsOut;
}
@end

@implementation ChatViewController

- (instancetype)initWithPeerId:(NSString *)aPeerId title:(NSString *)title {
    self = [super init];
    if (self) {
        peerId = aPeerId;
        self.title = title ?: @"Диалог";
        self.hidesBottomBarWhenPushed = YES;
        messages = [NSMutableArray array];
        loadedOffset = 0;
        isLoadingMore = NO;
        noMoreMessages = NO;
        isEmojiMode = NO;
    }
    return self;
}

#pragma mark - Lifecycle

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor colorWithWhite:0.88 alpha:1.0];
    
    tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 44)
                                             style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:tableView];
    
    loadingMoreSpinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    loadingMoreSpinner.frame = CGRectMake(0, 0, self.view.bounds.size.width, 44);
    loadingMoreSpinner.hidesWhenStopped = YES;
    tableView.tableHeaderView = loadingMoreSpinner;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [tableView addGestureRecognizer:tap];
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    longPress.minimumPressDuration = 0.5;
    [tableView addGestureRecognizer:longPress];
    
    // ===== ПАНЕЛЬ ВВОДА =====
    UIView *inputBar = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44)];
    inputBar.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1.0];
    inputBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    inputBar.layer.shadowColor = [UIColor blackColor].CGColor;
    inputBar.layer.shadowOffset = CGSizeMake(0, -1);
    inputBar.layer.shadowOpacity = 0.15;
    inputBar.layer.shadowRadius = 2;
    inputBar.tag = 777;
    [self.view addSubview:inputBar];
    
    emojiButton = [UIButton buttonWithType:UIButtonTypeCustom];
    emojiButton.frame = CGRectMake(4, 4, 36, 36);
    [emojiButton setTitle:@"😊" forState:UIControlStateNormal];
    emojiButton.titleLabel.font = [UIFont systemFontOfSize:20];
    [emojiButton addTarget:self action:@selector(emojiButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [inputBar addSubview:emojiButton];
    
    inputField = [[UITextField alloc] initWithFrame:CGRectMake(44, 4, self.view.bounds.size.width - 44 - 50, 36)];
    inputField.borderStyle = UITextBorderStyleRoundedRect;
    inputField.placeholder = @"Сообщение...";
    inputField.delegate = self;
    inputField.returnKeyType = UIReturnKeySend;
    inputField.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    inputField.backgroundColor = [UIColor whiteColor];
    inputField.font = [UIFont fontWithName:@"HelveticaNeue" size:15];
    [inputBar addSubview:inputField];
    
    [self setupEmojiInputView];
    
    // Восстанавливаем черновик
    NSString *draftKey = [NSString stringWithFormat:@"draft_%@", peerId];
    NSString *draft = [[NSUserDefaults standardUserDefaults] stringForKey:draftKey];
    if (draft.length > 0) inputField.text = draft;
    
    sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sendButton.frame = CGRectMake(self.view.bounds.size.width - 46, 4, 36, 36);
    [sendButton setTitle:@"▶" forState:UIControlStateNormal];
    [sendButton setTitleColor:[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0] forState:UIControlStateNormal];
    sendButton.titleLabel.font = [UIFont systemFontOfSize:20];
    [sendButton addTarget:self action:@selector(sendMessage) forControlEvents:UIControlEventTouchUpInside];
    sendButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [inputBar addSubview:sendButton];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    [self loadUserInfo];
    [self loadHistory];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    // Сохраняем черновик
    NSString *draftKey = [NSString stringWithFormat:@"draft_%@", peerId];
    if (inputField.text.length > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:inputField.text forKey:draftKey];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:draftKey];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)dismissKeyboard { [inputField resignFirstResponder]; }

#pragma mark - Emoji InputView

- (void)setupEmojiInputView {
    CGFloat w = self.view.bounds.size.width;
    emojiPanel = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, 216)];
    emojiPanel.backgroundColor = [UIColor colorWithWhite:0.92 alpha:1.0];
    
    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:emojiPanel.bounds];
    scroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scroll.showsVerticalScrollIndicator = YES;
    scroll.delaysContentTouches = NO;
    scroll.canCancelContentTouches = NO;
    [emojiPanel addSubview:scroll];
    
    NSArray *emojis = @[
                        @"😀", @"😁", @"😂", @"😃", @"😄", @"😅", @"😆", @"😉",
                        @"😊", @"😋", @"😎", @"😍", @"😘", @"😗", @"😙", @"😚",
                        @"🙂", @"😐", @"😑", @"😶", @"😏", @"😣", @"😥", @"😮",
                        @"😯", @"😪", @"😫", @"😴", @"😌", @"😛", @"😜", @"😝",
                        @"😒", @"😓", @"😔", @"😕", @"😲", @"😷", @"😖", @"😞",
                        @"😟", @"😤", @"😢", @"😭", @"😦", @"😧", @"😨", @"😩",
                        @"😬", @"😰", @"😱", @"😳", @"😵", @"😡", @"😠", @"😇",
                        @"❤️", @"💔", @"👍", @"👎", @"👌", @"✌️", @"👋", @"🙏",
                        @"💪", @"🎉", @"🔥", @"✨", @"⭐️", @"🌟", @"🎁", @"🎂",
                        @"🍎", @"🍕", @"☕️", @"🍺", @"🌹", @"🌸", @"🌈", @"☀️"
                        ];
    
    NSInteger perRow = 8;
    CGFloat cellSize = w / perRow;
    NSInteger rows = (emojis.count + perRow - 1) / perRow;
    
    for (NSInteger i = 0; i < emojis.count; i++) {
        NSInteger row = i / perRow;
        NSInteger col = i % perRow;
        
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.frame = CGRectMake(col * cellSize, row * cellSize + 4, cellSize, cellSize);
        b.titleLabel.font = [UIFont systemFontOfSize:28];
        [b setTitle:emojis[i] forState:UIControlStateNormal];
        [b addTarget:self action:@selector(emojiTapped:) forControlEvents:UIControlEventTouchUpInside];
        [scroll addSubview:b];
    }
    
    scroll.contentSize = CGSizeMake(w, rows * cellSize + 8);
}

- (void)emojiButtonTapped {
    if (!isEmojiMode) {
        isEmojiMode = YES;
        inputField.inputView = emojiPanel;
        [inputField reloadInputViews];
        [inputField becomeFirstResponder];
    } else {
        isEmojiMode = NO;
        inputField.inputView = nil;
        [inputField reloadInputViews];
        [inputField becomeFirstResponder];
    }
}

- (void)emojiTapped:(UIButton *)sender {
    NSString *emoji = sender.currentTitle;
    if (!emoji || emoji.length == 0) return;
    inputField.text = [inputField.text stringByAppendingString:emoji];
}

#pragma mark - Long press (UIActionSheet)

- (void)handleLongPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    
    CGPoint point = [gesture locationInView:tableView];
    NSIndexPath *indexPath = [tableView indexPathForRowAtPoint:point];
    if (!indexPath || indexPath.row >= messages.count) return;
    
    NSDictionary *msg = [messages objectAtIndex:indexPath.row];
    
    // Пропускаем разделители дат
    if ([[msg objectForKey:@"type"] isEqualToString:@"__separator__"]) return;
    
    NSString *text = [msg objectForKey:@"text"];
    NSNumber *messageId = [msg objectForKey:@"id"];
    BOOL isOut = [[msg objectForKey:@"out"] boolValue];
    
    if (text.length == 0) text = @"[Вложение]";
    
    // Сохраняем данные выбранного сообщения
    selectedMessageText = text;
    selectedMessageId = messageId;
    selectedIndexPath = indexPath;
    selectedIsOut = isOut;
    
    NSString *title = text.length > 40 ? [[text substringToIndex:40] stringByAppendingString:@"..."] : text;
    
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:title
                                                       delegate:self
                                              cancelButtonTitle:nil
                                         destructiveButtonTitle:nil
                                              otherButtonTitles:nil];
    
    [sheet addButtonWithTitle:@"📋  Копировать"];
    [sheet addButtonWithTitle:@"↩️  Ответить"];
    
    if (isOut && messageId) {
        [sheet addButtonWithTitle:@"✏️  Редактировать"];
        [sheet addButtonWithTitle:@"🗑  Удалить"];
    }
    
    // Индекс кнопки "Отмена" = количество добавленных
    NSInteger cancelIndex = sheet.numberOfButtons;
    [sheet addButtonWithTitle:@"Отмена"];
    sheet.cancelButtonIndex = cancelIndex;
    
    sheet.tag = 500;
    
    [sheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (actionSheet.tag != 500) return;
    
    NSString *buttonTitle = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    // ===== КОПИРОВАТЬ =====
    if ([buttonTitle rangeOfString:@"Копировать"].location != NSNotFound) {
        [UIPasteboard generalPasteboard].string = selectedMessageText;
        return;
    }
    
    // ===== ОТВЕТИТЬ =====
    if ([buttonTitle rangeOfString:@"Ответить"].location != NSNotFound) {
        if (!selectedMessageId) return;
        inputField.text = [NSString stringWithFormat:@"[%@]\n", selectedMessageText];
        replyingToMessageId = selectedMessageId;
        [inputField becomeFirstResponder];
        return;
    }
    
    // ===== РЕДАКТИРОВАТЬ =====
    if ([buttonTitle rangeOfString:@"Редактировать"].location != NSNotFound) {
        if (!selectedMessageId) return;
        editingMessageId = selectedMessageId;
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Редактировать"
                                                        message:@"Введите новый текст"
                                                       delegate:self
                                              cancelButtonTitle:@"Отмена"
                                              otherButtonTitles:@"Сохранить", nil];
        alert.alertViewStyle = UIAlertViewStylePlainTextInput;
        UITextField *tf = [alert textFieldAtIndex:0];
        tf.text = selectedMessageText;
        alert.tag = 200;
        [alert show];
        return;
    }
    
    // ===== УДАЛИТЬ =====
    if ([buttonTitle rangeOfString:@"Удалить"].location != NSNotFound) {
        if (!selectedMessageId) return;
        deletingMessageId = selectedMessageId;
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Удалить сообщение?"
                                                        message:@"Это действие нельзя отменить"
                                                       delegate:self
                                              cancelButtonTitle:@"Отмена"
                                              otherButtonTitles:@"Удалить", nil];
        alert.tag = 400;
        [alert show];
        return;
    }
    
    // "Отмена" — просто ничего не делаем
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    // ===== СОХРАНЕНИЕ РЕДАКТИРОВАНИЯ =====
    if (alertView.tag == 200 && buttonIndex == 1) {
        NSNumber *messageId = editingMessageId;
        NSIndexPath *indexPath = selectedIndexPath;
        UITextField *tf = [alertView textFieldAtIndex:0];
        NSString *newText = tf.text;
        if (!messageId || !newText.length || !indexPath) return;
        
        [spinner startAnimating];
        [[VKAPIClient sharedClient] editMessage:newText forMessageId:messageId peerId:peerId completion:^(BOOL success, NSError *error) {
            [spinner stopAnimating];
            if (success && indexPath.row < messages.count) {
                NSMutableDictionary *updatedMsg = [messages[indexPath.row] mutableCopy];
                [updatedMsg setObject:newText forKey:@"text"];
                [messages replaceObjectAtIndex:indexPath.row withObject:updatedMsg];
                [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            }
            editingMessageId = nil;
        }];
    }
    
    // ===== ПОДТВЕРЖДЕНИЕ УДАЛЕНИЯ =====
    else if (alertView.tag == 400 && buttonIndex == 1) {
        if (!deletingMessageId) return;
        NSNumber *messageId = deletingMessageId;
        NSIndexPath *indexPath = selectedIndexPath;
        
        [spinner startAnimating];
        [[VKAPIClient sharedClient] deleteMessage:messageId forPeerId:peerId completion:^(BOOL success, NSError *error) {
            [spinner stopAnimating];
            
            // Удаляем локально в любом случае (сервер может не поддерживать удаление)
            if (indexPath && indexPath.row < messages.count) {
                NSMutableArray *newMessages = [NSMutableArray arrayWithArray:messages];
                [newMessages removeObjectAtIndex:indexPath.row];
                
                // Если перед удалённым был разделитель и после нет сообщений того же дня — убираем разделитель
                if (indexPath.row > 0 && indexPath.row - 1 < newMessages.count) {
                    NSDictionary *prev = [newMessages objectAtIndex:indexPath.row - 1];
                    if ([[prev objectForKey:@"type"] isEqualToString:@"__separator__"]) {
                        BOOL shouldRemove = (indexPath.row >= newMessages.count);
                        if (!shouldRemove) {
                            NSDictionary *next = [newMessages objectAtIndex:indexPath.row];
                            if ([[next objectForKey:@"type"] isEqualToString:@"__separator__"]) {
                                shouldRemove = YES;
                            }
                        }
                        if (shouldRemove) {
                            [newMessages removeObjectAtIndex:indexPath.row - 1];
                        }
                    }
                }
                
                messages = newMessages;
                [tableView reloadData];
            }
            
            if (!success) {
                NSLog(@"⚠️ Сервер не подтвердил удаление: %@", error);
            }
            deletingMessageId = nil;
        }];
    }
}

#pragma mark - Отправка

- (void)sendMessage {
    NSString *text = inputField.text;
    if (text.length == 0) return;
    inputField.text = @"";
    NSNumber *replyTo = replyingToMessageId;
    replyingToMessageId = nil;
    
    // Удаляем черновик
    NSString *draftKey = [NSString stringWithFormat:@"draft_%@", peerId];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:draftKey];
    
    NSMutableDictionary *localMsg = [NSMutableDictionary dictionary];
    [localMsg setObject:text forKey:@"text"];
    [localMsg setObject:[NSNumber numberWithBool:YES] forKey:@"out"];
    [localMsg setObject:[NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]] forKey:@"date"];
    if (replyTo) [localMsg setObject:replyTo forKey:@"reply_to"];
    
    [messages addObject:localMsg];
    [tableView reloadData];
    [self scrollToBottom];
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"ChatSoundEnabled"]) {
        AudioServicesPlaySystemSound(1003);
    }
    
    if (replyTo) {
        [[VKAPIClient sharedClient] sendMessage:text toPeerId:peerId replyTo:replyTo completion:^(BOOL success, NSError *error) {}];
    } else {
        [[VKAPIClient sharedClient] sendMessage:text toPeerId:peerId completion:^(BOOL success, NSError *error) {}];
    }
}

#pragma mark - Загрузка

- (void)loadUserInfo {
    NSInteger peer = [peerId integerValue];
    if (peer > 0) {
        [[VKAPIClient sharedClient] profileGetInfoWithUserId:peerId completion:^(NSDictionary *aUserInfo, NSError *error) {
            if (!error && [aUserInfo isKindOfClass:[NSDictionary class]]) {
                userInfo = aUserInfo;
                NSString *fn = [aUserInfo objectForKey:@"first_name"] ?: @"";
                NSString *ln = [aUserInfo objectForKey:@"last_name"] ?: @"";
                if (fn.length > 0 || ln.length > 0) {
                    NSString *newTitle = [NSString stringWithFormat:@"%@ %@", fn, ln];
                    self.title = newTitle;
                    self.navigationItem.title = newTitle;
                }
            }
        }];
    }
}

- (void)loadHistory {
    [self loadHistoryWithOffset:0];
}

- (void)loadHistoryWithOffset:(NSInteger)offset {
    if (isLoadingMore) return;
    if (offset > 0 && noMoreMessages) return;
    
    isLoadingMore = YES;
    if (offset == 0) [spinner startAnimating];
    else [loadingMoreSpinner startAnimating];
    
    [[VKAPIClient sharedClient] getMessageHistoryForPeerId:peerId offset:offset count:kMessagesPerPage completion:^(NSArray *items, NSError *error) {
        isLoadingMore = NO;
        if (offset == 0) [spinner stopAnimating];
        else [loadingMoreSpinner stopAnimating];
        if (error) return;
        
        if (![items isKindOfClass:[NSArray class]]) items = @[];
        if (items.count < kMessagesPerPage) noMoreMessages = YES;
        
        CGPoint oldOffset = tableView.contentOffset;
        CGFloat oldHeight = tableView.contentSize.height;
        
        NSArray *itemsWithSeparators = [self insertDateSeparators:items];
        
        if (offset == 0) {
            [messages removeAllObjects];
            [messages addObjectsFromArray:itemsWithSeparators];
        } else {
            NSMutableArray *newArr = [NSMutableArray arrayWithArray:itemsWithSeparators];
            [newArr addObjectsFromArray:messages];
            [messages removeAllObjects];
            [messages addObjectsFromArray:newArr];
        }
        loadedOffset += items.count;
        
        [tableView reloadData];
        
        if (offset == 0) {
            [self scrollToBottom];
            [[VKAPIClient sharedClient] markMessagesAsReadWithPeerId:peerId completion:^(BOOL success, NSError *error) {}];
        } else {
            CGFloat newHeight = tableView.contentSize.height;
            CGFloat delta = newHeight - oldHeight;
            tableView.contentOffset = CGPointMake(oldOffset.x, oldOffset.y + delta);
        }
    }];
}

- (NSArray *)insertDateSeparators:(NSArray *)srcMessages {
    NSMutableArray *result = [NSMutableArray array];
    NSDateFormatter *dayFmt = [[NSDateFormatter alloc] init];
    dayFmt.dateFormat = @"yyyy-MM-dd";
    
    NSString *lastDayKey = nil;
    
    for (NSDictionary *msg in srcMessages) {
        if (![msg isKindOfClass:[NSDictionary class]]) continue;
        NSTimeInterval ts = [[msg objectForKey:@"date"] doubleValue];
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:ts];
        NSString *dayKey = [dayFmt stringFromDate:date];
        
        if (![dayKey isEqualToString:lastDayKey]) {
            NSMutableDictionary *sep = [NSMutableDictionary dictionary];
            [sep setObject:@"__separator__" forKey:@"type"];
            [sep setObject:@(ts) forKey:@"date"];
            [sep setObject:[self humanDateString:date] forKey:@"human"];
            [result addObject:sep];
            lastDayKey = dayKey;
        }
        [result addObject:msg];
    }
    return result;
}

- (NSString *)humanDateString:(NSDate *)date {
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *comp = [cal components:(NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit)
                                    fromDate:date
                                      toDate:[NSDate date]
                                     options:0];
    if (comp.year == 0 && comp.month == 0 && comp.day == 0) return @"Сегодня";
    if (comp.year == 0 && comp.month == 0 && comp.day == 1) return @"Вчера";
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    df.dateFormat = @"d MMMM";
    df.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"ru_RU"];
    return [df stringFromDate:date];
}

- (void)scrollToBottom {
    if (messages.count) {
        NSIndexPath *ip = [NSIndexPath indexPathForRow:messages.count-1 inSection:0];
        [tableView scrollToRowAtIndexPath:ip atScrollPosition:UITableViewScrollPositionBottom animated:NO];
    }
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return messages.count;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= messages.count) return 44;
    NSDictionary *msg = [messages objectAtIndex:indexPath.row];
    
    if ([[msg objectForKey:@"type"] isEqualToString:@"__separator__"]) {
        return 30;
    }
    
    NSString *text = [msg objectForKey:@"text"] ?: @"";
    if (text.length == 0) text = @"[Вложение]";
    
    CGSize size = [text sizeWithFont:[UIFont fontWithName:@"HelveticaNeue" size:15]
                   constrainedToSize:CGSizeMake(self.view.bounds.size.width - 90, CGFLOAT_MAX)
                       lineBreakMode:UILineBreakModeWordWrap];
    return MAX(size.height + 42, 56);
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"ChatCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    UIImageView *bubbleView;
    UILabel *messageLabel;
    UILabel *timeLabel;
    UILabel *separatorLabel;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        bubbleView = [[UIImageView alloc] init];
        bubbleView.tag = 100;
        bubbleView.contentMode = UIViewContentModeScaleToFill;
        [cell.contentView addSubview:bubbleView];
        
        messageLabel = [[UILabel alloc] init];
        messageLabel.tag = 101;
        messageLabel.numberOfLines = 0;
        messageLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:15];
        messageLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:messageLabel];
        
        timeLabel = [[UILabel alloc] init];
        timeLabel.tag = 102;
        timeLabel.font = [UIFont systemFontOfSize:10];
        timeLabel.textAlignment = NSTextAlignmentRight;
        timeLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:timeLabel];
        
        separatorLabel = [[UILabel alloc] init];
        separatorLabel.tag = 103;
        separatorLabel.font = [UIFont boldSystemFontOfSize:11];
        separatorLabel.textAlignment = NSTextAlignmentCenter;
        separatorLabel.textColor = [UIColor colorWithWhite:0.4 alpha:1.0];
        separatorLabel.backgroundColor = [UIColor colorWithWhite:0.85 alpha:0.9];
        separatorLabel.layer.cornerRadius = 9;
        separatorLabel.clipsToBounds = YES;
        [cell.contentView addSubview:separatorLabel];
    } else {
        bubbleView = (UIImageView *)[cell.contentView viewWithTag:100];
        messageLabel = (UILabel *)[cell.contentView viewWithTag:101];
        timeLabel = (UILabel *)[cell.contentView viewWithTag:102];
        separatorLabel = (UILabel *)[cell.contentView viewWithTag:103];
    }
    
    if (indexPath.row >= messages.count) return cell;
    NSDictionary *msg = [messages objectAtIndex:indexPath.row];
    if (![msg isKindOfClass:[NSDictionary class]]) return cell;
    
    // ===== РАЗДЕЛИТЕЛЬ ДАТЫ =====
    if ([[msg objectForKey:@"type"] isEqualToString:@"__separator__"]) {
        bubbleView.image = nil;
        bubbleView.backgroundColor = [UIColor clearColor];
        bubbleView.hidden = YES;
        messageLabel.hidden = YES;
        timeLabel.hidden = YES;
        separatorLabel.hidden = NO;
        
        NSString *human = [msg objectForKey:@"human"] ?: @"";
        separatorLabel.text = human;
        CGSize s = [human sizeWithFont:separatorLabel.font];
        CGFloat w = s.width + 24;
        separatorLabel.frame = CGRectMake((self.view.bounds.size.width - w) / 2.0, 7, w, 18);
        return cell;
    }
    
    bubbleView.hidden = NO;
    messageLabel.hidden = NO;
    timeLabel.hidden = NO;
    separatorLabel.hidden = YES;
    
    BOOL isOut = [[msg objectForKey:@"out"] boolValue];
    bubbleView.image = nil;
    bubbleView.backgroundColor = [UIColor clearColor];
    messageLabel.text = @"";
    timeLabel.text = @"";
    
    NSString *text = [msg objectForKey:@"text"] ?: @"";
    if (text.length == 0) text = @"[Вложение]";
    
    messageLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:15];
    CGSize textSize = [text sizeWithFont:messageLabel.font
                       constrainedToSize:CGSizeMake(self.view.bounds.size.width - 90, CGFLOAT_MAX)
                           lineBreakMode:UILineBreakModeWordWrap];
    CGFloat bubbleWidth = textSize.width + 32;
    CGFloat bubbleHeight = textSize.height + 24 + 14;
    CGFloat maxWidth = self.view.bounds.size.width - 50;
    if (bubbleWidth > maxWidth) bubbleWidth = maxWidth;
    if (bubbleWidth < 80) bubbleWidth = 80;
    
    CGFloat x = isOut ? self.view.bounds.size.width - bubbleWidth - 10 : 10;
    bubbleView.frame = CGRectMake(x, 2, bubbleWidth, bubbleHeight);
    
    UIImage *bubbleImage = [UIImage imageNamed:isOut ? @"bubble_right.png" : @"bubble_left.png"];
    if (bubbleImage) {
        bubbleView.image = [bubbleImage resizableImageWithCapInsets:UIEdgeInsetsMake(16, 20, 16, 20)];
        messageLabel.textColor = isOut ? [UIColor whiteColor] : [UIColor blackColor];
    } else {
        if (isOut) {
            bubbleView.backgroundColor = [UIColor colorWithRed:0.2 green:0.5 blue:0.9 alpha:1.0];
            messageLabel.textColor = [UIColor whiteColor];
        } else {
            bubbleView.backgroundColor = [UIColor whiteColor];
            bubbleView.layer.cornerRadius = 14;
            bubbleView.layer.borderWidth = 1;
            bubbleView.layer.borderColor = [UIColor colorWithWhite:0.8 alpha:1.0].CGColor;
            messageLabel.textColor = [UIColor blackColor];
        }
    }
    
    messageLabel.text = text;
    messageLabel.frame = CGRectMake(x + 16, 10, bubbleWidth - 32, textSize.height);
    
    // ===== ВРЕМЯ =====
    NSTimeInterval ts = [[msg objectForKey:@"date"] doubleValue];
    if (ts > 0) {
        NSDate *d = [NSDate dateWithTimeIntervalSince1970:ts];
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateFormat = @"HH:mm";
        timeLabel.text = [df stringFromDate:d];
        timeLabel.textColor = isOut ? [UIColor colorWithWhite:0.9 alpha:0.75]
        : [UIColor colorWithWhite:0.5 alpha:1.0];
    } else {
        timeLabel.text = @"";
    }
    timeLabel.frame = CGRectMake(x + bubbleWidth - 50, bubbleView.frame.origin.y + bubbleHeight - 14, 40, 12);
    
    return cell;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView.contentOffset.y < 100 && !isLoadingMore && !noMoreMessages && messages.count > 0) {
        [self loadHistoryWithOffset:loadedOffset];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self sendMessage];
    return YES;
}

#pragma mark - Keyboard

- (void)keyboardWillShow:(NSNotification *)notification {
    CGRect keyboardFrame = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat height = keyboardFrame.size.height;
    NSTimeInterval duration = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect frame = tableView.frame;
        frame.size.height = self.view.bounds.size.height - height - 44;
        tableView.frame = frame;
        UIView *inputBar = [self.view viewWithTag:777];
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - height - 44, self.view.bounds.size.width, 44);
        [self scrollToBottom];
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSTimeInterval duration = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect frame = tableView.frame;
        frame.size.height = self.view.bounds.size.height - 44;
        tableView.frame = frame;
        UIView *inputBar = [self.view viewWithTag:777];
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44);
    }];
}

@end