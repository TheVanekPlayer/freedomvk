// PhotosViewController.h
#import <UIKit/UIKit.h>

@interface PhotosViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end