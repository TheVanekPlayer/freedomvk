// StickersViewController.m
#import "StickersViewController.h"
#import "VKAPIClient.h"

@interface StickersViewController () <UICollectionViewDataSource, UICollectionViewDelegate>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSArray *stickers;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@end

@implementation StickersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Стикеры";
    self.view.backgroundColor = [UIColor whiteColor];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(100, 100);
    layout.minimumInteritemSpacing = 5;
    layout.minimumLineSpacing = 5;
    self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"StickerCell"];
    [self.view addSubview:self.collectionView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *cancelBtn = [[UIBarButtonItem alloc] initWithTitle:@"Закрыть" style:UIBarButtonItemStylePlain target:self action:@selector(cancelTapped)];
    self.navigationItem.leftBarButtonItem = cancelBtn;
    
    [self loadStickers];
}

- (void)cancelTapped {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)loadStickers {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] getStickerPacksWithCompletion:^(NSArray *packs, NSError *error) {
        if (error) {
            [self.spinner stopAnimating];
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        // Берем первый пак для простоты
        if (packs.count > 0) {
            NSDictionary *firstPack = packs[0];
            NSInteger packId = [firstPack[@"id"] integerValue];
            [[VKAPIClient sharedClient] getStickersForPackId:packId completion:^(NSArray *stickers, NSError *error2) {
                [self.spinner stopAnimating];
                if (!error2) {
                    self.stickers = stickers;
                    [self.collectionView reloadData];
                } else {
                    [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error2.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                }
            }];
        } else {
            [self.spinner stopAnimating];
            [[[UIAlertView alloc] initWithTitle:@"Инфо" message:@"Нет стикерпаков" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        }
    }];
}

#pragma mark - UICollectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.stickers.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"StickerCell" forIndexPath:indexPath];
    UIImageView *imageView = (UIImageView *)[cell.contentView viewWithTag:100];
    if (!imageView) {
        imageView = [[UIImageView alloc] initWithFrame:cell.contentView.bounds];
        imageView.tag = 100;
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        [cell.contentView addSubview:imageView];
    }
    NSDictionary *sticker = self.stickers[indexPath.row];
    NSString *stickerId = [sticker[@"id"] stringValue];
    imageView.image = nil;
    [[VKAPIClient sharedClient] getStickerImageWithId:stickerId completion:^(UIImage *image, NSError *error) {
        if (image) {
            dispatch_async(dispatch_get_main_queue(), ^{
                imageView.image = image;
            });
        }
    }];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *sticker = self.stickers[indexPath.row];
    NSString *stickerId = [sticker[@"id"] stringValue];
    if (self.stickerSelectedBlock) {
        self.stickerSelectedBlock(stickerId);
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end