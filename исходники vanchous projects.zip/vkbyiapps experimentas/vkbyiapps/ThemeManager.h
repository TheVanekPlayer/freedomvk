// ThemeManager.h
#import <UIKit/UIKit.h>

@interface ThemeManager : NSObject

+ (BOOL)isDarkTheme;
+ (void)setDarkTheme:(BOOL)dark;
+ (void)applyThemeToWindow:(UIWindow *)window;

+ (UIColor *)backgroundColor;
+ (UIImage *)backgroundImage;
+ (UIColor *)textColor;
+ (UIColor *)cellBackgroundColor;
+ (UIColor *)cellTextColor;
+ (UIColor *)separatorColor;
+ (UIColor *)navigationBarTopColor;
+ (UIColor *)navigationBarBottomColor;
+ (UIColor *)navigationBarTintColor;
+ (UIColor *)navigationBarTitleColor;

@end

extern NSString * const ThemeDidChangeNotification;