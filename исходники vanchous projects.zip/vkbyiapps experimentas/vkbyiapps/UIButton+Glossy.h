// UIButton+Glossy.h
#import <UIKit/UIKit.h>

@interface UIButton (Glossy)
- (void)makeGlossy;
@end