//
//  vkbyiappsTests.h
//  vkbyiappsTests
//
//  Created by matrix on 31.12.00.
//  Copyright (c) 2000 matrix. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface vkbyiappsTests : SenTestCase

@end
