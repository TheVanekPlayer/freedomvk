//
//  vkbyiappsTests.m
//  vkbyiappsTests
//
//  Created by matrix on 31.12.00.
//  Copyright (c) 2000 matrix. All rights reserved.
//

#import "vkbyiappsTests.h"

@implementation vkbyiappsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in vkbyiappsTests");
}

@end
