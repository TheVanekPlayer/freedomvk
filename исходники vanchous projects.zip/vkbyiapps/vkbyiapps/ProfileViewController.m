// ProfileViewController.m
#import "ProfileViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "ChatViewController.h"
#import "PostDetailViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface ProfileViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, copy) NSString *userId;
@property (nonatomic, strong) NSDictionary *userInfo;
@property (nonatomic, strong) NSArray *wallPosts;
@property (nonatomic, strong) NSMutableDictionary *imageCache;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UIImageView *avatarView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UILabel *locationLabel;
@property (nonatomic, strong) UIButton *messageButton;
@property (nonatomic, strong) UIButton *followButton; // добавили
@property (nonatomic, strong) UITableView *wallTableView;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, assign) NSInteger friendStatus;
@end

@implementation ProfileViewController

- (instancetype)initWithUserId:(NSString *)userId {
    self = [super init];
    if (self) {
        _userId = userId;
        _imageCache = [NSMutableDictionary dictionary];
        _friendStatus = 0;
    }
    return self;
}

- (instancetype)initWithCurrentUser {
    return [self initWithUserId:[[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Профиль";
    self.view.backgroundColor = [UIColor colorWithWhite:0.88 alpha:1.0];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [self setupUI];
    [self loadProfile];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)setupUI {
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.scrollView];
    
    // Шапка профиля с градиентом (как в VK)
    self.headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 160)];
    self.headerView.backgroundColor = [UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0];
    
    // Градиент
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = self.headerView.bounds;
    gradient.colors = @[(id)[UIColor colorWithRed:0.3 green:0.45 blue:0.7 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0].CGColor];
    gradient.locations = @[@0, @1];
    [self.headerView.layer insertSublayer:gradient atIndex:0];
    
    // Тень
    self.headerView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.headerView.layer.shadowOffset = CGSizeMake(0, 2);
    self.headerView.layer.shadowOpacity = 0.3;
    self.headerView.layer.shadowRadius = 3;
    [self.scrollView addSubview:self.headerView];
    
    // Аватар
    self.avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 20, 80, 80)];
    self.avatarView.layer.cornerRadius = 5;
    self.avatarView.layer.borderWidth = 3;
    self.avatarView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.avatarView.clipsToBounds = YES;
    self.avatarView.backgroundColor = [UIColor lightGrayColor];
    self.avatarView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.avatarView.layer.shadowOffset = CGSizeMake(0, 1);
    self.avatarView.layer.shadowOpacity = 0.3;
    self.avatarView.layer.shadowRadius = 2;
    self.avatarView.contentMode = UIViewContentModeScaleAspectFill;
    [self.headerView addSubview:self.avatarView];
    
    // Имя
    self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 25, self.view.bounds.size.width - 130, 24)];
    self.nameLabel.font = [UIFont boldSystemFontOfSize:19];
    self.nameLabel.textColor = [UIColor whiteColor];
    self.nameLabel.shadowColor = [UIColor blackColor];
    self.nameLabel.shadowOffset = CGSizeMake(0, -1);
    self.nameLabel.backgroundColor = [UIColor clearColor];
    [self.headerView addSubview:self.nameLabel];
    
    // Статус
    self.statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 55, self.view.bounds.size.width - 130, 18)];
    self.statusLabel.font = [UIFont systemFontOfSize:13];
    self.statusLabel.textColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    self.statusLabel.shadowColor = [UIColor blackColor];
    self.statusLabel.shadowOffset = CGSizeMake(0, -1);
    self.statusLabel.backgroundColor = [UIColor clearColor];
    [self.headerView addSubview:self.statusLabel];
    
    // Город/дата
    self.locationLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 77, self.view.bounds.size.width - 130, 18)];
    self.locationLabel.font = [UIFont systemFontOfSize:12];
    self.locationLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    self.locationLabel.shadowColor = [UIColor blackColor];
    self.locationLabel.shadowOffset = CGSizeMake(0, -1);
    self.locationLabel.backgroundColor = [UIColor clearColor];
    [self.headerView addSubview:self.locationLabel];
    
    // Кнопка "Сообщение" (градиентная)
    self.messageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.messageButton.frame = CGRectMake(110, 105, 100, 30);
    [self.messageButton setTitle:@"Сообщение" forState:UIControlStateNormal];
    [self.messageButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.messageButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    
    CAGradientLayer *btnGradient = [CAGradientLayer layer];
    btnGradient.frame = self.messageButton.bounds;
    btnGradient.cornerRadius = 5;
    btnGradient.colors = @[(id)[UIColor colorWithRed:0.4 green:0.6 blue:0.9 alpha:1.0].CGColor,
                           (id)[UIColor colorWithRed:0.1 green:0.25 blue:0.5 alpha:1.0].CGColor];
    [self.messageButton.layer insertSublayer:btnGradient atIndex:0];
    self.messageButton.layer.cornerRadius = 5;
    self.messageButton.layer.masksToBounds = YES;
    self.messageButton.layer.shadowColor = [UIColor blackColor].CGColor;
    self.messageButton.layer.shadowOffset = CGSizeMake(0, 1);
    self.messageButton.layer.shadowOpacity = 0.3;
    self.messageButton.layer.shadowRadius = 2;
    [self.messageButton addTarget:self action:@selector(sendMessageTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.headerView addSubview:self.messageButton];
    
    // Кнопка "Подписаться"
    self.followButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.followButton.frame = CGRectMake(220, 105, 90, 30);
    [self.followButton setTitle:@"Подписаться" forState:UIControlStateNormal];
    [self.followButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.followButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    self.followButton.layer.cornerRadius = 5;
    self.followButton.layer.masksToBounds = YES;
    self.followButton.layer.shadowColor = [UIColor blackColor].CGColor;
    self.followButton.layer.shadowOffset = CGSizeMake(0, 1);
    self.followButton.layer.shadowOpacity = 0.3;
    self.followButton.layer.shadowRadius = 2;
    [self.followButton addTarget:self action:@selector(followTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.headerView addSubview:self.followButton];
    
    // Таблица стены
    self.wallTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 160, self.view.bounds.size.width, 0) style:UITableViewStylePlain];
    self.wallTableView.delegate = self;
    self.wallTableView.dataSource = self;
    self.wallTableView.backgroundColor = [UIColor clearColor];
    self.wallTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.wallTableView.separatorColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    [self.scrollView addSubview:self.wallTableView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
}

- (void)loadProfile {
    [self.spinner startAnimating];
    // Запрашиваем пользователя с friend_status
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *urlString = [NSString stringWithFormat:@"%@users.get?user_ids=%@&fields=photo_100,photo_50,online,last_seen,city,bdate,friend_status&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], self.userId, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || !json[@"response"] || [json[@"response"] count] == 0) {
                [self.spinner stopAnimating];
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription ?: @"Не удалось загрузить профиль" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                return;
            }
            self.userInfo = json[@"response"][0];
            self.friendStatus = [self.userInfo[@"friend_status"] integerValue];
            [self updateUI];
            [[VKAPIClient sharedClient] getWallPostsWithOwnerId:self.userId completion:^(NSArray *posts, NSError *wallError) {
                [self.spinner stopAnimating];
                if (wallError) {
                    [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:wallError.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                    return;
                }
                self.wallPosts = posts ?: @[];
                [self.wallTableView reloadData];
                [self adjustScrollViewHeight];
            }];
        });
    });
}

- (void)updateUI {
    NSString *firstName = self.userInfo[@"first_name"] ?: @"";
    NSString *lastName = self.userInfo[@"last_name"] ?: @"";
    self.nameLabel.text = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
    
    NSNumber *online = self.userInfo[@"online"];
    if ([online boolValue]) {
        self.statusLabel.text = @"онлайн";
        self.statusLabel.textColor = [UIColor colorWithRed:0.6 green:1.0 blue:0.6 alpha:1.0];
    } else {
        NSInteger last = [self.userInfo[@"last_seen"][@"time"] integerValue];
        if (last) {
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:last];
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            df.dateFormat = @"dd.MM.yyyy HH:mm";
            self.statusLabel.text = [NSString stringWithFormat:@"был(а) %@", [df stringFromDate:date]];
        } else {
            self.statusLabel.text = @"не в сети";
        }
        self.statusLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    }
    
    NSString *bdate = self.userInfo[@"bdate"];
    NSString *city = self.userInfo[@"city"][@"title"];
    NSMutableString *loc = [NSMutableString string];
    if (bdate.length) [loc appendString:bdate];
    if (city.length) {
        if (loc.length) [loc appendString:@", "];
        [loc appendString:city];
    }
    self.locationLabel.text = loc.length ? loc : @"нет данных";
    
    NSString *avatarURL = self.userInfo[@"photo_100"] ?: self.userInfo[@"photo_50"];
    if (avatarURL) {
        [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
            if (image) dispatch_async(dispatch_get_main_queue(), ^{ self.avatarView.image = image; });
        }];
    }
    
    // Настройка кнопки подписки
    NSString *currentUserId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    if ([self.userId isEqualToString:currentUserId]) {
        self.followButton.hidden = YES;
        return;
    }
    self.followButton.hidden = NO;
    if (self.friendStatus == 3) {
        [self.followButton setTitle:@"Отписаться" forState:UIControlStateNormal];
        self.followButton.backgroundColor = [UIColor colorWithRed:0.8 green:0.3 blue:0.3 alpha:1.0];
    } else if (self.friendStatus == 2) {
        [self.followButton setTitle:@"Заявка отправлена" forState:UIControlStateNormal];
        self.followButton.backgroundColor = [UIColor grayColor];
        self.followButton.enabled = NO;
    } else {
        [self.followButton setTitle:@"Подписаться" forState:UIControlStateNormal];
        self.followButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.6 blue:0.2 alpha:1.0];
        self.followButton.enabled = YES;
    }
}

- (void)followTapped {
    if (self.friendStatus == 3) {
        [[VKAPIClient sharedClient] unfollowUser:self.userId completion:^(BOOL success, NSError *error) {
            if (success) {
                self.friendStatus = 1;
                [self updateUI];
            } else {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    } else if (self.friendStatus == 1) {
        [[VKAPIClient sharedClient] followUser:self.userId completion:^(BOOL success, NSError *error) {
            if (success) {
                self.friendStatus = 3;
                [self updateUI];
            } else {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    }
}

- (void)adjustScrollViewHeight {
    CGFloat tableHeight = self.wallTableView.contentSize.height;
    if (tableHeight < 50) tableHeight = 200;
    CGRect frame = self.wallTableView.frame;
    frame.size.height = tableHeight;
    self.wallTableView.frame = frame;
    self.scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, frame.origin.y + frame.size.height + 20);
}

- (void)sendMessageTapped {
    ChatViewController *chatVC = [[ChatViewController alloc] initWithPeerId:self.userId title:self.nameLabel.text];
    [self.navigationController pushViewController:chatVC animated:YES];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.wallPosts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"WallCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.textLabel.numberOfLines = 0;
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.layer.shadowColor = [UIColor blackColor].CGColor;
        cell.layer.shadowOffset = CGSizeMake(0, 1);
        cell.layer.shadowOpacity = 0.1;
        cell.layer.shadowRadius = 1;
        cell.layer.masksToBounds = NO;
    }
    NSDictionary *post = self.wallPosts[indexPath.row];
    cell.textLabel.text = post[@"text"] ?: @"";
    cell.detailTextLabel.text = [NSString stringWithFormat:@"❤️ %@  💬 %@", post[@"likes"][@"count"] ?: @"0", post[@"comments"][@"count"] ?: @"0"];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *text = self.wallPosts[indexPath.row][@"text"] ?: @"";
    CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(self.view.bounds.size.width - 40, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
    return size.height + 35;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *post = self.wallPosts[indexPath.row];
    PostDetailViewController *detailVC = [[PostDetailViewController alloc] initWithPost:post];
    [self.navigationController pushViewController:detailVC animated:YES];
}

@end