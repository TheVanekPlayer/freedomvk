#import <UIKit/UIKit.h>

@interface FriendsViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end