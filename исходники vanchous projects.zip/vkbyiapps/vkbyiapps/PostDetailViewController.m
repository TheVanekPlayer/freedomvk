// PostDetailViewController.m
#import "PostDetailViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "ProfileViewController.h"
#import "GroupWallViewController.h"
#import "VideoPlayerViewController.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

@interface PostDetailViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
@property (nonatomic, strong) NSDictionary *post;
@property (nonatomic, strong) NSArray *comments;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSMutableDictionary *imageCache;
@property (nonatomic, strong) UIView *inputBar;
@property (nonatomic, strong) UITextField *commentField;
@property (nonatomic, strong) UIButton *sendButton;
@property (nonatomic, assign) BOOL postLiked;
@property (nonatomic, assign) NSInteger postLikesCount;
@property (nonatomic, strong) NSString *authorName;
@property (nonatomic, strong) NSString *authorAvatarURL;
@property (nonatomic, assign) NSInteger authorId;
@property (nonatomic, assign) BOOL authorIsGroup;
@end

@implementation PostDetailViewController

- (instancetype)initWithPost:(NSDictionary *)post {
    self = [super init];
    if (self) {
        _post = post;
        NSDictionary *likes = post[@"likes"];
        _postLikesCount = [likes[@"count"] integerValue];
        _postLiked = [post[@"user_likes"] boolValue];
        self.hidesBottomBarWhenPushed = YES; // <-- Убирает таббар
        _imageCache = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"Пост";
    
    [self loadAuthorInfo];
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    self.inputBar = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44)];
    self.inputBar.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1.0];
    self.inputBar.layer.borderWidth = 0.5;
    self.inputBar.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.inputBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [self.view addSubview:self.inputBar];
    
    self.commentField = [[UITextField alloc] initWithFrame:CGRectMake(8, 4, self.view.bounds.size.width - 70, 36)];
    self.commentField.borderStyle = UITextBorderStyleRoundedRect;
    self.commentField.placeholder = @"Написать комментарий...";
    self.commentField.delegate = self;
    self.commentField.returnKeyType = UIReturnKeySend;
    self.commentField.backgroundColor = [UIColor whiteColor];
    [self.inputBar addSubview:self.commentField];
    
    self.sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.sendButton.frame = CGRectMake(self.view.bounds.size.width - 60, 4, 50, 36);
    [self.sendButton setTitle:@"Отпр." forState:UIControlStateNormal];
    [self.sendButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.sendButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    self.sendButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0];
    self.sendButton.layer.cornerRadius = 5;
    [self.sendButton addTarget:self action:@selector(sendComment) forControlEvents:UIControlEventTouchUpInside];
    [self.inputBar addSubview:self.sendButton];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    [self loadComments];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)loadAuthorInfo {
    NSInteger sourceId = [self.post[@"source_id"] integerValue];
    self.authorId = sourceId;
    self.authorIsGroup = (sourceId < 0);
    
    if (self.authorIsGroup) {
        NSInteger groupId = -sourceId;
        NSString *urlString = [NSString stringWithFormat:@"%@groups.getById?group_id=%ld&fields=photo_50,name",
                               [[VKAPIClient sharedClient] baseURLString], (long)groupId];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSError *error = nil;
            NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
            if (!error && json[@"response"]) {
                NSArray *groups = json[@"response"];
                if (groups.count > 0) {
                    NSDictionary *group = groups[0];
                    self.authorName = group[@"name"];
                    self.authorAvatarURL = group[@"photo_50"];
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            });
        });
    } else {
        NSString *urlString = [NSString stringWithFormat:@"%@users.get?user_id=%ld&fields=photo_50",
                               [[VKAPIClient sharedClient] baseURLString], (long)sourceId];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSError *error = nil;
            NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
            if (!error && json[@"response"]) {
                NSArray *users = json[@"response"];
                if (users.count > 0) {
                    NSDictionary *user = users[0];
                    self.authorName = [NSString stringWithFormat:@"%@ %@", user[@"first_name"] ?: @"", user[@"last_name"] ?: @""];
                    self.authorAvatarURL = user[@"photo_50"];
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            });
        });
    }
}

- (void)loadComments {
    [self.spinner startAnimating];
    NSString *ownerId = [self.post[@"source_id"] stringValue] ?: @"";
    id postIdObj = self.post[@"post_id"] ?: self.post[@"id"];
    NSString *postId = [postIdObj stringValue] ?: @"";
    [[VKAPIClient sharedClient] getCommentsForPostWithOwnerId:ownerId postId:postId completion:^(NSArray *comments, NSError *error) {
        [self.spinner stopAnimating];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        self.comments = comments;
        [self.tableView reloadData];
    }];
}

- (void)sendComment {
    NSString *text = self.commentField.text;
    if (!text.length) return;
    self.commentField.text = @"";
    [self.commentField resignFirstResponder];
    
    NSString *ownerId = [self.post[@"source_id"] stringValue] ?: @"";
    id postIdObj = self.post[@"post_id"] ?: self.post[@"id"];
    NSString *postId = [postIdObj stringValue] ?: @"";
    
    if (!ownerId.length || !postId.length) {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Невозможно определить параметры поста." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        return;
    }
    
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] createComment:text forOwnerId:ownerId postId:postId completion:^(BOOL success, NSError *error) {
        [self.spinner stopAnimating];
        if (success) [self loadComments];
        else {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        }
    }];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self sendComment];
    return YES;
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 2; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) return 1;
    return self.comments.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 1 && self.comments.count > 0) return 30;
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 1 && self.comments.count > 0) {
        UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)];
        header.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 5, 200, 20)];
        label.text = @"Комментарии";
        label.font = [UIFont boldSystemFontOfSize:14];
        label.textColor = [UIColor darkGrayColor];
        label.backgroundColor = [UIColor clearColor];
        [header addSubview:label];
        return header;
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        static NSString *postCellID = @"PostDetailCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:postCellID];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:postCellID];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundColor = [UIColor whiteColor];
            cell.contentView.backgroundColor = [UIColor whiteColor];
            
            UIImageView *avatarView = [[UIImageView alloc] init]; avatarView.tag = 100; avatarView.frame = CGRectMake(10, 10, 40, 40); avatarView.layer.cornerRadius = 0; avatarView.clipsToBounds = YES; avatarView.userInteractionEnabled = YES; [cell.contentView addSubview:avatarView];
            UILabel *nameLabel = [[UILabel alloc] init]; nameLabel.tag = 101; nameLabel.font = [UIFont boldSystemFontOfSize:15]; nameLabel.textColor = [UIColor blackColor]; nameLabel.backgroundColor = [UIColor clearColor]; [cell.contentView addSubview:nameLabel];
            UILabel *postTextLabel = [[UILabel alloc] init]; postTextLabel.tag = 102; postTextLabel.numberOfLines = 0; postTextLabel.font = [UIFont systemFontOfSize:15]; postTextLabel.backgroundColor = [UIColor clearColor]; [cell.contentView addSubview:postTextLabel];
            UIImageView *postImageView = [[UIImageView alloc] init]; postImageView.tag = 103; postImageView.contentMode = UIViewContentModeScaleAspectFit; postImageView.clipsToBounds = YES; [cell.contentView addSubview:postImageView];
            UILabel *statsLabel = [[UILabel alloc] init]; statsLabel.tag = 104; statsLabel.font = [UIFont systemFontOfSize:13]; statsLabel.textColor = [UIColor darkGrayColor]; statsLabel.backgroundColor = [UIColor clearColor]; [cell.contentView addSubview:statsLabel];
            UIButton *likeBtn = [UIButton buttonWithType:UIButtonTypeCustom]; likeBtn.tag = 105; likeBtn.titleLabel.font = [UIFont systemFontOfSize:14]; [likeBtn setTitleColor:[UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0] forState:UIControlStateNormal]; [likeBtn addTarget:self action:@selector(likePost) forControlEvents:UIControlEventTouchUpInside]; [cell.contentView addSubview:likeBtn];
            UILabel *dateLabel = [[UILabel alloc] init]; dateLabel.tag = 106; dateLabel.font = [UIFont systemFontOfSize:11]; dateLabel.textColor = [UIColor grayColor]; dateLabel.backgroundColor = [UIColor clearColor]; [cell.contentView addSubview:dateLabel];
        }
        
        UIImageView *avatarView = (UIImageView *)[cell.contentView viewWithTag:100];
        UILabel *nameLabel = (UILabel *)[cell.contentView viewWithTag:101];
        UILabel *postTextLabel = (UILabel *)[cell.contentView viewWithTag:102];
        UIImageView *postImageView = (UIImageView *)[cell.contentView viewWithTag:103];
        UILabel *statsLabel = (UILabel *)[cell.contentView viewWithTag:104];
        UIButton *likeBtn = (UIButton *)[cell.contentView viewWithTag:105];
        UILabel *dateLabel = (UILabel *)[cell.contentView viewWithTag:106];
        
        nameLabel.text = self.authorName ?: (self.authorIsGroup ? @"Сообщество" : @"Пользователь");
        if (self.authorAvatarURL) {
            UIImage *cached = self.imageCache[self.authorAvatarURL];
            if (cached) avatarView.image = cached;
            else {
                [[VKAPIClient sharedClient] downloadImageWithURL:self.authorAvatarURL completion:^(UIImage *image) {
                    if (image) {
                        self.imageCache[self.authorAvatarURL] = image;
                        dispatch_async(dispatch_get_main_queue(), ^{ avatarView.image = image; });
                    }
                }];
            }
        } else avatarView.image = [UIImage imageNamed:@"default_avatar"];
        
        avatarView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openAuthorProfile)];
        [avatarView addGestureRecognizer:tap];
        
        postTextLabel.text = self.post[@"text"] ?: @"";
        postImageView.image = nil;
        postImageView.hidden = YES;
        NSArray *attachments = self.post[@"attachments"];
        if (attachments.count > 0) {
            NSDictionary *first = attachments[0];
            if ([first[@"type"] isEqualToString:@"photo"]) {
                NSString *photoURL = [self bestImageURLFromPhoto:first[@"photo"]];
                if (photoURL) {
                    postImageView.hidden = NO;
                    UIImage *cached = self.imageCache[photoURL];
                    if (cached) postImageView.image = cached;
                    else {
                        [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                            if (image) {
                                self.imageCache[photoURL] = image;
                                dispatch_async(dispatch_get_main_queue(), ^{ postImageView.image = image; });
                            }
                        }];
                    }
                }
            }
        }
        
        statsLabel.text = [NSString stringWithFormat:@"❤️ %ld", (long)self.postLikesCount];
        [likeBtn setTitle:self.postLiked ? @"❤️ Убрать лайк" : @"❤️ Мне нравится" forState:UIControlStateNormal];
        
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:[self.post[@"date"] doubleValue]];
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateFormat = @"dd MMMM yyyy, HH:mm";
        dateLabel.text = [df stringFromDate:date];
        
        // Верстка
        CGFloat width = tableView.bounds.size.width;
        CGFloat y = 10;
        avatarView.frame = CGRectMake(10, y, 40, 40);
        nameLabel.frame = CGRectMake(60, y, width - 70, 22);
        y += 45;
        CGSize textSize = [postTextLabel.text sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(width - 20, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
        postTextLabel.frame = CGRectMake(10, y, width - 20, textSize.height);
        y += textSize.height + 10;
        if (!postImageView.hidden) {
            CGFloat imgHeight = 200;
            postImageView.frame = CGRectMake(10, y, width - 20, imgHeight);
            y += imgHeight + 10;
        }
        statsLabel.frame = CGRectMake(10, y, 150, 25);
        likeBtn.frame = CGRectMake(width - 130, y, 120, 25);
        y += 30;
        dateLabel.frame = CGRectMake(10, y, width - 20, 16);
        y += 20;
        
        UIView *separator = [[UIView alloc] initWithFrame:CGRectMake(10, y, width - 20, 1)];
        separator.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:separator];
        
        return cell;
    } else {
        static NSString *commentCellID = @"CommentCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:commentCellID];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:commentCellID];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.textLabel.font = [UIFont systemFontOfSize:14];
            cell.textLabel.numberOfLines = 0;
            cell.textLabel.backgroundColor = [UIColor clearColor];
            cell.detailTextLabel.font = [UIFont systemFontOfSize:11];
            cell.detailTextLabel.textColor = [UIColor grayColor];
            cell.detailTextLabel.backgroundColor = [UIColor clearColor];
            
            UIImageView *avatar = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 30, 30)];
            avatar.tag = 200;
            avatar.layer.cornerRadius = 0;
            avatar.clipsToBounds = YES;
            [cell.contentView addSubview:avatar];
        }
        NSDictionary *comment = self.comments[indexPath.row];
        UIImageView *avatar = (UIImageView *)[cell.contentView viewWithTag:200];
        avatar.image = [UIImage imageNamed:@"default_avatar"];
        
        cell.textLabel.text = comment[@"text"];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"❤️ %@", comment[@"likes"][@"count"] ?: @"0"];
        CGSize textSize = [comment[@"text"] sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(tableView.bounds.size.width - 80, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
        cell.textLabel.frame = CGRectMake(50, 8, tableView.bounds.size.width - 80, textSize.height);
        cell.detailTextLabel.frame = CGRectMake(50, cell.textLabel.frame.origin.y + cell.textLabel.frame.size.height + 2, 100, 14);
        
        UIButton *likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        likeBtn.frame = CGRectMake(tableView.bounds.size.width - 70, 8, 60, 25);
        [likeBtn setTitle:@"❤️" forState:UIControlStateNormal];
        [likeBtn setTitleColor:[UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0] forState:UIControlStateNormal];
        likeBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        likeBtn.tag = indexPath.row;
        [likeBtn addTarget:self action:@selector(likeComment:) forControlEvents:UIControlEventTouchUpInside];
        cell.accessoryView = likeBtn;
        
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        NSString *text = self.post[@"text"] ?: @"";
        CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(tableView.bounds.size.width - 20, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
        CGFloat height = 55 + textSize.height + 10;
        NSArray *attachments = self.post[@"attachments"];
        if (attachments.count > 0 && [attachments[0][@"type"] isEqualToString:@"photo"]) height += 210;
        height += 50;
        height += 10;
        return height;
    } else {
        NSString *text = self.comments[indexPath.row][@"text"] ?: @"";
        CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(tableView.bounds.size.width - 80, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
        return textSize.height + 35;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        NSArray *attachments = self.post[@"attachments"];
        if (attachments.count > 0 && [attachments[0][@"type"] isEqualToString:@"video"]) {
            NSDictionary *video = attachments[0][@"video"];
            [self playVideoWithOwnerId:[video[@"owner_id"] stringValue] videoId:[video[@"id"] stringValue]];
        }
    }
}

- (void)likePost {
    if (self.postLiked) return;
    NSString *ownerId = [self.post[@"source_id"] stringValue] ?: @"";
    id postIdObj = self.post[@"post_id"] ?: self.post[@"id"];
    NSString *postId = [postIdObj stringValue] ?: @"";
    [[VKAPIClient sharedClient] addLikeForOwnerId:ownerId itemId:postId type:@"post" completion:^(BOOL success, NSError *error) {
        if (success) {
            self.postLiked = YES;
            self.postLikesCount++;
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            });
        } else {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        }
    }];
}

- (void)likeComment:(UIButton *)sender {
    NSInteger index = sender.tag;
    if (index < 0 || index >= self.comments.count) return;
    NSDictionary *comment = self.comments[index];
    NSString *ownerId = [self.post[@"source_id"] stringValue] ?: @"";
    NSString *commentId = [comment[@"id"] stringValue];
    [[VKAPIClient sharedClient] addLikeForOwnerId:ownerId itemId:commentId type:@"comment" completion:^(BOOL success, NSError *error) {
        if (success) [self loadComments];
        else {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        }
    }];
}

- (void)openAuthorProfile {
    if (self.authorIsGroup) {
        GroupWallViewController *groupVC = [[GroupWallViewController alloc] initWithGroupId:[NSString stringWithFormat:@"-%ld", (long)self.authorId] name:self.authorName avatarURL:self.authorAvatarURL];
        groupVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:groupVC animated:YES];
    } else {
        ProfileViewController *profileVC = [[ProfileViewController alloc] initWithUserId:[NSString stringWithFormat:@"%ld", (long)self.authorId]];
        profileVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:profileVC animated:YES];
    }
}

- (void)playVideoWithOwnerId:(NSString *)ownerId videoId:(NSString *)videoId {
    VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
    [self.navigationController pushViewController:playerVC animated:YES];
}

- (void)keyboardWillShow:(NSNotification *)notification {
    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat height = keyboardFrame.size.height;
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        self.inputBar.frame = CGRectMake(0, self.view.bounds.size.height - height - 44, self.view.bounds.size.width, 44);
        self.tableView.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - height - 44);
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        self.inputBar.frame = CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44);
        self.tableView.frame = self.view.bounds;
    }];
}

- (NSString *)bestImageURLFromPhoto:(NSDictionary *)photo {
    if (![photo isKindOfClass:[NSDictionary class]]) return nil;
    NSArray *keys = @[@"photo_1280", @"photo_807", @"photo_604", @"photo_130", @"photo_75"];
    for (NSString *key in keys) {
        NSString *url = photo[key];
        if (url && [url isKindOfClass:[NSString class]] && url.length > 0) return url;
    }
    NSArray *sizes = photo[@"sizes"];
    if ([sizes isKindOfClass:[NSArray class]]) {
        for (NSDictionary *size in sizes) {
            if ([size[@"type"] isEqualToString:@"x"] || [size[@"type"] isEqualToString:@"z"] || [size[@"type"] isEqualToString:@"m"]) {
                return size[@"url"];
            }
        }
        return [(NSDictionary *)[sizes lastObject] objectForKey:@"url"];
    }
    return nil;
}

@end