// PhotosViewController.m
#import "PhotosViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"

@interface PhotosViewController () <UICollectionViewDataSource, UICollectionViewDelegate>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSArray *albums;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSMutableDictionary *imageCache;
@end

@implementation PhotosViewController

- (void)loadView {
    [super loadView];
    self.title = @"Фотографии";
    self.view.backgroundColor = [UIColor whiteColor];
    self.imageCache = [NSMutableDictionary dictionary];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(80, 80);
    layout.minimumInteritemSpacing = 4;
    layout.minimumLineSpacing = 4;
    layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    
    self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    self.collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"AlbumCell"];
    [self.view addSubview:self.collectionView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [self loadAlbums];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadAlbums {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] getPhotoAlbumsWithCompletion:^(NSArray *albums, NSError *error) {
        [self.spinner stopAnimating];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        self.albums = albums ?: @[];
        [self.collectionView reloadData];
        if (self.albums.count == 0) {
            [[[UIAlertView alloc] initWithTitle:@"Инфо" message:@"Нет альбомов" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        }
    }];
}

#pragma mark - UICollectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.albums.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"AlbumCell" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor lightGrayColor];
    
    UIImageView *imageView = (UIImageView *)[cell.contentView viewWithTag:200];
    if (!imageView) {
        imageView = [[UIImageView alloc] initWithFrame:cell.contentView.bounds];
        imageView.tag = 200;
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = YES;
        [cell.contentView addSubview:imageView];
    }
    
    NSDictionary *album = self.albums[indexPath.row];
    NSString *coverURL = album[@"thumb_src"] ?: album[@"photo_130"];
    if (coverURL) {
        UIImage *cached = self.imageCache[coverURL];
        if (cached) {
            imageView.image = cached;
        } else {
            imageView.image = nil;
            [[VKAPIClient sharedClient] downloadImageWithURL:coverURL completion:^(UIImage *image) {
                if (image) {
                    self.imageCache[coverURL] = image;
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UICollectionViewCell *updateCell = [collectionView cellForItemAtIndexPath:indexPath];
                        if (updateCell) {
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:200];
                            iv.image = image;
                        }
                    });
                }
            }];
        }
    }
    return cell;
}

@end