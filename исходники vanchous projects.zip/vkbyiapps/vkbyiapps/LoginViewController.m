// LoginViewController.m
#import "LoginViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "UIButton+Glossy.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@interface LoginViewController () <UIWebViewDelegate> {
    UITextField *tokenField;
    UIButton *loginButton;
    UIButton *oauthButton;
    UIActivityIndicatorView *spinner;
    UILabel *statusLabel;
    UIWebView *webView;
    UINavigationBar *webNavBar;
    UIImageView *logoImageView;
}
@end

@implementation LoginViewController

- (void)loadView {
    [super loadView];
    
    // ===== СИНИЙ ГРАДИЕНТНЫЙ ФОН =====
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = self.view.bounds;
    gradient.colors = @[
                        (id)[UIColor colorWithRed:0.22 green:0.40 blue:0.65 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.12 green:0.25 blue:0.45 alpha:1.0].CGColor
                        ];
    gradient.locations = @[@0.0, @1.0];
    [self.view.layer insertSublayer:gradient atIndex:0];
    
    // Текстура поверх
    UIImage *texture = [UIImage imageNamed:@"linen_soft.png"];
    if (texture) {
        UIImageView *textureView = [[UIImageView alloc] initWithImage:texture];
        textureView.frame = self.view.bounds;
        textureView.alpha = 0.1;
        textureView.contentMode = UIViewContentModeScaleAspectFill;
        [self.view addSubview:textureView];
    }
    
    // ===== ЛОГОТИП VK =====
    logoImageView = [[UIImageView alloc] init];
    UIImage *logo = [UIImage imageNamed:@"Login_Logo.png"];
    if (logo) {
        logoImageView.image = logo;
        logoImageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.view addSubview:logoImageView];
    } else {
        // fallback
        UILabel *fallbackLogo = [[UILabel alloc] init];
        fallbackLogo.text = @"VK";
        fallbackLogo.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:60];
        fallbackLogo.textColor = [UIColor whiteColor];
        fallbackLogo.textAlignment = NSTextAlignmentCenter;
        fallbackLogo.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.4];
        fallbackLogo.shadowOffset = CGSizeMake(0, -2);
        fallbackLogo.backgroundColor = [UIColor clearColor];
        [self.view addSubview:fallbackLogo];
        logoImageView.image = nil;
    }
    
    // ===== ПОЛЕ ТОКЕНА =====
    tokenField = [[UITextField alloc] init];
    tokenField.placeholder = @"Access Token";
    tokenField.borderStyle = UITextBorderStyleRoundedRect;
    tokenField.font = [UIFont systemFontOfSize:16];
    tokenField.backgroundColor = [UIColor whiteColor];
    tokenField.textColor = [UIColor darkTextColor];
    tokenField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    tokenField.layer.cornerRadius = 10.0;
    tokenField.layer.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.3].CGColor;
    tokenField.layer.shadowOffset = CGSizeMake(0, 2);
    tokenField.layer.shadowOpacity = 1.0;
    tokenField.layer.shadowRadius = 4.0;
    tokenField.layer.borderWidth = 0.5;
    tokenField.layer.borderColor = [UIColor colorWithWhite:0.7 alpha:1.0].CGColor;
    [self.view addSubview:tokenField];
    
    // ===== КНОПКИ =====
    loginButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [loginButton setTitle:@"Войти по токену" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = [UIFont boldSystemFontOfSize:17];
    [loginButton makeGlossy];
    [loginButton addTarget:self action:@selector(loginTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
    oauthButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [oauthButton setTitle:@"Войти через VK" forState:UIControlStateNormal];
    [oauthButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    oauthButton.titleLabel.font = [UIFont boldSystemFontOfSize:17];
    // Зелёный градиент для OAuth
    CAGradientLayer *greenGrad = [CAGradientLayer layer];
    greenGrad.frame = oauthButton.bounds;
    greenGrad.colors = @[(id)[UIColor colorWithRed:0.28 green:0.72 blue:0.28 alpha:1.0].CGColor,
                         (id)[UIColor colorWithRed:0.16 green:0.56 blue:0.16 alpha:1.0].CGColor];
    greenGrad.cornerRadius = 10.0;
    [oauthButton.layer insertSublayer:greenGrad atIndex:0];
    CAGradientLayer *gloss = [CAGradientLayer layer];
    gloss.frame = oauthButton.bounds;
    gloss.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:0.4].CGColor,
                     (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor];
    gloss.locations = @[@0.0, @0.5];
    gloss.cornerRadius = 10.0;
    [oauthButton.layer insertSublayer:gloss atIndex:1];
    oauthButton.layer.cornerRadius = 10.0;
    oauthButton.layer.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.3].CGColor;
    oauthButton.layer.shadowOffset = CGSizeMake(0, 2);
    oauthButton.layer.shadowOpacity = 1.0;
    oauthButton.layer.shadowRadius = 3.0;
    oauthButton.clipsToBounds = YES;
    [oauthButton addTarget:self action:@selector(oauthTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:oauthButton];
    
    // ===== СТАТУС =====
    statusLabel = [[UILabel alloc] init];
    statusLabel.textAlignment = NSTextAlignmentCenter;
    statusLabel.font = [UIFont systemFontOfSize:14];
    statusLabel.textColor = [UIColor whiteColor];
    statusLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    statusLabel.shadowOffset = CGSizeMake(0, -1);
    statusLabel.backgroundColor = [UIColor clearColor];
    statusLabel.numberOfLines = 0;
    statusLabel.text = @"Введите токен или войдите через VK";
    [self.view addSubview:statusLabel];
    
    // ===== ИНДИКАТОР =====
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [self.view addSubview:spinner];
    
    // ===== WEBVIEW =====
    webView = [[UIWebView alloc] init];
    webView.delegate = self;
    webView.hidden = YES;
    webView.scalesPageToFit = YES;
    webView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:webView];
    
    webNavBar = [[UINavigationBar alloc] init];
    webNavBar.hidden = YES;
    [webNavBar setBackgroundImage:[self navigationBarBackgroundImage] forBarMetrics:UIBarMetricsDefault];
    webNavBar.tintColor = [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
    UINavigationItem *navItem = [[UINavigationItem alloc] initWithTitle:@"Авторизация"];
    UIBarButtonItem *cancelBtn = [[UIBarButtonItem alloc] initWithTitle:@"Отмена" style:UIBarButtonItemStylePlain target:self action:@selector(cancelOAuth)];
    navItem.leftBarButtonItem = cancelBtn;
    webNavBar.items = @[navItem];
    [self.view addSubview:webNavBar];
    
    // ===== РАЗМЕЩЕНИЕ =====
    CGFloat w = self.view.bounds.size.width;
    CGFloat centerX = w / 2;
    CGFloat y = 60;
    
    if (logoImageView.image) {
        CGFloat logoWidth = 200;
        CGFloat logoHeight = 100;
        logoImageView.frame = CGRectMake(centerX - logoWidth/2, y, logoWidth, logoHeight);
        y += logoHeight + 30;
    } else {
        UILabel *fl = (UILabel *)[self.view.subviews lastObject];
        fl.frame = CGRectMake(0, y, w, 80);
        y += 100;
    }
    
    tokenField.frame = CGRectMake(30, y, w - 60, 44);
    y += 60;
    loginButton.frame = CGRectMake(30, y, w - 60, 44);
    y += 56;
    oauthButton.frame = CGRectMake(30, y, w - 60, 44);
    y += 56;
    statusLabel.frame = CGRectMake(20, y, w - 40, 40);
    y += 50;
    spinner.center = CGPointMake(centerX, y);
    
    webView.frame = CGRectMake(0, 44, w, self.view.bounds.size.height - 44);
    webNavBar.frame = CGRectMake(0, 0, w, 44);
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (UIImage *)navigationBarBackgroundImage {
    CGRect rect = CGRectMake(0, 0, 1, 44);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGFloat locations[] = {0.0, 1.0};
    NSArray *colors = @[(id)[UIColor colorWithRed:0.22 green:0.40 blue:0.65 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.12 green:0.25 blue:0.45 alpha:1.0].CGColor];
    CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)colors, locations);
    CGContextDrawLinearGradient(context, gradient, CGPointMake(0, 0), CGPointMake(0, rect.size.height), 0);
    CGGradientRelease(gradient);
    CGColorSpaceRelease(colorSpace);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)dismissKeyboard {
    [tokenField resignFirstResponder];
}

- (void)loginTapped {
    [self dismissKeyboard];
    NSString *token = tokenField.text;
    if (!token.length) {
        statusLabel.text = @"Введите токен!";
        statusLabel.textColor = [UIColor redColor];
        return;
    }
    [spinner startAnimating];
    loginButton.enabled = NO;
    statusLabel.text = @"Проверка...";
    statusLabel.textColor = [UIColor yellowColor];
    
    [[VKAPIClient sharedClient] validateToken:token completion:^(BOOL valid, NSString *userId, NSString *errorMessage) {
        [spinner stopAnimating];
        loginButton.enabled = YES;
        if (valid) {
            [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"VKAccessToken"];
            [[NSUserDefaults standardUserDefaults] setObject:userId forKey:@"VKUserId"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            SideMenuViewController *sideMenu = [[SideMenuViewController alloc] init];
            self.view.window.rootViewController = sideMenu;
            [UIView transitionWithView:self.view.window duration:0.4 options:UIViewAnimationOptionTransitionFlipFromRight animations:nil completion:nil];
        } else {
            statusLabel.text = errorMessage ?: @"Неверный токен";
            statusLabel.textColor = [UIColor redColor];
        }
    }];
}

- (void)oauthTapped {
    webView.hidden = NO;
    webNavBar.hidden = NO;
    NSString *appID = @"YOUR_APP_ID"; // замени на свой
    NSString *redirectURI = @"https://oauth.vk.com/blank.html";
    NSString *scope = @"friends,photos,audio,video,messages,wall,groups,offline";
    NSString *urlString = [NSString stringWithFormat:@"https://oauth.vk.com/authorize?client_id=%@&display=mobile&redirect_uri=%@&scope=%@&response_type=token&v=5.131", appID, redirectURI, scope];
    NSURL *url = [NSURL URLWithString:urlString];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
}

- (void)cancelOAuth {
    webView.hidden = YES;
    webNavBar.hidden = YES;
    [webView loadHTMLString:@"" baseURL:nil];
    statusLabel.text = @"Авторизация отменена";
    statusLabel.textColor = [UIColor whiteColor];
}

#pragma mark - UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSString *urlString = request.URL.absoluteString;
    if ([urlString hasPrefix:@"https://oauth.vk.com/blank.html#access_token="]) {
        NSArray *components = [urlString componentsSeparatedByString:@"#"];
        if (components.count > 1) {
            NSString *fragment = components[1];
            NSArray *params = [fragment componentsSeparatedByString:@"&"];
            for (NSString *param in params) {
                if ([param hasPrefix:@"access_token="]) {
                    NSString *token = [param stringByReplacingOccurrencesOfString:@"access_token=" withString:@""];
                    [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"VKAccessToken"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    webView.hidden = YES;
                    webNavBar.hidden = YES;
                    [webView loadHTMLString:@"" baseURL:nil];
                    SideMenuViewController *sideMenu = [[SideMenuViewController alloc] init];
                    self.view.window.rootViewController = sideMenu;
                    [UIView transitionWithView:self.view.window duration:0.4 options:UIViewAnimationOptionTransitionFlipFromRight animations:nil completion:nil];
                    return NO;
                }
            }
        }
    }
    return YES;
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    statusLabel.text = @"Ошибка загрузки страницы";
    statusLabel.textColor = [UIColor redColor];
}

- (void)dealloc {
    // ARC, ничего не делаем
}

@end