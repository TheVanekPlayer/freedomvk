// VideoPlayerViewController.m
#import "VideoPlayerViewController.h"
#import "VKAPIClient.h"
#import <MediaPlayer/MediaPlayer.h>

@interface VideoPlayerViewController ()
@property (nonatomic, strong) NSString *ownerId;
@property (nonatomic, strong) NSString *videoId;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@end

@implementation VideoPlayerViewController

- (instancetype)initWithVideoOwnerId:(NSString *)ownerId videoId:(NSString *)videoId {
    self = [super init];
    if (self) {
        _ownerId = ownerId;
        _videoId = videoId;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    self.title = @"Видео";
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    [self.spinner startAnimating];
    
    [self loadVideo];
}

- (void)loadVideo {
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    NSString *urlString = [NSString stringWithFormat:@"%@video.get?videos=%@_%@&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], self.ownerId, self.videoId, token];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || ![json[@"response"][@"items"] count]) {
                [self.spinner stopAnimating];
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не удалось получить видео" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                [self.navigationController popViewControllerAnimated:YES];
                return;
            }
            NSDictionary *video = json[@"response"][@"items"][0];
            NSDictionary *files = video[@"files"];
            NSString *videoURL = files[@"mp4_720"] ?: files[@"mp4_480"] ?: files[@"mp4_360"] ?: files[@"mp4_240"];
            if (!videoURL) {
                [self.spinner stopAnimating];
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Ссылка на видео не найдена" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                [self.navigationController popViewControllerAnimated:YES];
                return;
            }
            // Скачиваем через публичный метод performAsyncGET
            [[VKAPIClient sharedClient] performAsyncGET:videoURL completion:^(NSData *data, NSError *error) {
                [self.spinner stopAnimating];
                if (error || !data) {
                    [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не удалось загрузить видео" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                    [self.navigationController popViewControllerAnimated:YES];
                    return;
                }
                // Сохраняем во временный файл
                NSString *tempPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"video.mp4"];
                [data writeToFile:tempPath atomically:YES];
                NSURL *localURL = [NSURL fileURLWithPath:tempPath];
                // Воспроизводим локально
                MPMoviePlayerViewController *playerVC = [[MPMoviePlayerViewController alloc] initWithContentURL:localURL];
                playerVC.moviePlayer.controlStyle = MPMovieControlStyleFullscreen;
                playerVC.moviePlayer.shouldAutoplay = YES;
                [self presentMoviePlayerViewControllerAnimated:playerVC];
                
                // По окончании закрываем
                [[NSNotificationCenter defaultCenter] addObserver:self
                                                         selector:@selector(movieFinished:)
                                                             name:MPMoviePlayerPlaybackDidFinishNotification
                                                           object:playerVC.moviePlayer];
            }];
        });
    });
}

- (void)movieFinished:(NSNotification *)notification {
    [self dismissMoviePlayerViewControllerAnimated];
    [self.navigationController popViewControllerAnimated:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end