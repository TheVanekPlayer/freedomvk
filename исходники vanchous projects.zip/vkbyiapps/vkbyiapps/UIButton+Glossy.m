// UIButton+Glossy.m
#import "UIButton+Glossy.h"
#import <QuartzCore/QuartzCore.h>

@implementation UIButton (Glossy)

- (void)makeGlossy {
    for (CALayer *layer in self.layer.sublayers) {
        if ([layer isKindOfClass:[CAGradientLayer class]]) {
            [layer removeFromSuperlayer];
        }
    }
    
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = self.bounds;
    gradient.colors = @[(id)[UIColor colorWithRed:0.42 green:0.58 blue:0.82 alpha:1.0].CGColor,
                        (id)[UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0].CGColor];
    gradient.cornerRadius = 10.0;
    gradient.borderWidth = 0.5;
    gradient.borderColor = [UIColor colorWithRed:0.12 green:0.24 blue:0.44 alpha:1.0].CGColor;
    [self.layer insertSublayer:gradient atIndex:0];
    
    CAGradientLayer *gloss = [CAGradientLayer layer];
    gloss.frame = self.bounds;
    gloss.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:0.6].CGColor,
                     (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor];
    gloss.locations = @[@0.0, @0.4];
    gloss.cornerRadius = 10.0;
    [self.layer insertSublayer:gloss atIndex:1];
    
    self.layer.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.3].CGColor;
    self.layer.shadowOpacity = 1.0;
    self.layer.shadowRadius = 3.0;
    self.layer.shadowOffset = CGSizeMake(0, 2);
    self.layer.cornerRadius = 10.0;
    self.clipsToBounds = NO;
    
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.titleLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.4];
    self.titleLabel.shadowOffset = CGSizeMake(0, -1);
}

@end