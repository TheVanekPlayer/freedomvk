// ChatViewController.m
#import "ChatViewController.h"
#import "VKAPIClient.h"
#import "AppDelegate.h"
#import "VideoPlayerViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

@interface ChatViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate, UIAlertViewDelegate>
@property (nonatomic, copy) NSString *peerId;
@property (nonatomic, strong) NSMutableArray *messages;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UITextField *inputField;
@property (nonatomic, strong) UIButton *sendButton;
@property (nonatomic, strong) UIButton *photoButton;
@property (nonatomic, strong) UIButton *videoButton;
@property (nonatomic, strong) UIButton *stickerButton;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSCache *imageCache;
@property (nonatomic, strong) NSDictionary *userInfo;
@property (nonatomic, strong) NSMutableDictionary *attachmentCache;
@property (nonatomic, assign) NSInteger currentOffset;
@property (nonatomic, assign) NSInteger totalCount;
@property (nonatomic, assign) BOOL isLoadingMore;
@property (nonatomic, assign) BOOL noMoreMessages;
@property (nonatomic, strong) UIActivityIndicatorView *loadingMoreSpinner;
@property (nonatomic, strong) NSNumber *editingMessageId;
@property (nonatomic, strong) NSNumber *replyingToMessageId;
@end

@implementation ChatViewController

- (instancetype)initWithPeerId:(NSString *)peerId title:(NSString *)title {
    self = [super init];
    if (self) {
        _peerId = peerId;
        self.title = title ?: @"Диалог";
        self.hidesBottomBarWhenPushed = YES;
        _imageCache = [[NSCache alloc] init];
        [_imageCache setCountLimit:50];
        _attachmentCache = [NSMutableDictionary dictionary];
        _currentOffset = 0;
        _totalCount = 0;
        _isLoadingMore = NO;
        _noMoreMessages = NO;
    }
    return self;
}

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor colorWithWhite:0.88 alpha:1.0];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 44)
                                                  style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.tableView];
    
    self.loadingMoreSpinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.loadingMoreSpinner.frame = CGRectMake(0, 0, self.view.bounds.size.width, 44);
    self.loadingMoreSpinner.hidesWhenStopped = YES;
    self.tableView.tableHeaderView = self.loadingMoreSpinner;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [self.tableView addGestureRecognizer:tap];
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    [self.tableView addGestureRecognizer:longPress];
    
    UIView *inputBar = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44)];
    inputBar.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1.0];
    inputBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    inputBar.layer.shadowColor = [UIColor blackColor].CGColor;
    inputBar.layer.shadowOffset = CGSizeMake(0, -1);
    inputBar.layer.shadowOpacity = 0.1;
    inputBar.layer.shadowRadius = 2;
    [self.view addSubview:inputBar];
    
    self.photoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.photoButton.frame = CGRectMake(4, 4, 30, 36);
    [self.photoButton setTitle:@"📷" forState:UIControlStateNormal];
    self.photoButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [self.photoButton addTarget:self action:@selector(photoButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [inputBar addSubview:self.photoButton];
    
    self.videoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.videoButton.frame = CGRectMake(38, 4, 30, 36);
    [self.videoButton setTitle:@"🎬" forState:UIControlStateNormal];
    self.videoButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [self.videoButton addTarget:self action:@selector(videoButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [inputBar addSubview:self.videoButton];
    
    self.stickerButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.stickerButton.frame = CGRectMake(72, 4, 30, 36);
    [self.stickerButton setTitle:@"😊" forState:UIControlStateNormal];
    self.stickerButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [self.stickerButton addTarget:self action:@selector(stickerButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [inputBar addSubview:self.stickerButton];
    
    self.inputField = [[UITextField alloc] initWithFrame:CGRectMake(106, 4, self.view.bounds.size.width - 106 - 50, 36)];
    self.inputField.borderStyle = UITextBorderStyleRoundedRect;
    self.inputField.placeholder = @"Сообщение...";
    self.inputField.delegate = self;
    self.inputField.returnKeyType = UIReturnKeySend;
    self.inputField.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    self.inputField.backgroundColor = [UIColor whiteColor];
    self.inputField.font = [UIFont fontWithName:@"HelveticaNeue" size:15];
    [inputBar addSubview:self.inputField];
    
    self.sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.sendButton.frame = CGRectMake(self.view.bounds.size.width - 46, 4, 36, 36);
    [self.sendButton setTitle:@"▶️" forState:UIControlStateNormal];
    self.sendButton.titleLabel.font = [UIFont systemFontOfSize:20];
    [self.sendButton addTarget:self action:@selector(sendMessage) forControlEvents:UIControlEventTouchUpInside];
    self.sendButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [inputBar addSubview:self.sendButton];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    [self loadUserInfo];
    [self loadHistory];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)dismissKeyboard {
    [self.inputField resignFirstResponder];
}

#pragma mark - Долгий тап (копирование, редактирование, ответ)
- (void)handleLongPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateBegan) {
        CGPoint point = [gesture locationInView:self.tableView];
        NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:point];
        if (indexPath) {
            NSDictionary *msg = self.messages[indexPath.row];
            NSString *text = msg[@"text"];
            NSNumber *messageId = msg[@"id"];
            BOOL isOut = [msg[@"out"] boolValue];
            
            UIMenuController *menuController = [UIMenuController sharedMenuController];
            NSMutableArray *menuItems = [NSMutableArray array];
            
            if (text.length > 0 && ![text isEqualToString:@"[Стикер]"] && ![text isEqualToString:@"[Фото]"] && ![text isEqualToString:@"[Видео]"]) {
                UIMenuItem *copyItem = [[UIMenuItem alloc] initWithTitle:@"Копировать" action:@selector(copyMessage:)];
                [menuItems addObject:copyItem];
            }
            if (isOut && text.length > 0 && ![text isEqualToString:@"[Стикер]"] && ![text isEqualToString:@"[Фото]"] && ![text isEqualToString:@"[Видео]"]) {
                UIMenuItem *editItem = [[UIMenuItem alloc] initWithTitle:@"Редактировать" action:@selector(editMessage:)];
                [menuItems addObject:editItem];
            }
            if (text.length > 0 && ![text isEqualToString:@"[Стикер]"] && ![text isEqualToString:@"[Фото]"] && ![text isEqualToString:@"[Видео]"]) {
                UIMenuItem *replyItem = [[UIMenuItem alloc] initWithTitle:@"Ответить" action:@selector(replyToMessage:)];
                [menuItems addObject:replyItem];
            }
            
            if (menuItems.count > 0) {
                [menuController setMenuItems:menuItems];
                [menuController setTargetRect:CGRectMake(point.x, point.y, 1, 1) inView:self.tableView];
                [menuController setMenuVisible:YES animated:YES];
                objc_setAssociatedObject(self, "longPressText", text, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                objc_setAssociatedObject(self, "longPressMessageId", messageId, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                objc_setAssociatedObject(self, "longPressIndexPath", indexPath, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                objc_setAssociatedObject(self, "longPressIsOut", @(isOut), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            }
        }
    }
}

- (void)copyMessage:(id)sender {
    NSString *text = objc_getAssociatedObject(self, "longPressText");
    if (text) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = text;
    }
}

- (void)editMessage:(id)sender {
    NSNumber *messageId = objc_getAssociatedObject(self, "longPressMessageId");
    NSString *text = objc_getAssociatedObject(self, "longPressText");
    NSIndexPath *indexPath = objc_getAssociatedObject(self, "longPressIndexPath");
    if (!messageId || !text || !indexPath) return;
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Редактировать"
                                                    message:@"Введите новый текст"
                                                   delegate:self
                                          cancelButtonTitle:@"Отмена"
                                          otherButtonTitles:@"Сохранить", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *tf = [alert textFieldAtIndex:0];
    tf.text = text;
    alert.tag = 200;
    objc_setAssociatedObject(alert, "editMessageId", messageId, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(alert, "editIndexPath", indexPath, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [alert show];
}

- (void)replyToMessage:(id)sender {
    NSNumber *messageId = objc_getAssociatedObject(self, "longPressMessageId");
    NSString *text = objc_getAssociatedObject(self, "longPressText");
    NSIndexPath *indexPath = objc_getAssociatedObject(self, "longPressIndexPath");
    if (!messageId || !text || !indexPath) return;
    
    NSDictionary *msg = self.messages[indexPath.row];
    NSString *senderName = @"Пользователь";
    if ([msg[@"out"] boolValue]) {
        senderName = @"Я";
    } else {
        NSNumber *fromId = msg[@"from_id"];
        if (fromId && [fromId integerValue] == [self.peerId integerValue] && self.userInfo) {
            senderName = [NSString stringWithFormat:@"%@ %@", self.userInfo[@"first_name"] ?: @"", self.userInfo[@"last_name"] ?: @""];
        }
    }
    
    NSString *quote = [NSString stringWithFormat:@"%@: %@", senderName, text];
    self.inputField.text = [NSString stringWithFormat:@"[%@]\n", quote];
    self.replyingToMessageId = messageId;
    [self.inputField becomeFirstResponder];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 200 && buttonIndex == 1) {
        NSNumber *messageId = objc_getAssociatedObject(alertView, "editMessageId");
        NSIndexPath *indexPath = objc_getAssociatedObject(alertView, "editIndexPath");
        UITextField *tf = [alertView textFieldAtIndex:0];
        NSString *newText = tf.text;
        if (!messageId || !newText.length) return;
        
        [self.spinner startAnimating];
        [[VKAPIClient sharedClient] editMessage:newText forMessageId:messageId peerId:self.peerId completion:^(BOOL success, NSError *error) {
            [self.spinner stopAnimating];
            if (success) {
                NSMutableDictionary *updatedMsg = [self.messages[indexPath.row] mutableCopy];
                updatedMsg[@"text"] = newText;
                self.messages[indexPath.row] = updatedMsg;
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            } else {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    }
}

#pragma mark - Стикеры (UIActionSheet)
- (void)stickerButtonTapped {
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"Выберите стикер"
                                                       delegate:self
                                              cancelButtonTitle:@"Отмена"
                                         destructiveButtonTitle:nil
                                              otherButtonTitles:
                            @"Привет! (1)", @"Грустно (2)", @"Так держать! (3)", @"Успел (4)", @"Рисую (5)",
                            @"Крутой (6)", @"Уже еду! (7)", @"Занят (8)", @"Дождь (9)", @"Злой (10)",
                            nil];
    sheet.tag = 100;
    [sheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (actionSheet.tag == 100 && buttonIndex != actionSheet.cancelButtonIndex) {
        NSInteger stickerId = buttonIndex + 1;
        NSString *stickerIdStr = [NSString stringWithFormat:@"%ld", (long)stickerId];
        [[VKAPIClient sharedClient] sendSticker:stickerIdStr toPeerId:self.peerId completion:^(BOOL success, NSError *error) {
            if (success) {
                // Локальное сообщение только со стикером, без других вложений
                NSDictionary *localMsg = @{@"text": @"[Стикер]", @"out": @1, @"sticker_id": stickerIdStr};
                [self.messages addObject:localMsg];
                [self.tableView reloadData];
                [self scrollToBottom];
            } else {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    }
}

#pragma mark - Отправка сообщений
- (void)sendMessage {
    NSString *text = self.inputField.text;
    if (text.length == 0) return;
    self.inputField.text = @"";
    NSNumber *replyTo = self.replyingToMessageId;
    self.replyingToMessageId = nil;
    
    NSDictionary *localMsg = @{@"text": text, @"out": @1};
    if (replyTo) {
        localMsg = @{@"text": text, @"out": @1, @"reply_to": replyTo};
    }
    [self.messages addObject:localMsg];
    [self.tableView reloadData];
    [self scrollToBottom];
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"ChatSoundEnabled"]) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"chat_sound" ofType:@"wav"];
        if (path) {
            SystemSoundID soundID;
            AudioServicesCreateSystemSoundID((__bridge CFURLRef)[NSURL fileURLWithPath:path], &soundID);
            AudioServicesPlaySystemSound(soundID);
        }
    }
    
    if (replyTo) {
        [[VKAPIClient sharedClient] sendMessage:text toPeerId:self.peerId replyTo:replyTo completion:^(BOOL success, NSError *error) {
            if (error) {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    } else {
        [[VKAPIClient sharedClient] sendMessage:text toPeerId:self.peerId completion:^(BOOL success, NSError *error) {
            if (error) {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    }
}

#pragma mark - Загрузка данных
- (void)loadUserInfo {
    NSInteger peer = [self.peerId integerValue];
    if (peer > 0) {
        [[VKAPIClient sharedClient] profileGetInfoWithUserId:self.peerId completion:^(NSDictionary *userInfo, NSError *error) {
            if (!error && userInfo) {
                self.userInfo = userInfo;
                NSString *firstName = userInfo[@"first_name"] ?: @"";
                NSString *lastName = userInfo[@"last_name"] ?: @"";
                if (firstName.length > 0 || lastName.length > 0) {
                    NSString *newTitle = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
                    self.title = newTitle;
                    self.navigationItem.title = newTitle;
                }
            }
        }];
    }
}

- (void)loadHistory {
    [self loadHistoryWithOffset:0 completion:nil];
}

- (void)loadHistoryWithOffset:(NSInteger)offset completion:(void(^)(NSError *error))completion {
    if (self.isLoadingMore) return;
    if (offset > 0 && self.noMoreMessages) return;
    
    self.isLoadingMore = YES;
    if (offset == 0) {
        [self.spinner startAnimating];
    } else {
        [self.loadingMoreSpinner startAnimating];
    }
    
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    if (!token) {
        if (completion) completion([NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
        return;
    }
    NSInteger count = 30;
    NSString *urlString = [NSString stringWithFormat:@"%@messages.getHistory?peer_id=%@&count=%ld&offset=%ld&v=5.131&access_token=%@",
                           [[VKAPIClient sharedClient] baseURLString], self.peerId, (long)count, (long)offset, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.isLoadingMore = NO;
            if (offset == 0) [self.spinner stopAnimating];
            else [self.loadingMoreSpinner stopAnimating];
            if (error) { if (completion) completion(error); return; }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                if (completion) completion(apiError);
                return;
            }
            NSDictionary *response = json[@"response"];
            NSArray *items = response[@"items"];
            self.totalCount = [response[@"count"] integerValue];
            if (items.count == 0) self.noMoreMessages = YES;
            NSArray *reversed = [[items reverseObjectEnumerator] allObjects];
            if (offset == 0) self.messages = [NSMutableArray arrayWithArray:reversed];
            else {
                NSMutableIndexSet *indexes = [NSMutableIndexSet indexSet];
                for (NSInteger i = 0; i < reversed.count; i++) [indexes addIndex:i];
                [self.messages insertObjects:reversed atIndexes:indexes];
            }
            self.currentOffset = offset + items.count;
            [self.tableView reloadData];
            if (offset == 0) [self scrollToBottom];
            if (completion) completion(nil);
            
            if (offset == 0) {
                [[VKAPIClient sharedClient] markMessagesAsReadWithPeerId:self.peerId completion:^(BOOL success, NSError *error) {
                    if (success) {
                        [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
                        [(AppDelegate *)[UIApplication sharedApplication].delegate updateBadgeCount];
                    }
                }];
            }
        });
    });
}

- (void)scrollToBottom {
    if (self.messages.count) {
        NSIndexPath *ip = [NSIndexPath indexPathForRow:self.messages.count-1 inSection:0];
        [self.tableView scrollToRowAtIndexPath:ip atScrollPosition:UITableViewScrollPositionBottom animated:NO];
    }
}

#pragma mark - Отправка фото и видео
- (void)sendPhoto:(UIImage *)photo {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] uploadPhotoForMessage:photo completion:^(NSString *attachment, NSError *error) {
        [self.spinner stopAnimating];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        [[VKAPIClient sharedClient] sendMessage:@"" toPeerId:self.peerId attachment:attachment stickerId:nil completion:^(BOOL success, NSError *err) {
            if (err) {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:err.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            } else {
                NSDictionary *localMsg = @{@"text": @"[Фото]", @"out": @1, @"attachment": attachment};
                [self.messages addObject:localMsg];
                NSInteger newIndex = self.messages.count - 1;
                [self.tableView reloadData];
                [self scrollToBottom];
                [self loadPhotoForAttachment:attachment atIndex:newIndex];
            }
        }];
    }];
}

- (void)sendVideo:(NSURL *)videoURL {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] uploadVideoForMessage:videoURL completion:^(NSString *attachment, NSError *error) {
        [self.spinner stopAnimating];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        [[VKAPIClient sharedClient] sendMessage:@"" toPeerId:self.peerId attachment:attachment stickerId:nil completion:^(BOOL success, NSError *err) {
            if (err) {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:err.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            } else {
                // Парсим attachment для создания локального сообщения
                NSArray *parts = [attachment componentsSeparatedByString:@"_"];
                NSString *ownerId = parts.count > 1 ? parts[1] : @"";
                NSString *videoId = parts.count > 2 ? parts[2] : @"";
                NSDictionary *videoDict = @{@"owner_id": ownerId, @"id": videoId};
                NSDictionary *localMsg = @{@"text": @"[Видео]", @"out": @1, @"attachments": @[@{@"type": @"video", @"video": videoDict}]};
                [self.messages addObject:localMsg];
                [self.tableView reloadData];
                [self scrollToBottom];
            }
        }];
    }];
}

- (void)loadPhotoForAttachment:(NSString *)attachment atIndex:(NSInteger)index {
    if (index < 0 || index >= self.messages.count) return;
    if (self.attachmentCache[attachment]) {
        [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        return;
    }
    NSArray *parts = [attachment componentsSeparatedByString:@"_"];
    if (parts.count != 2) return;
    NSString *ownerId = parts[0];
    NSString *photoId = parts[1];
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    if (!token) return;
    NSString *urlString = [NSString stringWithFormat:@"%@photos.getById?photos=%@_%@&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], ownerId, photoId, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!json[@"response"] || [json[@"response"] count] == 0) return;
            NSDictionary *photoInfo = json[@"response"][0];
            NSString *photoURL = photoInfo[@"photo_1280"] ?: photoInfo[@"photo_807"] ?: photoInfo[@"photo_604"] ?: photoInfo[@"photo_320"] ?: photoInfo[@"photo_130"];
            if (!photoURL) {
                NSArray *sizes = photoInfo[@"sizes"];
                if ([sizes isKindOfClass:[NSArray class]] && sizes.count > 0) {
                    for (NSDictionary *size in sizes) {
                        NSString *type = size[@"type"];
                        if ([type isEqualToString:@"x"] || [type isEqualToString:@"z"] || [type isEqualToString:@"m"] || [type isEqualToString:@"o"]) {
                            photoURL = size[@"url"];
                            break;
                        }
                    }
                    if (!photoURL) photoURL = [sizes[0] objectForKey:@"url"];
                }
            }
            if (photoURL) {
                self.attachmentCache[attachment] = photoURL;
                [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                    if (image) {
                        [self.imageCache setObject:image forKey:photoURL];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            NSIndexPath *ip = [NSIndexPath indexPathForRow:index inSection:0];
                            [self.tableView reloadRowsAtIndexPaths:@[ip] withRowAnimation:UITableViewRowAnimationNone];
                        });
                    }
                }];
            }
        });
    });
}

- (void)photoButtonTapped {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    picker.allowsEditing = NO;
    [self presentModalViewController:picker animated:YES];
}

- (void)videoButtonTapped {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.mediaTypes = @[@"public.movie"];
    picker.delegate = self;
    picker.allowsEditing = NO;
    [self presentModalViewController:picker animated:YES];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    NSString *mediaType = info[UIImagePickerControllerMediaType];
    if ([mediaType isEqualToString:@"public.movie"]) {
        NSURL *videoURL = info[UIImagePickerControllerMediaURL];
        [self dismissModalViewControllerAnimated:YES];
        [self sendVideo:videoURL];
    } else {
        UIImage *image = info[UIImagePickerControllerOriginalImage];
        [self dismissModalViewControllerAnimated:YES];
        if (image) [self sendPhoto:image];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.messages.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *msg = self.messages[indexPath.row];
    NSString *text = msg[@"text"] ?: @"";
    NSArray *attachments = msg[@"attachments"];
    for (NSDictionary *attach in attachments) {
        NSString *type = attach[@"type"];
        if ([type isEqualToString:@"sticker"]) return 160;
        if ([type isEqualToString:@"photo"]) return 220;
        if ([type isEqualToString:@"video"]) return 220;
    }
    if (msg[@"attachment"] || [text isEqualToString:@"[Фото]"]) return 220;
    if ([text isEqualToString:@"[Стикер]"]) return 160;
    if ([text isEqualToString:@"[Видео]"]) return 160;
    CGSize size = [text sizeWithFont:[UIFont fontWithName:@"HelveticaNeue" size:15]
                   constrainedToSize:CGSizeMake(self.view.bounds.size.width - 80, CGFLOAT_MAX)
                       lineBreakMode:UILineBreakModeWordWrap];
    return size.height + 45;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"ChatCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImageView *bubbleView = [[UIImageView alloc] init];
        bubbleView.tag = 100;
        bubbleView.contentMode = UIViewContentModeScaleToFill;
        [cell.contentView addSubview:bubbleView];
        
        UILabel *messageLabel = [[UILabel alloc] init];
        messageLabel.tag = 101;
        messageLabel.numberOfLines = 0;
        messageLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:15];
        messageLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:messageLabel];
        
        UILabel *nameLabel = [[UILabel alloc] init];
        nameLabel.tag = 102;
        nameLabel.font = [UIFont boldSystemFontOfSize:12];
        nameLabel.textColor = [UIColor colorWithWhite:0.3 alpha:1.0];
        nameLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:nameLabel];
        
        UIImageView *mediaView = [[UIImageView alloc] init];
        mediaView.tag = 103;
        mediaView.contentMode = UIViewContentModeScaleAspectFit;
        mediaView.backgroundColor = [UIColor clearColor];
        mediaView.clipsToBounds = YES;
        [cell.contentView addSubview:mediaView];
    }
    
    NSDictionary *msg = self.messages[indexPath.row];
    BOOL isOut = [msg[@"out"] boolValue];
    
    UIImageView *bubbleView = (UIImageView *)[cell.contentView viewWithTag:100];
    UILabel *messageLabel = (UILabel *)[cell.contentView viewWithTag:101];
    UILabel *nameLabel = (UILabel *)[cell.contentView viewWithTag:102];
    UIImageView *mediaView = (UIImageView *)[cell.contentView viewWithTag:103];
    
    mediaView.hidden = YES;
    mediaView.image = nil;
    bubbleView.image = nil;
    messageLabel.text = @"";
    nameLabel.text = @"";
    
    if (!isOut) {
        NSString *senderName = @"Пользователь";
        NSNumber *fromId = msg[@"from_id"];
        if (fromId && [fromId integerValue] == [self.peerId integerValue] && self.userInfo) {
            senderName = [NSString stringWithFormat:@"%@ %@", self.userInfo[@"first_name"] ?: @"", self.userInfo[@"last_name"] ?: @""];
        }
        nameLabel.text = senderName;
        nameLabel.textAlignment = NSTextAlignmentLeft;
        nameLabel.frame = CGRectMake(15, 4, self.view.bounds.size.width - 30, 18);
    } else {
        nameLabel.text = @"";
        nameLabel.frame = CGRectZero;
    }
    
    CGFloat topOffset = nameLabel.text.length > 0 ? 22 : 4;
    NSString *text = msg[@"text"] ?: @"";
    BOOL hasPhoto = NO;
    BOOL isSticker = NO;
    BOOL hasVideo = NO;
    NSString *stickerId = nil;
    NSString *attachment = msg[@"attachment"];
    NSDictionary *videoInfo = nil;
    BOOL hasAttachment = NO;
    
    NSArray *attachments = msg[@"attachments"];
    
    // Определяем тип вложения (приоритет: видео > стикер > фото > текст)
    for (NSDictionary *attach in attachments) {
        NSString *type = attach[@"type"];
        if ([type isEqualToString:@"video"]) {
            hasVideo = YES;
            videoInfo = attach[@"video"];
            hasAttachment = YES;
            break; // видео – приоритет, выходим
        } else if ([type isEqualToString:@"sticker"]) {
            isSticker = YES;
            NSDictionary *sticker = attach[@"sticker"];
            stickerId = [sticker[@"sticker_id"] stringValue];
            if (!stickerId) {
                stickerId = [sticker[@"id"] stringValue];
            }
            hasAttachment = YES;
            // не выходим, продолжаем искать видео, но если видео нет, то будет стикер
        } else if ([type isEqualToString:@"photo"]) {
            hasPhoto = YES;
            // обработаем позже
            hasAttachment = YES;
            // не выходим, ищем видео или стикер
        }
    }
    
    // Если есть видео – обрабатываем видео, игнорируем остальное
    if (hasVideo && videoInfo) {
        // ---- Обработка видео ----
        NSString *previewURL = videoInfo[@"photo_800"] ?: videoInfo[@"photo_640"] ?: videoInfo[@"photo_320"] ?: videoInfo[@"photo_130"];
        if (previewURL) {
            mediaView.hidden = NO;
            mediaView.frame = CGRectMake(isOut ? self.view.bounds.size.width - 200 - 10 : 15, topOffset, 180, 180);
            mediaView.contentMode = UIViewContentModeScaleAspectFill;
            mediaView.image = nil;
            [[VKAPIClient sharedClient] downloadImageWithURL:previewURL completion:^(UIImage *image) {
                if (image) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) {
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:103];
                            iv.image = image;
                        }
                    });
                }
            }];
            UIImageView *playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"play_icon"]];
            if (!playIcon.image) {
                UILabel *playLabel = [[UILabel alloc] initWithFrame:mediaView.bounds];
                playLabel.text = @"▶";
                playLabel.textAlignment = NSTextAlignmentCenter;
                playLabel.font = [UIFont systemFontOfSize:60];
                playLabel.textColor = [UIColor whiteColor];
                playLabel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
                [mediaView addSubview:playLabel];
            } else {
                playIcon.contentMode = UIViewContentModeCenter;
                playIcon.frame = mediaView.bounds;
                [mediaView addSubview:playIcon];
            }
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playVideoFromChat:)];
            objc_setAssociatedObject(tap, "ownerId", [videoInfo[@"owner_id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            objc_setAssociatedObject(tap, "videoId", [videoInfo[@"id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [mediaView addGestureRecognizer:tap];
            mediaView.userInteractionEnabled = YES;
            messageLabel.text = @"";
            messageLabel.frame = CGRectZero;
            bubbleView.image = nil;
            bubbleView.backgroundColor = [UIColor clearColor];
        } else {
            // Нет превью – чёрный фон с иконкой
            mediaView.hidden = NO;
            mediaView.frame = CGRectMake(isOut ? self.view.bounds.size.width - 160 - 10 : 15, topOffset, 150, 110);
            mediaView.backgroundColor = [UIColor blackColor];
            mediaView.contentMode = UIViewContentModeCenter;
            mediaView.image = nil;
            
            UIImageView *playIconView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
            playIconView.center = CGPointMake(mediaView.bounds.size.width/2, mediaView.bounds.size.height/2 - 10);
            UIImage *playImage = [UIImage imageNamed:@"play_icon"];
            if (playImage) {
                playIconView.image = playImage;
            } else {
                UIGraphicsBeginImageContextWithOptions(CGSizeMake(50, 50), NO, 0);
                CGContextRef ctx = UIGraphicsGetCurrentContext();
                CGContextSetFillColorWithColor(ctx, [UIColor colorWithWhite:1.0 alpha:0.8].CGColor);
                CGContextBeginPath(ctx);
                CGContextMoveToPoint(ctx, 15, 10);
                CGContextAddLineToPoint(ctx, 40, 25);
                CGContextAddLineToPoint(ctx, 15, 40);
                CGContextClosePath(ctx);
                CGContextFillPath(ctx);
                UIImage *triangle = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
                playIconView.image = triangle;
            }
            playIconView.contentMode = UIViewContentModeScaleAspectFit;
            [mediaView addSubview:playIconView];
            
            UILabel *videoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, mediaView.bounds.size.height - 25, mediaView.bounds.size.width, 18)];
            videoLabel.text = @"Видео";
            videoLabel.textAlignment = NSTextAlignmentCenter;
            videoLabel.textColor = [UIColor whiteColor];
            videoLabel.font = [UIFont boldSystemFontOfSize:13];
            [mediaView addSubview:videoLabel];
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playVideoFromChat:)];
            objc_setAssociatedObject(tap, "ownerId", [videoInfo[@"owner_id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            objc_setAssociatedObject(tap, "videoId", [videoInfo[@"id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [mediaView addGestureRecognizer:tap];
            mediaView.userInteractionEnabled = YES;
            messageLabel.text = @"";
            messageLabel.frame = CGRectZero;
            bubbleView.image = nil;
            bubbleView.backgroundColor = [UIColor clearColor];
        }
        // Видео обработано – выходим, не проверяем стикеры/фото
        return cell;
    }
    
    // Если нет видео, но есть стикер
    if (isSticker && stickerId) {
        // ---- Обработка стикера ----
        mediaView.hidden = NO;
        mediaView.frame = CGRectMake(isOut ? self.view.bounds.size.width - 130 - 10 : 15, topOffset, 120, 120);
        mediaView.contentMode = UIViewContentModeScaleAspectFit;
        NSString *cacheKey = [NSString stringWithFormat:@"sticker_%@", stickerId];
        UIImage *cached = [self.imageCache objectForKey:cacheKey];
        if (cached) {
            mediaView.image = cached;
        } else {
            mediaView.image = nil;
            [[VKAPIClient sharedClient] getStickerImageWithId:stickerId completion:^(UIImage *image, NSError *error) {
                if (image) {
                    [self.imageCache setObject:image forKey:cacheKey];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) {
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:103];
                            if (iv) {
                                iv.image = image;
                            }
                        }
                    });
                } else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) {
                            UILabel *label = (UILabel *)[updateCell.contentView viewWithTag:101];
                            if (label) {
                                label.text = @"😊 Стикер";
                                label.frame = CGRectMake(isOut ? self.view.bounds.size.width - 120 : 15, topOffset + 4, 100, 30);
                                label.textColor = isOut ? [UIColor whiteColor] : [UIColor blackColor];
                            }
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:103];
                            iv.hidden = YES;
                        }
                    });
                }
            }];
        }
        messageLabel.text = @"";
        messageLabel.frame = CGRectZero;
        bubbleView.image = nil;
        bubbleView.backgroundColor = [UIColor clearColor];
        return cell;
    }
    
    // Если нет видео и нет стикера, но есть фото
    if (hasPhoto) {
        // ---- Обработка фото ----
        NSDictionary *photo = nil;
        for (NSDictionary *attach in attachments) {
            if ([attach[@"type"] isEqualToString:@"photo"]) {
                photo = attach[@"photo"];
                break;
            }
        }
        if (photo) {
            NSString *photoURL = photo[@"photo_1280"] ?: photo[@"photo_807"] ?: photo[@"photo_604"] ?: photo[@"photo_320"] ?: photo[@"photo_130"];
            if (!photoURL) {
                NSArray *sizes = photo[@"sizes"];
                if ([sizes isKindOfClass:[NSArray class]] && sizes.count > 0) {
                    for (NSDictionary *size in sizes) {
                        NSString *type = size[@"type"];
                        if ([type isEqualToString:@"x"] || [type isEqualToString:@"z"] || [type isEqualToString:@"m"] || [type isEqualToString:@"o"]) {
                            photoURL = size[@"url"];
                            break;
                        }
                    }
                    if (!photoURL) photoURL = [sizes[0] objectForKey:@"url"];
                }
            }
            if (photoURL) {
                mediaView.hidden = NO;
                mediaView.frame = CGRectMake(isOut ? self.view.bounds.size.width - 200 - 10 : 15, topOffset, 180, 180);
                UIImage *cached = [self.imageCache objectForKey:photoURL];
                if (cached) {
                    mediaView.image = cached;
                } else {
                    [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                        if (image) {
                            [self.imageCache setObject:image forKey:photoURL];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                                if (updateCell) {
                                    UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:103];
                                    iv.image = image;
                                }
                            });
                        }
                    }];
                }
                messageLabel.text = @"";
                messageLabel.frame = CGRectZero;
                bubbleView.image = nil;
                bubbleView.backgroundColor = [UIColor clearColor];
            } else {
                // Если нет прямой ссылки – пробуем через loadPhotoForAttachment
                NSString *ownerId = [photo[@"owner_id"] stringValue];
                NSString *photoId = [photo[@"id"] stringValue];
                if (ownerId && photoId) {
                    [self loadPhotoForAttachment:[NSString stringWithFormat:@"%@_%@", ownerId, photoId] atIndex:indexPath.row];
                    mediaView.hidden = NO;
                    mediaView.frame = CGRectMake(isOut ? self.view.bounds.size.width - 200 - 10 : 15, topOffset, 180, 180);
                    mediaView.backgroundColor = [UIColor lightGrayColor];
                    mediaView.image = nil;
                    messageLabel.text = @"";
                    messageLabel.frame = CGRectZero;
                    bubbleView.image = nil;
                    bubbleView.backgroundColor = [UIColor clearColor];
                }
            }
            return cell;
        }
    }
    
    // Если нет вложений – это текстовое сообщение
    // Проверка на локальные фоллбеки
    if ([text isEqualToString:@"[Стикер]"] && !hasAttachment) {
        // Может быть локальный стикер без вложений
        stickerId = msg[@"sticker_id"];
        if (!stickerId) stickerId = @"1";
        // Обрабатываем как стикер
        mediaView.hidden = NO;
        mediaView.frame = CGRectMake(isOut ? self.view.bounds.size.width - 130 - 10 : 15, topOffset, 120, 120);
        mediaView.contentMode = UIViewContentModeScaleAspectFit;
        NSString *cacheKey = [NSString stringWithFormat:@"sticker_%@", stickerId];
        UIImage *cached = [self.imageCache objectForKey:cacheKey];
        if (cached) {
            mediaView.image = cached;
        } else {
            mediaView.image = nil;
            [[VKAPIClient sharedClient] getStickerImageWithId:stickerId completion:^(UIImage *image, NSError *error) {
                if (image) {
                    [self.imageCache setObject:image forKey:cacheKey];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) {
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:103];
                            if (iv) {
                                iv.image = image;
                            }
                        }
                    });
                } else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) {
                            UILabel *label = (UILabel *)[updateCell.contentView viewWithTag:101];
                            if (label) {
                                label.text = @"😊 Стикер";
                                label.frame = CGRectMake(isOut ? self.view.bounds.size.width - 120 : 15, topOffset + 4, 100, 30);
                                label.textColor = isOut ? [UIColor whiteColor] : [UIColor blackColor];
                            }
                            UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:103];
                            iv.hidden = YES;
                        }
                    });
                }
            }];
        }
        messageLabel.text = @"";
        messageLabel.frame = CGRectZero;
        bubbleView.image = nil;
        bubbleView.backgroundColor = [UIColor clearColor];
        return cell;
    }
    
    if ([text isEqualToString:@"[Фото]"] && !hasAttachment) {
        // Локальное фото – обработаем через attachment
        attachment = msg[@"attachment"];
        if (attachment) {
            // аналогично фото блоку
            NSString *photoURL = self.attachmentCache[attachment];
            if (photoURL) {
                mediaView.hidden = NO;
                mediaView.frame = CGRectMake(isOut ? self.view.bounds.size.width - 200 - 10 : 15, topOffset, 180, 180);
                UIImage *cached = [self.imageCache objectForKey:photoURL];
                if (cached) {
                    mediaView.image = cached;
                } else {
                    [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                        if (image) {
                            [self.imageCache setObject:image forKey:photoURL];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                                if (updateCell) {
                                    UIImageView *iv = (UIImageView *)[updateCell.contentView viewWithTag:103];
                                    iv.image = image;
                                }
                            });
                        }
                    }];
                }
                messageLabel.text = @"";
                messageLabel.frame = CGRectZero;
                bubbleView.image = nil;
                bubbleView.backgroundColor = [UIColor clearColor];
            } else {
                messageLabel.text = @"📷 Фото";
                messageLabel.frame = CGRectMake(isOut ? self.view.bounds.size.width - 120 : 15, topOffset, 100, 30);
                messageLabel.textColor = isOut ? [UIColor whiteColor] : [UIColor blackColor];
                mediaView.hidden = YES;
                [self loadPhotoForAttachment:attachment atIndex:indexPath.row];
            }
            return cell;
        }
    }
    
    // Если [Видео] без вложений – такого быть не должно, но обработаем
    if ([text isEqualToString:@"[Видео]"] && !hasAttachment) {
        messageLabel.text = @"🎬 Видео";
        messageLabel.frame = CGRectMake(isOut ? self.view.bounds.size.width - 120 : 15, topOffset, 100, 30);
        messageLabel.textColor = isOut ? [UIColor whiteColor] : [UIColor blackColor];
        mediaView.hidden = YES;
        bubbleView.image = nil;
        bubbleView.backgroundColor = [UIColor clearColor];
        return cell;
    }
    
    // Обычное текстовое сообщение
    CGSize textSize = [text sizeWithFont:[UIFont fontWithName:@"HelveticaNeue" size:15]
                       constrainedToSize:CGSizeMake(self.view.bounds.size.width - 80, CGFLOAT_MAX)
                           lineBreakMode:UILineBreakModeWordWrap];
    CGFloat bubbleWidth = textSize.width + 30;
    CGFloat bubbleHeight = textSize.height + 20;
    CGFloat maxWidth = self.view.bounds.size.width - 40;
    if (bubbleWidth > maxWidth) bubbleWidth = maxWidth;
    
    CGFloat x = isOut ? self.view.bounds.size.width - bubbleWidth - 10 : 10;
    CGFloat y = topOffset;
    bubbleView.frame = CGRectMake(x, y, bubbleWidth, bubbleHeight);
    
    if (isOut) {
        CAGradientLayer *gradient = [CAGradientLayer layer];
        gradient.frame = bubbleView.bounds;
        gradient.cornerRadius = 12;
        gradient.colors = @[(id)[UIColor colorWithRed:0.2 green:0.45 blue:0.8 alpha:1.0].CGColor,
                            (id)[UIColor colorWithRed:0.1 green:0.25 blue:0.6 alpha:1.0].CGColor];
        gradient.locations = @[@0, @1];
        UIGraphicsBeginImageContextWithOptions(gradient.bounds.size, NO, 0);
        [gradient renderInContext:UIGraphicsGetCurrentContext()];
        UIImage *gradientImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        bubbleView.image = [gradientImage resizableImageWithCapInsets:UIEdgeInsetsMake(20, 20, 20, 20) resizingMode:UIImageResizingModeStretch];
        bubbleView.backgroundColor = [UIColor clearColor];
    } else {
        bubbleView.image = nil;
        bubbleView.backgroundColor = [UIColor whiteColor];
        bubbleView.layer.cornerRadius = 12;
        bubbleView.layer.masksToBounds = YES;
        bubbleView.layer.shadowColor = [UIColor blackColor].CGColor;
        bubbleView.layer.shadowOffset = CGSizeMake(0, 1);
        bubbleView.layer.shadowOpacity = 0.15;
        bubbleView.layer.shadowRadius = 2;
    }
    
    messageLabel.text = text;
    messageLabel.frame = CGRectMake(x + 12, y + 8, bubbleWidth - 24, textSize.height);
    if (isOut) {
        messageLabel.textColor = [UIColor whiteColor];
        messageLabel.textAlignment = NSTextAlignmentRight;
    } else {
        messageLabel.textColor = [UIColor blackColor];
        messageLabel.textAlignment = NSTextAlignmentLeft;
    }
    mediaView.hidden = YES;
    
    return cell;
}

- (void)playVideoFromChat:(UITapGestureRecognizer *)gesture {
    NSString *ownerId = objc_getAssociatedObject(gesture, "ownerId");
    NSString *videoId = objc_getAssociatedObject(gesture, "videoId");
    if (ownerId && videoId) {
        VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
        [self.navigationController pushViewController:playerVC animated:YES];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self sendMessage];
    return YES;
}

#pragma mark - UIScrollViewDelegate для пагинации
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView.contentOffset.y < -60 && !self.isLoadingMore && !self.noMoreMessages && self.currentOffset < self.totalCount) {
        [self loadHistoryWithOffset:self.currentOffset completion:nil];
    }
}

#pragma mark - Keyboard handling
- (void)keyboardWillShow:(NSNotification *)notification {
    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat height = keyboardFrame.size.height;
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect frame = self.tableView.frame;
        frame.size.height = self.view.bounds.size.height - height - 44;
        self.tableView.frame = frame;
        UIView *inputBar = self.inputField.superview;
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - height - 44, self.view.bounds.size.width, 44);
        [self scrollToBottom];
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect frame = self.tableView.frame;
        frame.size.height = self.view.bounds.size.height - 44;
        self.tableView.frame = frame;
        UIView *inputBar = self.inputField.superview;
        inputBar.frame = CGRectMake(0, self.view.bounds.size.height - 44, self.view.bounds.size.width, 44);
    }];
}

@end