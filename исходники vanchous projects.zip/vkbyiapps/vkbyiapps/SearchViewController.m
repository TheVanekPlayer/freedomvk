// SearchViewController.m
#import "SearchViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "ProfileViewController.h"
#import "GroupWallViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface SearchViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
@property (nonatomic, strong) UITextField *searchField;
@property (nonatomic, strong) UIButton *searchButton;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *results;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) UISegmentedControl *typeSegmented;
@property (nonatomic, strong) NSMutableDictionary *avatarCache;
@end

@implementation SearchViewController

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"Поиск";
    self.avatarCache = [NSMutableDictionary dictionary];
    
    self.searchField = [[UITextField alloc] initWithFrame:CGRectMake(10, 10, self.view.bounds.size.width - 80, 40)];
    self.searchField.placeholder = @"Введите запрос";
    self.searchField.borderStyle = UITextBorderStyleRoundedRect;
    self.searchField.delegate = self;
    self.searchField.returnKeyType = UIReturnKeySearch;
    [self.view addSubview:self.searchField];
    
    self.searchButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.searchButton.frame = CGRectMake(self.view.bounds.size.width - 65, 10, 55, 40);
    [self.searchButton setTitle:@"Искать" forState:UIControlStateNormal];
    [self.searchButton addTarget:self action:@selector(performSearch) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.searchButton];
    
    self.typeSegmented = [[UISegmentedControl alloc] initWithItems:@[@"Пользователи", @"Сообщества"]];
    self.typeSegmented.frame = CGRectMake(10, 55, self.view.bounds.size.width - 20, 30);
    self.typeSegmented.selectedSegmentIndex = 0;
    [self.typeSegmented addTarget:self action:@selector(searchTypeChanged:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:self.typeSegmented];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 95, self.view.bounds.size.width, self.view.bounds.size.height - 95)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.rowHeight = 54;
    [self.view addSubview:self.tableView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)searchTypeChanged:(UISegmentedControl *)sender {
    if (self.searchField.text.length) [self performSearch];
}

- (void)performSearch {
    NSString *query = [self.searchField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (query.length == 0) {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Введите запрос" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        return;
    }
    [self.searchField resignFirstResponder];
    [self.spinner startAnimating];
    NSInteger type = self.typeSegmented.selectedSegmentIndex;
    if (type == 0) {
        [[VKAPIClient sharedClient] searchUsersWithQuery:query completion:^(NSArray *users, NSError *error) {
            [self.spinner stopAnimating];
            if (error) {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                return;
            }
            self.results = users ?: @[];
            [self.tableView reloadData];
        }];
    } else {
        [[VKAPIClient sharedClient] searchGroupsWithQuery:query completion:^(NSArray *groups, NSError *error) {
            [self.spinner stopAnimating];
            if (error) {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                return;
            }
            self.results = groups ?: @[];
            [self.tableView reloadData];
        }];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self performSearch];
    return YES;
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.results.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"SearchCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.textLabel.font = [UIFont systemFontOfSize:15];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = 0;
    }
    NSInteger type = self.typeSegmented.selectedSegmentIndex;
    if (type == 0) {
        NSDictionary *user = self.results[indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", user[@"first_name"] ?: @"", user[@"last_name"] ?: @""];
        cell.detailTextLabel.text = @"Пользователь";
        NSString *avatarURL = user[@"photo_50"];
        if (avatarURL) {
            UIImage *cached = self.avatarCache[avatarURL];
            if (cached) cell.imageView.image = cached;
            else {
                cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
                [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                    if (image) {
                        self.avatarCache[avatarURL] = image;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                            if (updateCell) updateCell.imageView.image = image;
                        });
                    }
                }];
            }
        } else {
            cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
        }
    } else {
        NSDictionary *group = self.results[indexPath.row];
        cell.textLabel.text = group[@"name"] ?: @"Без названия";
        cell.detailTextLabel.text = @"Сообщество";
        NSString *avatarURL = group[@"photo_50"];
        if (avatarURL) {
            UIImage *cached = self.avatarCache[avatarURL];
            if (cached) cell.imageView.image = cached;
            else {
                cell.imageView.image = [UIImage imageNamed:@"default_group"];
                [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                    if (image) {
                        self.avatarCache[avatarURL] = image;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                            if (updateCell) updateCell.imageView.image = image;
                        });
                    }
                }];
            }
        } else {
            cell.imageView.image = [UIImage imageNamed:@"default_group"];
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSInteger type = self.typeSegmented.selectedSegmentIndex;
    if (type == 0) {
        NSDictionary *user = self.results[indexPath.row];
        ProfileViewController *profileVC = [[ProfileViewController alloc] initWithUserId:[user[@"id"] stringValue]];
        profileVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:profileVC animated:YES];
    } else {
        NSDictionary *group = self.results[indexPath.row];
        GroupWallViewController *wallVC = [[GroupWallViewController alloc] initWithGroupId:[NSString stringWithFormat:@"-%@", group[@"id"]] name:group[@"name"] avatarURL:group[@"photo_50"]];
        wallVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:wallVC animated:YES];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.searchField resignFirstResponder];
}

@end