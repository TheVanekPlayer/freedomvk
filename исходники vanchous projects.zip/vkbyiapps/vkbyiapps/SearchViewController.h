// SearchViewController.h
#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController
@property (nonatomic, unsafe_unretained) id sideMenuController;
@end