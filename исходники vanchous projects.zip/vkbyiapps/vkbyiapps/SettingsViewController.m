// SettingsViewController.m
#import "SettingsViewController.h"
#import "SideMenuViewController.h"
#import "ThemeManager.h"

@interface SettingsViewController () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate> {
    UITableView *tableView;
    UITextField *proxyField;
    UISwitch *proxySwitch;
    UISwitch *directSSLSwitch;
    UISwitch *soundSwitch;
    UISwitch *themeSwitch;
}
@end

@implementation SettingsViewController

- (void)loadView {
    [super loadView];
    self.title = @"Настройки";
    // ВСЕГДА светлый фон с текстурой (независимо от темы)
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"linen_soft.png"]];
    
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.backgroundView = nil;
    [self.view addSubview:tableView];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    // Подписываемся на смену темы, но только для обновления свитча, фон не меняем
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)themeDidChange:(NSNotification *)notification {
    // Обновляем только свитч
    [tableView reloadData];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0: return 2;
        case 1: return 2;
        case 2: return 1;
        case 3: return 1;
        default: return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case 0: return @"Прокси-сервер";
        case 1: return @"Дополнительно";
        case 2: return @"Оформление";
        case 3: return @"О приложении";
        default: return @"";
    }
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"SettingsCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor whiteColor]; // всегда белый
        cell.textLabel.font = [UIFont systemFontOfSize:16];
        cell.textLabel.textColor = [UIColor blackColor]; // всегда чёрный
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    // Очищаем ячейку
    for (UIView *subview in cell.contentView.subviews) {
        if (![subview isKindOfClass:[UILabel class]] && ![subview isKindOfClass:[UISwitch class]] && ![subview isKindOfClass:[UITextField class]]) {
            [subview removeFromSuperview];
        }
    }
    cell.accessoryView = nil;
    cell.textLabel.text = @"";
    
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"Использовать прокси";
            if (!proxySwitch) {
                proxySwitch = [[UISwitch alloc] init];
                [proxySwitch addTarget:self action:@selector(proxySwitchChanged) forControlEvents:UIControlEventValueChanged];
            }
            proxySwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"UseProxy"];
            cell.accessoryView = proxySwitch;
        } else if (indexPath.row == 1) {
            cell.textLabel.text = @"Адрес прокси";
            if (!proxyField) {
                proxyField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
                proxyField.borderStyle = UITextBorderStyleRoundedRect;
                proxyField.placeholder = @"http://192.168.1.5:8080";
                proxyField.font = [UIFont systemFontOfSize:14];
                proxyField.delegate = self;
                proxyField.autocapitalizationType = UITextAutocapitalizationTypeNone;
                proxyField.returnKeyType = UIReturnKeyDone;
                proxyField.textAlignment = NSTextAlignmentRight;
                proxyField.textColor = [UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0];
                proxyField.backgroundColor = [UIColor whiteColor];
            }
            NSString *proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"ProxyAddress"];
            proxyField.text = proxy ?: @"";
            proxyField.enabled = proxySwitch.on;
            cell.accessoryView = proxyField;
        }
    } else if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"Обход SSL (прямое подключение)";
            if (!directSSLSwitch) {
                directSSLSwitch = [[UISwitch alloc] init];
                [directSSLSwitch addTarget:self action:@selector(directSSLChanged) forControlEvents:UIControlEventValueChanged];
            }
            directSSLSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"UseDirectSSL"];
            cell.accessoryView = directSSLSwitch;
        } else if (indexPath.row == 1) {
            cell.textLabel.text = @"Звук при отправке";
            if (!soundSwitch) {
                soundSwitch = [[UISwitch alloc] init];
                [soundSwitch addTarget:self action:@selector(soundSwitchChanged) forControlEvents:UIControlEventValueChanged];
            }
            soundSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"ChatSoundEnabled"];
            cell.accessoryView = soundSwitch;
        }
    } else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            // Изменяем текст ячейки: добавляем пояснение
            cell.textLabel.text = @"Тёмная тема (после перезапуска)";
            if (!themeSwitch) {
                themeSwitch = [[UISwitch alloc] init];
                [themeSwitch addTarget:self action:@selector(themeSwitchChanged:) forControlEvents:UIControlEventValueChanged];
            }
            themeSwitch.on = [ThemeManager isDarkTheme];
            cell.accessoryView = themeSwitch;
        }
    } else if (indexPath.section == 3) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"";
            cell.textLabel.textAlignment = NSTextAlignmentCenter;
            cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
            cell.textLabel.textColor = [UIColor grayColor];
            
            UILabel *versionLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 8, self.view.bounds.size.width, 20)];
            versionLabel1.text = @"VK by iapps 0.14.0 от vanchous";
            versionLabel1.textAlignment = NSTextAlignmentCenter;
            versionLabel1.font = [UIFont systemFontOfSize:14];
            versionLabel1.textColor = [UIColor grayColor];
            versionLabel1.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:versionLabel1];
            
            UILabel *versionLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 30, self.view.bounds.size.width, 20)];
            versionLabel2.text = @"VK Legacy = dead";
            versionLabel2.textAlignment = NSTextAlignmentCenter;
            versionLabel2.font = [UIFont italicSystemFontOfSize:12];
            versionLabel2.textColor = [UIColor grayColor];
            versionLabel2.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:versionLabel2];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 3 && indexPath.row == 0) return 60.0;
    return 44.0;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0 && indexPath.row == 1) {
        [proxyField becomeFirstResponder];
    }
}

#pragma mark - Switch handlers

- (void)proxySwitchChanged {
    BOOL useProxy = proxySwitch.on;
    [[NSUserDefaults standardUserDefaults] setBool:useProxy forKey:@"UseProxy"];
    if (useProxy) {
        directSSLSwitch.on = NO;
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"UseDirectSSL"];
        [self saveProxy];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"ProxyAddress"];
        proxyField.text = @"";
    }
    proxyField.enabled = useProxy;
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)directSSLChanged {
    BOOL useDirect = directSSLSwitch.on;
    [[NSUserDefaults standardUserDefaults] setBool:useDirect forKey:@"UseDirectSSL"];
    if (useDirect) {
        proxySwitch.on = NO;
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"UseProxy"];
        proxyField.enabled = NO;
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)soundSwitchChanged {
    BOOL soundEnabled = soundSwitch.on;
    [[NSUserDefaults standardUserDefaults] setBool:soundEnabled forKey:@"ChatSoundEnabled"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)themeSwitchChanged:(UISwitch *)sender {
    [ThemeManager setDarkTheme:sender.on];
    // Показываем алерт, что нужно перезапустить приложение
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Требуется перезапуск"
                                                    message:@"Для применения темы перезапустите приложение."
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    // Обновляем только свитч, чтобы он отображал новое состояние
    [tableView reloadData];
}

- (void)saveProxy {
    NSString *proxy = proxyField.text;
    if (proxy.length > 0) {
        if (![proxy hasPrefix:@"http://"] && ![proxy hasPrefix:@"https://"]) {
            proxy = [@"http://" stringByAppendingString:proxy];
        }
        NSRange schemeEnd = [proxy rangeOfString:@"://"];
        if (schemeEnd.location != NSNotFound) {
            NSInteger after = schemeEnd.location + schemeEnd.length;
            NSRange colonRange = [proxy rangeOfString:@":" options:0 range:NSMakeRange(after, proxy.length - after)];
            if (colonRange.location == NSNotFound) {
                proxy = [proxy stringByAppendingString:@":8080"];
            }
        }
        if (![proxy hasSuffix:@"/"]) {
            proxy = [proxy stringByAppendingString:@"/"];
        }
        [[NSUserDefaults standardUserDefaults] setObject:proxy forKey:@"ProxyAddress"];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"ProxyAddress"];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    if (proxySwitch.on) {
        [self saveProxy];
    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (proxySwitch.on) {
        [self saveProxy];
    }
}

@end