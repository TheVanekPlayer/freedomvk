// ThemeManager.m
#import "ThemeManager.h"

NSString * const ThemeDidChangeNotification = @"ThemeDidChangeNotification";

@implementation ThemeManager

+ (BOOL)isDarkTheme {
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"DarkTheme"];
}

+ (void)setDarkTheme:(BOOL)dark {
    [[NSUserDefaults standardUserDefaults] setBool:dark forKey:@"DarkTheme"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:ThemeDidChangeNotification object:nil];
}

+ (void)applyThemeToWindow:(UIWindow *)window {
    if ([self isDarkTheme]) {
        window.backgroundColor = [UIColor colorWithWhite:0.12 alpha:1.0];
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    } else {
        UIImage *bg = [self backgroundImage];
        if (bg) {
            window.backgroundColor = [UIColor colorWithPatternImage:bg];
        } else {
            window.backgroundColor = [UIColor colorWithWhite:0.92 alpha:1.0];
        }
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    }
}

+ (UIImage *)backgroundImage {
    if ([self isDarkTheme]) return nil;
    UIImage *img = [UIImage imageNamed:@"linen_soft.png"];
    if (!img) {
        CGRect rect = CGRectMake(0, 0, 1, 1);
        UIGraphicsBeginImageContext(rect.size);
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextSetFillColorWithColor(context, [UIColor colorWithWhite:0.92 alpha:1.0].CGColor);
        CGContextFillRect(context, rect);
        img = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    return img;
}

+ (UIColor *)backgroundColor {
    if ([self isDarkTheme]) {
        return [UIColor colorWithWhite:0.12 alpha:1.0];
    } else {
        UIImage *bg = [self backgroundImage];
        if (bg) {
            return [UIColor colorWithPatternImage:bg];
        } else {
            return [UIColor colorWithWhite:0.92 alpha:1.0];
        }
    }
}

+ (UIColor *)textColor {
    return [self isDarkTheme] ? [UIColor whiteColor] : [UIColor blackColor];
}

+ (UIColor *)cellBackgroundColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.18 alpha:1.0] : [UIColor whiteColor];
}

+ (UIColor *)cellTextColor {
    return [self isDarkTheme] ? [UIColor whiteColor] : [UIColor blackColor];
}

+ (UIColor *)separatorColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.3 alpha:1.0] : [UIColor colorWithWhite:0.85 alpha:1.0];
}

+ (UIColor *)navigationBarTopColor {
    if ([self isDarkTheme]) {
        return [UIColor colorWithWhite:0.25 alpha:1.0];
    } else {
        return [UIColor colorWithRed:0.22 green:0.40 blue:0.65 alpha:1.0];
    }
}

+ (UIColor *)navigationBarBottomColor {
    if ([self isDarkTheme]) {
        return [UIColor colorWithWhite:0.15 alpha:1.0];
    } else {
        return [UIColor colorWithRed:0.12 green:0.25 blue:0.45 alpha:1.0];
    }
}

+ (UIColor *)navigationBarTintColor {
    return [self isDarkTheme] ? [UIColor colorWithWhite:0.4 alpha:1.0] : [UIColor colorWithRed:0.18 green:0.33 blue:0.58 alpha:1.0];
}

+ (UIColor *)navigationBarTitleColor {
    return [UIColor whiteColor];
}

@end