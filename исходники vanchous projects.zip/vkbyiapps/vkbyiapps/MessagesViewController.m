// MessagesViewController.m
#import "MessagesViewController.h"
#import "ChatViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@interface MessagesViewController () <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *conversations;
@property (nonatomic, strong) NSDictionary *profiles;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSMutableDictionary *avatarCache;
@property (nonatomic, strong) UIRefreshControl *refreshControl;
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) NSArray *searchResults;
@property (nonatomic, assign) BOOL isSearching;
@end

@implementation MessagesViewController

- (void)loadView {
    [super loadView];
    self.title = @"Сообщения";
    self.view.backgroundColor = [UIColor whiteColor];
    self.avatarCache = [NSMutableDictionary dictionary];
    self.isSearching = NO;
    
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 44)];
    self.searchBar.delegate = self;
    self.searchBar.placeholder = @"Поиск по сообщениям";
    self.searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.searchBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.tableHeaderView = self.searchBar;
    [self.view addSubview:self.tableView];
    
    // Жест для скрытия клавиатуры
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(loadConversations) forControlEvents:UIControlEventValueChanged];
    [self.tableView addSubview:self.refreshControl];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [self loadConversations];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (self.conversations.count > 0) {
        [[VKAPIClient sharedClient] startLongPollWithCompletion:^(NSDictionary *event) {
            NSInteger code = [event[@"code"] integerValue];
            if (code == 4 || code == 5 || code == 6 || code == 7 || code == 8 || code == 9) {
                [self loadConversations];
            }
        }];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[VKAPIClient sharedClient] stopLongPoll];
}

- (void)dismissKeyboard {
    [self.searchBar resignFirstResponder];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadConversations {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] getConversationsWithCompletion:^(NSArray *conversations, NSDictionary *profiles, NSError *error) {
        [self.spinner stopAnimating];
        [self.refreshControl endRefreshing];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        self.conversations = conversations ?: @[];
        self.profiles = profiles ?: @{};
        self.isSearching = NO;
        self.searchResults = nil;
        [self.tableView reloadData];
        [self updateBadge];
    }];
}

- (void)updateBadge {
    NSInteger totalUnread = 0;
    for (NSDictionary *conv in self.conversations) {
        totalUnread += [conv[@"conversation"][@"unread_count"] integerValue];
    }
    [UIApplication sharedApplication].applicationIconBadgeNumber = totalUnread;
    [(AppDelegate *)[UIApplication sharedApplication].delegate updateBadgeCount];
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if (searchText.length == 0) {
        self.isSearching = NO;
        self.searchResults = nil;
        [self.tableView reloadData];
        return;
    }
    self.isSearching = YES;
    [[VKAPIClient sharedClient] searchMessagesWithQuery:searchText peerId:nil completion:^(NSArray *messages, NSError *error) {
        if (!error && messages) {
            self.searchResults = messages;
            [self.tableView reloadData];
        } else {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка поиска" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        }
    }];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    searchBar.text = @"";
    [searchBar resignFirstResponder];
    self.isSearching = NO;
    self.searchResults = nil;
    [self.tableView reloadData];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.isSearching) {
        return self.searchResults.count;
    }
    return self.conversations.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"ConversationCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:16];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = 0;
        cell.imageView.frame = CGRectMake(0,0,40,40);
    }
    
    NSDictionary *item;
    if (self.isSearching) {
        item = self.searchResults[indexPath.row];
        if (![item isKindOfClass:[NSDictionary class]]) {
            cell.textLabel.text = @"";
            cell.detailTextLabel.text = @"";
            cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
            return cell;
        }
        NSString *text = item[@"text"] ?: @"[Вложение]";
        cell.textLabel.text = text;
        cell.detailTextLabel.text = @"";
        cell.accessoryView = nil;
        cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
        return cell;
    }
    
    NSDictionary *conv = self.conversations[indexPath.row];
    if (![conv isKindOfClass:[NSDictionary class]]) {
        cell.textLabel.text = @"";
        cell.detailTextLabel.text = @"";
        cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
        return cell;
    }
    
    NSDictionary *peer = conv[@"conversation"][@"peer"];
    NSString *title = @"Неизвестно";
    NSString *avatarURL = nil;
    
    if (conv[@"conversation"][@"chat_settings"]) {
        title = conv[@"conversation"][@"chat_settings"][@"title"] ?: @"Беседа";
        avatarURL = conv[@"conversation"][@"chat_settings"][@"photo_50"];
    } else if (peer) {
        NSNumber *uid = peer[@"id"];
        NSDictionary *profile = self.profiles[uid];
        if (profile) {
            title = [NSString stringWithFormat:@"%@ %@", profile[@"first_name"] ?: @"", profile[@"last_name"] ?: @""];
            avatarURL = profile[@"photo_50"] ?: peer[@"photo_50"];
        } else {
            title = [NSString stringWithFormat:@"%@ %@", peer[@"first_name"] ?: @"", peer[@"last_name"] ?: @""];
            avatarURL = peer[@"photo_50"];
        }
    }
    cell.textLabel.text = title;
    NSDictionary *lastMessage = conv[@"last_message"];
    cell.detailTextLabel.text = (lastMessage && [lastMessage isKindOfClass:[NSDictionary class]]) ? (lastMessage[@"text"] ?: @"[Вложение]") : @"";
    NSInteger unread = [conv[@"conversation"][@"unread_count"] integerValue];
    if (unread > 0) {
        UILabel *badge = [[UILabel alloc] initWithFrame:CGRectMake(0,0,24,24)];
        badge.backgroundColor = [UIColor colorWithRed:0.0 green:0.48 blue:1.0 alpha:1.0];
        badge.textColor = [UIColor whiteColor];
        badge.textAlignment = NSTextAlignmentCenter;
        badge.font = [UIFont boldSystemFontOfSize:12];
        badge.text = [NSString stringWithFormat:@"%ld", (long)unread];
        badge.layer.cornerRadius = 12;
        badge.clipsToBounds = YES;
        cell.accessoryView = badge;
    } else {
        cell.accessoryView = nil;
    }
    
    if (avatarURL) {
        UIImage *cached = self.avatarCache[avatarURL];
        if (cached) {
            cell.imageView.image = cached;
        } else {
            cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    self.avatarCache[avatarURL] = image;
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) updateCell.imageView.image = image;
                    });
                }
            }];
        }
    } else {
        cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.isSearching) {
        NSDictionary *msg = self.searchResults[indexPath.row];
        if (![msg isKindOfClass:[NSDictionary class]]) return;
        NSString *peerId = [msg[@"peer_id"] stringValue];
        NSString *title = @"Диалог";
        ChatViewController *chatVC = [[ChatViewController alloc] initWithPeerId:peerId title:title];
        [self.navigationController pushViewController:chatVC animated:YES];
        return;
    }
    NSDictionary *conv = self.conversations[indexPath.row];
    if (![conv isKindOfClass:[NSDictionary class]]) return;
    NSDictionary *peer = conv[@"conversation"][@"peer"];
    NSString *peerId = [peer[@"id"] stringValue];
    NSString *title = @"Диалог";
    if (conv[@"conversation"][@"chat_settings"]) {
        title = conv[@"conversation"][@"chat_settings"][@"title"] ?: @"Беседа";
    } else if (peer) {
        NSNumber *uid = peer[@"id"];
        NSDictionary *profile = self.profiles[uid];
        if (profile) {
            title = [NSString stringWithFormat:@"%@ %@", profile[@"first_name"] ?: @"", profile[@"last_name"] ?: @""];
        } else {
            title = [NSString stringWithFormat:@"%@ %@", peer[@"first_name"] ?: @"", peer[@"last_name"] ?: @""];
        }
    }
    ChatViewController *chatVC = [[ChatViewController alloc] initWithPeerId:peerId title:title];
    [self.navigationController pushViewController:chatVC animated:YES];
}

- (void)dealloc {
    [[VKAPIClient sharedClient] stopLongPoll];
}

@end