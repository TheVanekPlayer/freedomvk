// FeedViewController.m
#import "FeedViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "PostDetailViewController.h"
#import "VideoPlayerViewController.h"
#import "PullToRefreshView.h"
#import "CreatePostViewController.h"
#import "ProfileViewController.h"
#import "GroupWallViewController.h"
#import "FullscreenImageViewController.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

@interface FeedViewController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *tableView;
    NSArray *posts;
    NSDictionary *profiles;
    NSDictionary *groups;
    UIActivityIndicatorView *spinner;
    NSMutableDictionary *imageCache;
    PullToRefreshView *pullToRefresh;
    NSMutableArray *expandedRows;
}
// Свойство sideMenuController объявлено в .h, не дублируем
@end

@implementation FeedViewController
@synthesize sideMenuController;

- (void)loadView {
    [super loadView];
    self.title = @"Новости";
    self.view.backgroundColor = [ThemeManager backgroundColor];
    imageCache = [[NSMutableDictionary alloc] init];
    expandedRows = [[NSMutableArray alloc] init];
    
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    tableView.separatorColor = [ThemeManager separatorColor];
    [self.view addSubview:tableView];
    
    pullToRefresh = [[PullToRefreshView alloc] initWithTableView:tableView refreshBlock:^{
        [self loadFeed];
    }];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = self.view.center;
    [self.view addSubview:spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    UIBarButtonItem *createBtn = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(createPostTapped)];
    self.navigationItem.rightBarButtonItem = createBtn;
    
    [self loadFeed];
    
    // Подписка на смену темы
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)themeDidChange:(NSNotification *)notification {
    self.view.backgroundColor = [ThemeManager backgroundColor];
    tableView.separatorColor = [ThemeManager separatorColor];
    [tableView reloadData];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [self.sideMenuController showMenu];
    }
}

- (void)createPostTapped {
    CreatePostViewController *postVC = [[CreatePostViewController alloc] init];
    [self.navigationController pushViewController:postVC animated:YES];
}

#pragma mark - Загрузка ленты

- (void)loadFeed {
    if (!pullToRefresh.isRefreshing) [spinner startAnimating];
    [[VKAPIClient sharedClient] getNewsfeedWithCompletion:^(NSArray *items, NSArray *profilesArray, NSArray *groupsArray, NSError *error) {
        if (!pullToRefresh.isRefreshing) [spinner stopAnimating];
        [pullToRefresh endRefreshing];
        if (error) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            return;
        }
        posts = items;
        NSMutableDictionary *profDict = [NSMutableDictionary dictionary];
        for (NSDictionary *p in profilesArray) {
            profDict[p[@"id"]] = p;
        }
        profiles = [profDict copy];
        NSMutableDictionary *groupDict = [NSMutableDictionary dictionary];
        for (NSDictionary *g in groupsArray) {
            groupDict[g[@"id"]] = g;
        }
        groups = [groupDict copy];
        [tableView reloadData];
    }];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
    return posts.count;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *post = posts[indexPath.row];
    NSString *text = post[@"text"] ?: @"";
    if (text.length > 30) {
        text = [[text substringToIndex:30] stringByAppendingString:@"..."];
    }
    CGSize textSize = [text sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(self.view.bounds.size.width - 80, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
    CGFloat height = 80 + textSize.height;
    NSArray *attachments = post[@"attachments"];
    if (attachments.count > 0) {
        NSString *type = attachments[0][@"type"];
        if ([type isEqualToString:@"photo"]) height += 200;
        else if ([type isEqualToString:@"video"]) height += 150;
    }
    return height;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"PostCell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellID];
    UIImageView *avatarView, *postImageView, *videoPreviewView;
    UILabel *sourceLabel, *textLabel, *timeLabel, *statsLabel;
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.backgroundColor = [ThemeManager cellBackgroundColor];
        cell.contentView.backgroundColor = [ThemeManager cellBackgroundColor];
        
        avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 50, 50)];
        avatarView.tag = 100;
        avatarView.contentMode = UIViewContentModeScaleAspectFill;
        avatarView.clipsToBounds = YES;
        avatarView.layer.cornerRadius = 0;
        avatarView.layer.borderWidth = 1;
        avatarView.layer.borderColor = [ThemeManager separatorColor].CGColor;
        avatarView.userInteractionEnabled = YES;
        UITapGestureRecognizer *avatarTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(avatarTapped:)];
        [avatarView addGestureRecognizer:avatarTap];
        [cell.contentView addSubview:avatarView];
        
        sourceLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 10, 200, 20)];
        sourceLabel.tag = 101;
        sourceLabel.font = [UIFont boldSystemFontOfSize:16];
        sourceLabel.textColor = [ThemeManager textColor];
        sourceLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:sourceLabel];
        
        timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 32, 100, 15)];
        timeLabel.tag = 102;
        timeLabel.font = [UIFont systemFontOfSize:12];
        timeLabel.textColor = [ThemeManager textColor];
        timeLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:timeLabel];
        
        statsLabel = [[UILabel alloc] initWithFrame:CGRectMake(200, 32, 100, 15)];
        statsLabel.tag = 103;
        statsLabel.font = [UIFont systemFontOfSize:12];
        statsLabel.textColor = [ThemeManager textColor];
        statsLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:statsLabel];
        
        textLabel = [[UILabel alloc] init];
        textLabel.tag = 104;
        textLabel.numberOfLines = 0;
        textLabel.font = [UIFont systemFontOfSize:14];
        textLabel.textColor = [ThemeManager textColor];
        textLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:textLabel];
        
        postImageView = [[UIImageView alloc] init];
        postImageView.tag = 105;
        postImageView.contentMode = UIViewContentModeScaleAspectFit;
        postImageView.clipsToBounds = YES;
        postImageView.backgroundColor = [ThemeManager cellBackgroundColor];
        postImageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *photoTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoTapped:)];
        [postImageView addGestureRecognizer:photoTap];
        [cell.contentView addSubview:postImageView];
        
        videoPreviewView = [[UIImageView alloc] init];
        videoPreviewView.tag = 106;
        videoPreviewView.contentMode = UIViewContentModeScaleAspectFill;
        videoPreviewView.clipsToBounds = YES;
        videoPreviewView.userInteractionEnabled = YES;
        [cell.contentView addSubview:videoPreviewView];
    } else {
        avatarView = (UIImageView *)[cell.contentView viewWithTag:100];
        sourceLabel = (UILabel *)[cell.contentView viewWithTag:101];
        timeLabel = (UILabel *)[cell.contentView viewWithTag:102];
        statsLabel = (UILabel *)[cell.contentView viewWithTag:103];
        textLabel = (UILabel *)[cell.contentView viewWithTag:104];
        postImageView = (UIImageView *)[cell.contentView viewWithTag:105];
        videoPreviewView = (UIImageView *)[cell.contentView viewWithTag:106];
    }
    
    NSDictionary *post = posts[indexPath.row];
    NSString *sourceName = @"";
    NSString *avatarURL = nil;
    NSInteger sourceId = [post[@"source_id"] integerValue];
    if (sourceId > 0) {
        NSDictionary *profile = profiles[@(sourceId)];
        sourceName = [NSString stringWithFormat:@"%@ %@", profile[@"first_name"] ?: @"", profile[@"last_name"] ?: @""];
        avatarURL = profile[@"photo_50"] ?: profile[@"photo_100"];
    } else if (sourceId < 0) {
        NSNumber *groupId = @(-sourceId);
        NSDictionary *group = groups[groupId];
        sourceName = group[@"name"] ?: @"Сообщество";
        avatarURL = group[@"photo_50"] ?: group[@"photo_100"];
    }
    sourceLabel.text = sourceName;
    
    if (avatarURL) {
        UIImage *cached = imageCache[avatarURL];
        if (cached) avatarView.image = cached;
        else {
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) { imageCache[avatarURL] = image; dispatch_async(dispatch_get_main_queue(), ^{ if ([sourceLabel.text isEqualToString:sourceName]) avatarView.image = image; }); }
            }];
        }
    }
    
    NSTimeInterval timestamp = [post[@"date"] doubleValue];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timestamp];
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    df.dateFormat = @"dd.MM HH:mm";
    timeLabel.text = [df stringFromDate:date];
    
    NSNumber *likes = post[@"likes"][@"count"];
    NSNumber *comments = post[@"comments"][@"count"];
    statsLabel.text = [NSString stringWithFormat:@"❤ %@  ✉ %@", likes, comments];
    
    NSString *fullText = post[@"text"] ?: @"";
    NSString *displayText = fullText;
    if (displayText.length > 30) {
        displayText = [[displayText substringToIndex:30] stringByAppendingString:@"..."];
    }
    textLabel.text = displayText;
    CGSize textSize = [displayText sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(self.view.bounds.size.width - 80, CGFLOAT_MAX) lineBreakMode:UILineBreakModeWordWrap];
    textLabel.frame = CGRectMake(70, 55, self.view.bounds.size.width - 80, textSize.height);
    
    postImageView.hidden = YES;
    videoPreviewView.hidden = YES;
    NSArray *attachments = post[@"attachments"];
    CGFloat attachmentY = 55 + textSize.height;
    if (attachments.count > 0) {
        NSDictionary *first = attachments[0];
        if ([first[@"type"] isEqualToString:@"photo"]) {
            postImageView.hidden = NO;
            postImageView.frame = CGRectMake(70, attachmentY, self.view.bounds.size.width - 80, 200);
            NSString *photoURL = [self bestImageURLFromPhoto:first[@"photo"]];
            if (photoURL) {
                UIImage *cached = imageCache[photoURL];
                if (cached) {
                    postImageView.image = cached;
                } else {
                    [[VKAPIClient sharedClient] downloadImageWithURL:photoURL completion:^(UIImage *image) {
                        if (image) { imageCache[photoURL] = image; dispatch_async(dispatch_get_main_queue(), ^{ postImageView.image = image; }); }
                    }];
                }
            }
        } else if ([first[@"type"] isEqualToString:@"video"]) {
            videoPreviewView.hidden = NO;
            videoPreviewView.frame = CGRectMake(70, attachmentY, self.view.bounds.size.width - 80, 150);
            NSString *previewURL = first[@"video"][@"photo_320"] ?: first[@"video"][@"photo_130"];
            if (previewURL) {
                UIImage *cached = imageCache[previewURL];
                if (cached) videoPreviewView.image = cached;
                else {
                    [[VKAPIClient sharedClient] downloadImageWithURL:previewURL completion:^(UIImage *image) {
                        if (image) { imageCache[previewURL] = image; dispatch_async(dispatch_get_main_queue(), ^{ videoPreviewView.image = image; }); }
                    }];
                }
            }
            UIImageView *playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"play_icon"]];
            playIcon.contentMode = UIViewContentModeCenter;
            playIcon.frame = videoPreviewView.bounds;
            [videoPreviewView addSubview:playIcon];
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playVideoFromPost:)];
            objc_setAssociatedObject(tap, "ownerId", [first[@"video"][@"owner_id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            objc_setAssociatedObject(tap, "videoId", [first[@"video"][@"id"] stringValue], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [videoPreviewView addGestureRecognizer:tap];
        }
    }
    return cell;
}

#pragma mark - Действия на тапы

- (void)avatarTapped:(UITapGestureRecognizer *)gesture {
    UIImageView *view = (UIImageView *)gesture.view;
    UITableViewCell *cell = (UITableViewCell *)[[view superview] superview];
    NSIndexPath *indexPath = [tableView indexPathForCell:cell];
    if (!indexPath) return;
    NSDictionary *post = posts[indexPath.row];
    NSInteger sourceId = [post[@"source_id"] integerValue];
    if (sourceId > 0) {
        ProfileViewController *profileVC = [[ProfileViewController alloc] initWithUserId:[NSString stringWithFormat:@"%ld", (long)sourceId]];
        profileVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:profileVC animated:YES];
    } else if (sourceId < 0) {
        NSString *groupId = [NSString stringWithFormat:@"%ld", (long)(-sourceId)];
        NSDictionary *group = groups[@(-sourceId)];
        NSString *name = group[@"name"] ?: @"Группа";
        NSString *avatarURL = group[@"photo_50"];
        GroupWallViewController *wallVC = [[GroupWallViewController alloc] initWithGroupId:groupId name:name avatarURL:avatarURL];
        wallVC.sideMenuController = self.sideMenuController;
        [self.navigationController pushViewController:wallVC animated:YES];
    }
}

- (void)photoTapped:(UITapGestureRecognizer *)gesture {
    UIImageView *imageView = (UIImageView *)gesture.view;
    UIImage *image = imageView.image;
    if (!image) return;
    FullscreenImageViewController *fullscreenVC = [[FullscreenImageViewController alloc] initWithImage:image];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:fullscreenVC];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:nav animated:YES completion:nil];
}

#pragma mark - Видео

- (void)playVideoFromPost:(UITapGestureRecognizer *)gesture {
    NSString *ownerId = objc_getAssociatedObject(gesture, "ownerId");
    NSString *videoId = objc_getAssociatedObject(gesture, "videoId");
    [self playVideoWithOwnerId:ownerId videoId:videoId];
}

- (void)playVideoWithOwnerId:(NSString *)ownerId videoId:(NSString *)videoId {
    @try {
        VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
        [self.navigationController pushViewController:playerVC animated:YES];
    } @catch (NSException *exception) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не удалось открыть видео" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [aTableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *post = posts[indexPath.row];
    NSArray *attachments = post[@"attachments"];
    if (attachments.count > 0 && [attachments[0][@"type"] isEqualToString:@"video"]) {
        NSDictionary *video = attachments[0][@"video"];
        VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:[video[@"owner_id"] stringValue]
                                                                                              videoId:[video[@"id"] stringValue]];
        [self.navigationController pushViewController:playerVC animated:YES];
        return;
    }
    PostDetailViewController *detailVC = [[PostDetailViewController alloc] initWithPost:post];
    [self.navigationController pushViewController:detailVC animated:YES];
}

- (NSString *)bestImageURLFromPhoto:(NSDictionary *)photo {
    if (![photo isKindOfClass:[NSDictionary class]]) return nil;
    NSArray *keys = @[@"photo_604", @"photo_807", @"photo_1280", @"photo_130", @"photo_75", @"photo_150", @"photo_200", @"photo_300"];
    for (NSString *key in keys) {
        NSString *url = photo[key];
        if (url && [url isKindOfClass:[NSString class]] && url.length > 0) return url;
    }
    NSArray *sizes = photo[@"sizes"];
    if ([sizes isKindOfClass:[NSArray class]]) {
        for (NSDictionary *size in sizes) {
            if ([size[@"type"] isEqualToString:@"x"] || [size[@"type"] isEqualToString:@"z"]) return size[@"url"];
        }
        return [(NSDictionary *)[sizes lastObject] objectForKey:@"url"];
    }
    return nil;
}

@end