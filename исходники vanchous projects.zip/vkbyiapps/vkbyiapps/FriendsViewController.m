// FriendsViewController.m
#import "FriendsViewController.h"
#import "SideMenuViewController.h"
#import "VKAPIClient.h"
#import "ProfileViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface FriendsViewController () <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *allFriends;      // все друзья
@property (nonatomic, strong) NSArray *filteredFriends; // отфильтрованные
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSMutableDictionary *avatarCache;
@end

@implementation FriendsViewController

- (void)loadView {
    [super loadView];
    self.title = @"Друзья";
    self.view.backgroundColor = [UIColor whiteColor];
    self.avatarCache = [NSMutableDictionary dictionary];
    
    // Поиск
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 44)];
    self.searchBar.delegate = self;
    self.searchBar.placeholder = @"Поиск по друзьям";
    self.searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.searchBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:self.searchBar];
    
    // Таблица
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, self.view.bounds.size.width, self.view.bounds.size.height - 44)
                                                  style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.rowHeight = 60;
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    
    [self loadFriends];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadFriends {
    [self.spinner startAnimating];
    [[VKAPIClient sharedClient] getFriendsWithCompletion:^(NSArray *friends, NSError *error) {
        [self.spinner stopAnimating];
        if (error) {
            [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            return;
        }
        self.allFriends = friends ?: @[];
        self.filteredFriends = self.allFriends;
        [self.tableView reloadData];
    }];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.filteredFriends.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"FriendCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:15];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = 0; // квадратные как в старом ВК
        cell.imageView.frame = CGRectMake(0,0,40,40);
    }
    NSDictionary *friend = self.filteredFriends[indexPath.row];
    NSString *firstName = friend[@"first_name"] ?: @"";
    NSString *lastName = friend[@"last_name"] ?: @"";
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
    
    // Онлайн/офлайн
    NSNumber *online = friend[@"online"];
    if ([online boolValue]) {
        cell.detailTextLabel.text = @"онлайн";
        cell.detailTextLabel.textColor = [UIColor colorWithRed:0.0 green:0.6 blue:0.0 alpha:1.0];
    } else {
        cell.detailTextLabel.text = @"";
        cell.detailTextLabel.textColor = [UIColor grayColor];
    }
    
    NSString *avatarURL = friend[@"photo_50"] ?: friend[@"photo_100"];
    if (avatarURL) {
        UIImage *cached = self.avatarCache[avatarURL];
        if (cached) {
            cell.imageView.image = cached;
        } else {
            cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
            [[VKAPIClient sharedClient] downloadImageWithURL:avatarURL completion:^(UIImage *image) {
                if (image) {
                    self.avatarCache[avatarURL] = image;
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UITableViewCell *updateCell = [tableView cellForRowAtIndexPath:indexPath];
                        if (updateCell) updateCell.imageView.image = image;
                    });
                }
            }];
        }
    } else {
        cell.imageView.image = [UIImage imageNamed:@"default_avatar"];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *friend = self.filteredFriends[indexPath.row];
    NSString *userId = [friend[@"id"] stringValue];
    ProfileViewController *profileVC = [[ProfileViewController alloc] initWithUserId:userId];
    profileVC.sideMenuController = self.sideMenuController;
    [self.navigationController pushViewController:profileVC animated:YES];
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if (searchText.length == 0) {
        self.filteredFriends = self.allFriends;
    } else {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(first_name CONTAINS[cd] %@) OR (last_name CONTAINS[cd] %@)", searchText, searchText];
        self.filteredFriends = [self.allFriends filteredArrayUsingPredicate:predicate];
    }
    [self.tableView reloadData];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
}

@end