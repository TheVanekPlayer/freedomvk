// VideosViewController.m
#import "VideosViewController.h"
#import "VKAPIClient.h"
#import "SideMenuViewController.h"
#import "VideoPlayerViewController.h"
#import "PullToRefreshView.h"
#import <QuartzCore/QuartzCore.h>

@interface VideosViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *videos;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) PullToRefreshView *pullToRefresh;
@end

@implementation VideosViewController

- (void)loadView {
    [super loadView];
    self.title = @"Видеозаписи";
    self.view.backgroundColor = [UIColor colorWithWhite:0.88 alpha:1.0];
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    [self.view addSubview:self.tableView];
    
    self.pullToRefresh = [[PullToRefreshView alloc] initWithTableView:self.tableView refreshBlock:^{ [self loadVideos]; }];
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithTitle:@"Меню" style:UIBarButtonItemStylePlain target:self action:@selector(menuTapped)];
    self.navigationItem.leftBarButtonItem = menuBtn;
    [self loadVideos];
}

- (void)menuTapped {
    if ([self.sideMenuController isKindOfClass:[SideMenuViewController class]]) {
        [(SideMenuViewController *)self.sideMenuController showMenu];
    }
}

- (void)loadVideos {
    if (!self.pullToRefresh.isRefreshing) [self.spinner startAnimating];
    NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"];
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    if (!userId || !token) {
        [self.spinner stopAnimating];
        [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не удалось определить пользователя" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        return;
    }
    NSString *urlString = [NSString stringWithFormat:@"%@video.get?owner_id=%@&count=50&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], userId, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!self.pullToRefresh.isRefreshing) [self.spinner stopAnimating];
            [self.pullToRefresh endRefreshing];
            if (error || json[@"error"]) {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription ?: json[@"error"][@"error_msg"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                return;
            }
            self.videos = json[@"response"][@"items"];
            [self.tableView reloadData];
        });
    });
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.videos.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"VideoCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.detailTextLabel.textColor = [UIColor grayColor];
    }
    NSDictionary *video = self.videos[indexPath.row];
    cell.textLabel.text = video[@"title"] ?: @"Без названия";
    NSInteger duration = [video[@"duration"] integerValue];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld:%02ld", (long)duration/60, (long)duration%60];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *video = self.videos[indexPath.row];
    NSString *ownerId = [video[@"owner_id"] stringValue];
    NSString *videoId = [video[@"id"] stringValue];
    
    // Открываем видео через VideoPlayerViewController
    VideoPlayerViewController *playerVC = [[VideoPlayerViewController alloc] initWithVideoOwnerId:ownerId videoId:videoId];
    [self.navigationController pushViewController:playerVC animated:YES];
}

@end