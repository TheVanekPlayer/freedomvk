// CreatePostViewController.m
#import "CreatePostViewController.h"
#import "VKAPIClient.h"

@interface CreatePostViewController () <UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) UIImageView *photoPreview;
@property (nonatomic, strong) UIButton *addPhotoButton;
@property (nonatomic, strong) UIButton *publishButton;
@property (nonatomic, strong) UIImage *selectedImage;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@end

@implementation CreatePostViewController

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor colorWithWhite:0.95 alpha:1.0];
    self.title = @"Новая запись";
    
    // ScrollView для прокрутки
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.backgroundColor = [UIColor clearColor];
    self.scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, 500);
    [self.view addSubview:self.scrollView];
    
    // Tap на фон для скрытия клавиатуры
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [self.scrollView addGestureRecognizer:tap];
    
    // Текстовое поле
    self.textView = [[UITextView alloc] initWithFrame:CGRectMake(15, 15, self.view.bounds.size.width - 30, 150)];
    self.textView.font = [UIFont systemFontOfSize:16];
    self.textView.backgroundColor = [UIColor whiteColor];
    self.textView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.textView.layer.borderWidth = 1;
    self.textView.layer.cornerRadius = 8;
    self.textView.delegate = self;
    self.textView.text = @"Введите текст записи...";
    self.textView.textColor = [UIColor lightGrayColor];
    [self.scrollView addSubview:self.textView];
    
    // Превью фото (под текстом)
    self.photoPreview = [[UIImageView alloc] initWithFrame:CGRectMake(15, 180, self.view.bounds.size.width - 30, 180)];
    self.photoPreview.contentMode = UIViewContentModeScaleAspectFit;
    self.photoPreview.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    self.photoPreview.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.photoPreview.layer.borderWidth = 1;
    self.photoPreview.hidden = YES;
    [self.scrollView addSubview:self.photoPreview];
    
    // Кнопка "Добавить фото" – прямо под превью (или на месте превью, если его нет)
    self.addPhotoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.addPhotoButton.frame = CGRectMake(15, 380, self.view.bounds.size.width - 30, 44);
    [self.addPhotoButton setTitle:@"📷 Добавить фото" forState:UIControlStateNormal];
    [self.addPhotoButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.addPhotoButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.35 blue:0.6 alpha:1.0];
    self.addPhotoButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    self.addPhotoButton.layer.cornerRadius = 8;
    [self.addPhotoButton addTarget:self action:@selector(addPhotoTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.scrollView addSubview:self.addPhotoButton];
    
    // Кнопка "Опубликовать" – сразу под кнопкой добавления фото
    self.publishButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.publishButton.frame = CGRectMake(15, 434, self.view.bounds.size.width - 30, 44);
    [self.publishButton setTitle:@"✅ Опубликовать" forState:UIControlStateNormal];
    [self.publishButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.publishButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.6 blue:0.2 alpha:1.0];
    self.publishButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    self.publishButton.layer.cornerRadius = 8;
    [self.publishButton addTarget:self action:@selector(publishTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.scrollView addSubview:self.publishButton];
    
    // Индикатор загрузки
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.spinner.center = self.view.center;
    [self.view addSubview:self.spinner];
    
    // Кнопка "Отмена" в навигации
    UIBarButtonItem *cancelBtn = [[UIBarButtonItem alloc] initWithTitle:@"Отмена" style:UIBarButtonItemStylePlain target:self action:@selector(cancelTapped)];
    self.navigationItem.leftBarButtonItem = cancelBtn;
}

- (void)dismissKeyboard {
    [self.textView resignFirstResponder];
}

#pragma mark - Actions

- (void)addPhotoTapped {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    picker.allowsEditing = NO;
    [self presentModalViewController:picker animated:YES];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    self.selectedImage = info[UIImagePickerControllerOriginalImage];
    [self dismissModalViewControllerAnimated:YES];
    self.photoPreview.image = self.selectedImage;
    self.photoPreview.hidden = NO;
    // Скрываем кнопку добавления, так как фото уже есть
    self.addPhotoButton.hidden = YES;
    // Сдвигаем кнопку публикации вверх, чтобы она была под фото
    CGRect frame = self.publishButton.frame;
    frame.origin.y = 380;
    self.publishButton.frame = frame;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissModalViewControllerAnimated:YES];
}

- (void)publishTapped {
    NSString *text = self.textView.text;
    if ([text isEqualToString:@"Введите текст записи..."] || text.length == 0) {
        text = @"";
    }
    NSString *ownerId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"] ?: @"";
    if (!ownerId.length) {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:@"Не определён пользователь" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
        return;
    }
    [self.spinner startAnimating];
    self.publishButton.enabled = NO;
    
    void (^publishBlock)(NSString *) = ^(NSString *attachment) {
        [[VKAPIClient sharedClient] wallPost:text ownerId:ownerId attachment:attachment completion:^(BOOL success, NSError *error) {
            [self.spinner stopAnimating];
            self.publishButton.enabled = YES;
            if (success) {
                [[[UIAlertView alloc] initWithTitle:@"Успех" message:@"Запись опубликована" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                [self.navigationController popViewControllerAnimated:YES];
            } else {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            }
        }];
    };
    
    if (self.selectedImage) {
        [[VKAPIClient sharedClient] uploadPhotoForWall:self.selectedImage completion:^(NSString *attachment, NSError *error) {
            if (error) {
                [self.spinner stopAnimating];
                self.publishButton.enabled = YES;
                [[[UIAlertView alloc] initWithTitle:@"Ошибка" message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
                return;
            }
            publishBlock(attachment);
        }];
    } else {
        publishBlock(nil);
    }
}

- (void)cancelTapped {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView {
    if ([textView.text isEqualToString:@"Введите текст записи..."]) {
        textView.text = @"";
        textView.textColor = [UIColor blackColor];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    if (textView.text.length == 0) {
        textView.text = @"Введите текст записи...";
        textView.textColor = [UIColor lightGrayColor];
    }
}

@end