// VKAPIClient.m
#import "VKAPIClient.h"
#import <CFNetwork/CFNetwork.h>

static NSString * const kVKAPIVersion = @"5.131";

@implementation NSURLRequest (IgnoreSSL)
+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host { return YES; }
@end

@interface VKAPIClient ()
@property (nonatomic, assign) BOOL longPollActive;
@property (nonatomic, copy) void (^longPollHandler)(NSDictionary *);
@property (nonatomic, strong) NSMutableDictionary *videoPreviewCache;
@end

@implementation VKAPIClient

+ (instancetype)sharedClient {
    static VKAPIClient *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ shared = [[self alloc] init]; });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _videoPreviewCache = [NSMutableDictionary dictionary];
    }
    return self;
}

- (BOOL)useProxy {
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"UseDirectSSL"]) return NO;
    NSString *proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"ProxyAddress"];
    return (proxy.length > 0);
}

- (NSString *)baseURLString {
    if ([self useProxy]) {
        NSString *proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"ProxyAddress"];
        if (proxy.length > 0) {
            if (![proxy hasSuffix:@"/"]) proxy = [proxy stringByAppendingString:@"/"];
            return [NSString stringWithFormat:@"%@method/", proxy];
        }
    }
    return @"https://api.vk.com/method/";
}

#pragma mark - Базовые сетевые методы (без изменений)

- (NSDictionary *)performSyncGET:(NSString *)urlString error:(NSError **)error {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) {
        if (error) *error = [NSError errorWithDomain:@"VK" code:-3 userInfo:@{NSLocalizedDescriptionKey: @"Неверный URL"}];
        return nil;
    }
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20.0];
    [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
    [req setValue:@"https://vk.com/" forHTTPHeaderField:@"Referer"];
    NSHTTPURLResponse *resp = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:req returningResponse:&resp error:error];
    if (!data) return nil;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:error];
    return json;
}

- (void)performAsyncGET:(NSString *)urlString completion:(void(^)(NSData *data, NSError *error))completion {
    if (!urlString || !completion) return;
    BOOL shouldUseProxy = [self useProxy];
    NSString *finalURLString = urlString;
    if (shouldUseProxy) {
        NSString *proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"ProxyAddress"];
        if (proxy.length > 0) {
            if (![proxy hasSuffix:@"/"]) proxy = [proxy stringByAppendingString:@"/"];
            finalURLString = [NSString stringWithFormat:@"%@%@", proxy, urlString];
        } else shouldUseProxy = NO;
    }
    NSURL *url = [NSURL URLWithString:finalURLString];
    if (!url) {
        completion(nil, [NSError errorWithDomain:@"VK" code:-3 userInfo:@{NSLocalizedDescriptionKey: @"Неверный URL"}]);
        return;
    }
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20.0];
    [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
    [req setValue:@"https://vk.com/" forHTTPHeaderField:@"Referer"];
    [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        NSInteger statusCode = 0;
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) statusCode = [(NSHTTPURLResponse *)response statusCode];
        if (!error && data && statusCode == 200) {
            completion(data, nil);
            return;
        }
        if (shouldUseProxy) {
            NSURL *directURL = [NSURL URLWithString:urlString];
            if (directURL) {
                NSMutableURLRequest *directReq = [NSMutableURLRequest requestWithURL:directURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20.0];
                [directReq setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
                [directReq setValue:@"https://vk.com/" forHTTPHeaderField:@"Referer"];
                [NSURLConnection sendAsynchronousRequest:directReq queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *directResponse, NSData *directData, NSError *directError) {
                    NSInteger directStatus = 0;
                    if ([directResponse isKindOfClass:[NSHTTPURLResponse class]]) directStatus = [(NSHTTPURLResponse *)directResponse statusCode];
                    if (!directError && directData && directStatus == 200) {
                        completion(directData, nil);
                    } else {
                        completion(nil, directError ?: error);
                    }
                }];
                return;
            }
        }
        completion(nil, error);
    }];
}

- (void)performAsyncPOST:(NSString *)urlString body:(NSData *)body headers:(NSDictionary *)headers completion:(void(^)(NSData *data, NSError *error))completion {
    if (!urlString || !completion) return;
    BOOL shouldUseProxy = [self useProxy];
    NSString *finalURLString = urlString;
    if (shouldUseProxy) {
        NSString *proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"ProxyAddress"];
        if (proxy.length > 0) {
            if (![proxy hasSuffix:@"/"]) proxy = [proxy stringByAppendingString:@"/"];
            finalURLString = [NSString stringWithFormat:@"%@%@", proxy, urlString];
        } else shouldUseProxy = NO;
    }
    NSURL *url = [NSURL URLWithString:finalURLString];
    if (!url) {
        completion(nil, [NSError errorWithDomain:@"VK" code:-3 userInfo:@{NSLocalizedDescriptionKey: @"Неверный URL"}]);
        return;
    }
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30.0];
    [req setHTTPMethod:@"POST"];
    [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
    [req setValue:@"https://vk.com/" forHTTPHeaderField:@"Referer"];
    for (NSString *key in headers) {
        [req setValue:headers[key] forHTTPHeaderField:key];
    }
    if (body) {
        [req setHTTPBody:body];
    }
    if (shouldUseProxy) {
        [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            if (!error && data) {
                completion(data, nil);
            } else {
                NSURL *directURL = [NSURL URLWithString:urlString];
                if (directURL) {
                    NSMutableURLRequest *directReq = [NSMutableURLRequest requestWithURL:directURL cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30.0];
                    [directReq setHTTPMethod:@"POST"];
                    [directReq setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
                    [directReq setValue:@"https://vk.com/" forHTTPHeaderField:@"Referer"];
                    for (NSString *key in headers) {
                        [directReq setValue:headers[key] forHTTPHeaderField:key];
                    }
                    if (body) {
                        [directReq setHTTPBody:body];
                    }
                    [NSURLConnection sendAsynchronousRequest:directReq queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *directResponse, NSData *directData, NSError *directError) {
                        if (!directError && directData) {
                            completion(directData, nil);
                        } else {
                            completion(nil, directError ?: error);
                        }
                    }];
                } else {
                    completion(nil, error);
                }
            }
        }];
    } else {
        NSError *err = nil;
        NSData *result = [self securePOSTRequestWithURL:url body:body headers:headers error:&err];
        if (result && !err) {
            completion(result, nil);
        } else {
            completion(nil, err);
        }
    }
}

- (NSData *)securePOSTRequestWithURL:(NSURL *)url body:(NSData *)body headers:(NSDictionary *)headers error:(NSError **)error {
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"UseDirectSSL"]) {
        CFHTTPMessageRef request = CFHTTPMessageCreateRequest(kCFAllocatorDefault, CFSTR("POST"), (__bridge CFURLRef)url, kCFHTTPVersion1_1);
        CFHTTPMessageSetHeaderFieldValue(request, CFSTR("User-Agent"), CFSTR("VKAndroidApp/7.0"));
        for (NSString *key in headers) {
            CFHTTPMessageSetHeaderFieldValue(request, (__bridge CFStringRef)key, (__bridge CFStringRef)headers[key]);
        }
        if (body) {
            CFHTTPMessageSetBody(request, (__bridge CFDataRef)body);
        }
        CFReadStreamRef readStream = CFReadStreamCreateForHTTPRequest(kCFAllocatorDefault, request);
        CFRelease(request);
        CFMutableDictionaryRef sslSettings = CFDictionaryCreateMutable(kCFAllocatorDefault, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
        CFDictionarySetValue(sslSettings, kCFStreamSSLAllowsAnyRoot, kCFBooleanTrue);
        CFDictionarySetValue(sslSettings, kCFStreamSSLValidatesCertificateChain, kCFBooleanFalse);
        CFDictionarySetValue(sslSettings, kCFStreamSSLPeerName, kCFNull);
        CFReadStreamSetProperty(readStream, kCFStreamPropertySSLSettings, sslSettings);
        CFRelease(sslSettings);
        if (!CFReadStreamOpen(readStream)) {
            if (error) *error = [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось открыть поток"}];
            CFRelease(readStream);
            return nil;
        }
        NSMutableData *responseData = [NSMutableData data];
        UInt8 buffer[4096];
        while (CFReadStreamHasBytesAvailable(readStream)) {
            CFIndex bytesRead = CFReadStreamRead(readStream, buffer, sizeof(buffer));
            if (bytesRead > 0) {
                [responseData appendBytes:buffer length:bytesRead];
            } else if (bytesRead < 0) {
                CFErrorRef streamError = CFReadStreamCopyError(readStream);
                if (streamError) {
                    if (error) *error = (__bridge NSError *)streamError;
                    CFRelease(streamError);
                }
                CFReadStreamClose(readStream);
                CFRelease(readStream);
                return nil;
            }
        }
        CFReadStreamClose(readStream);
        CFRelease(readStream);
        return responseData.length ? responseData : nil;
    } else {
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30.0];
        [req setHTTPMethod:@"POST"];
        [req setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
        [req setValue:@"https://vk.com/" forHTTPHeaderField:@"Referer"];
        for (NSString *key in headers) {
            [req setValue:headers[key] forHTTPHeaderField:key];
        }
        if (body) {
            [req setHTTPBody:body];
        }
        NSHTTPURLResponse *resp = nil;
        return [NSURLConnection sendSynchronousRequest:req returningResponse:&resp error:error];
    }
}

#pragma mark - Авторизация

- (void)validateToken:(NSString *)token completion:(void(^)(BOOL valid, NSString *userId, NSString *errorMessage))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *urlString = [NSString stringWithFormat:@"%@users.get?access_token=%@&v=%@", [self baseURLString], token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, nil, error.localizedDescription);
                return;
            }
            if (json[@"error"]) {
                completion(NO, nil, json[@"error"][@"error_msg"]);
                return;
            }
            NSArray *users = json[@"response"];
            if (users.count > 0) {
                completion(YES, [users[0][@"id"] stringValue], nil);
            } else {
                completion(NO, nil, @"Не удалось получить данные пользователя");
            }
        });
    });
}

#pragma mark - Новости

- (void)getNewsfeedWithCompletion:(void(^)(NSArray *items, NSArray *profiles, NSArray *groups, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, nil, nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@newsfeed.get?filters=post&count=10&fields=photo_50&access_token=%@&v=%@", [self baseURLString], token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, nil, nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, nil, nil, apiError);
                return;
            }
            NSDictionary *resp = json[@"response"];
            completion(resp[@"items"], resp[@"profiles"] ?: @[], resp[@"groups"] ?: @[], nil);
        });
    });
}

#pragma mark - Друзья

- (void)getFriendsWithCompletion:(void(^)(NSArray *friends, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@friends.get?fields=photo_50,online&access_token=%@&v=%@", [self baseURLString], token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            completion(json[@"response"][@"items"], nil);
        });
    });
}

#pragma mark - Сообщения (базовые методы)

- (void)getConversationsWithCompletion:(void(^)(NSArray *conversations, NSDictionary *profiles, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@messages.getConversations?count=20&fields=photo_50&extended=1&access_token=%@&v=%@", [self baseURLString], token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, nil, apiError);
                return;
            }
            NSDictionary *response = json[@"response"];
            NSArray *items = response[@"items"];
            NSArray *profilesArray = response[@"profiles"] ?: @[];
            NSMutableDictionary *profilesDict = [NSMutableDictionary dictionary];
            for (NSDictionary *profile in profilesArray) {
                NSNumber *uid = profile[@"id"];
                if (uid) {
                    profilesDict[uid] = profile;
                }
            }
            completion(items, profilesDict, nil);
        });
    });
}

- (void)getMessageHistoryForPeerId:(NSString *)peerId completion:(void(^)(NSArray *messages, NSError *error))completion {
    [self getMessageHistoryForPeerId:peerId offset:0 count:30 completion:completion];
}

- (void)getMessageHistoryForPeerId:(NSString *)peerId offset:(NSInteger)offset count:(NSInteger)count completion:(void(^)(NSArray *messages, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@messages.getHistory?peer_id=%@&count=%ld&offset=%ld&v=%@&access_token=%@",
                               [self baseURLString], peerId, (long)count, (long)offset, kVKAPIVersion, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            NSArray *items = json[@"response"][@"items"];
            NSArray *reversed = [[items reverseObjectEnumerator] allObjects];
            completion(reversed, nil);
        });
    });
}

- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    [self sendMessage:message toPeerId:peerId attachment:nil stickerId:nil completion:completion];
}

- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId attachment:(NSString *)attachment stickerId:(NSString *)stickerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSInteger randomId = arc4random_uniform(9999999);
        NSMutableString *urlString = [NSMutableString stringWithFormat:@"%@messages.send?peer_id=%@&random_id=%ld&access_token=%@&v=%@",
                                      [self baseURLString], peerId, (long)randomId, token, kVKAPIVersion];
        if (message.length > 0) {
            NSString *encodedMessage = [message stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [urlString appendFormat:@"&message=%@", encodedMessage];
        }
        if (attachment.length > 0) {
            [urlString appendFormat:@"&attachment=%@", attachment];
        }
        if (stickerId.length > 0) {
            NSCharacterSet *nonDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
            if ([stickerId rangeOfCharacterFromSet:nonDigits].location == NSNotFound) {
                [urlString appendFormat:@"&sticker_id=%@", stickerId];
            }
        }
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

- (void)sendMessage:(NSString *)message toPeerId:(NSString *)peerId replyTo:(NSNumber *)replyTo completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSInteger randomId = arc4random_uniform(9999999);
        NSString *encodedMessage = [message stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.send?peer_id=%@&random_id=%ld&message=%@&reply_to=%@&access_token=%@&v=5.131",
                               [self baseURLString], peerId, (long)randomId, encodedMessage, replyTo, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

- (void)editMessage:(NSString *)newText forMessageId:(NSNumber *)messageId peerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *encodedText = [newText stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.edit?peer_id=%@&message_id=%@&message=%@&access_token=%@&v=5.131",
                               [self baseURLString], peerId, messageId, encodedText, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

- (void)markMessagesAsReadWithPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@messages.markAsRead?peer_id=%@&access_token=%@&v=5.131",
                               [self baseURLString], peerId, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

- (void)sendSticker:(NSString *)stickerId toPeerId:(NSString *)peerId completion:(void(^)(BOOL success, NSError *error))completion {
    if (!stickerId || !peerId) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Неверные параметры"}]);
        });
        return;
    }
    NSString *numericId = stickerId;
    NSCharacterSet *nonDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    if ([stickerId rangeOfCharacterFromSet:nonDigits].location != NSNotFound) {
        NSArray *parts = [stickerId componentsSeparatedByString:@"-"];
        if (parts.count > 1) {
            NSString *lastPart = [parts lastObject];
            if ([lastPart rangeOfCharacterFromSet:nonDigits].location == NSNotFound) {
                numericId = lastPart;
            }
        }
    }
    if (!numericId || numericId.length == 0) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Некорректный ID стикера"}]);
        });
        return;
    }
    [self sendMessage:@"" toPeerId:peerId attachment:nil stickerId:numericId completion:completion];
}

#pragma mark - Поиск по сообщениям

- (void)searchMessagesWithQuery:(NSString *)query peerId:(NSString *)peerId completion:(void(^)(NSArray *messages, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *encodedQuery = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@messages.search?q=%@&peer_id=%@&count=50&access_token=%@&v=5.131",
                               [self baseURLString], encodedQuery, peerId ?: @"", token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (!json || json[@"error"]) {
                NSError *apiError = json[@"error"] ? [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                                     userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}] : [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Ошибка поиска"}];
                completion(nil, apiError);
                return;
            }
            NSArray *items = json[@"response"][@"items"] ?: @[];
            completion(items, nil);
        });
    });
}

#pragma mark - Загрузка фото для сообщения

- (void)uploadPhotoForMessage:(UIImage *)photo completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *getServerUrl = [NSString stringWithFormat:@"%@photos.getMessagesUploadServer?access_token=%@&v=%@",
                                  [self baseURLString], token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *serverJson = [self performSyncGET:getServerUrl error:&error];
        if (error || !serverJson || serverJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: serverJson[@"error"][@"error_msg"] ?: @"Ошибка получения сервера"}];
                completion(nil, err);
            });
            return;
        }
        NSString *uploadURL = serverJson[@"response"][@"upload_url"];
        if (!uploadURL) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось получить URL для загрузки"}]);
            });
            return;
        }
        NSData *imageData = UIImageJPEGRepresentation(photo, 0.9);
        NSString *boundary = @"----VKUploadBoundary";
        NSMutableData *body = [NSMutableData data];
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Disposition: form-data; name=\"photo\"; filename=\"photo.jpg\"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:imageData];
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
        NSMutableURLRequest *uploadRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:uploadURL]];
        [uploadRequest setHTTPMethod:@"POST"];
        [uploadRequest setValue:contentType forHTTPHeaderField:@"Content-Type"];
        [uploadRequest setValue:[NSString stringWithFormat:@"%lu", (unsigned long)body.length] forHTTPHeaderField:@"Content-Length"];
        [uploadRequest setHTTPBody:body];
        [uploadRequest setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
        NSHTTPURLResponse *uploadResponse = nil;
        NSData *uploadResponseData = [NSURLConnection sendSynchronousRequest:uploadRequest returningResponse:&uploadResponse error:&error];
        if (error || !uploadResponseData) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Ошибка загрузки фото на сервер"}]);
            });
            return;
        }
        NSDictionary *uploadJson = [NSJSONSerialization JSONObjectWithData:uploadResponseData options:0 error:&error];
        if (error || !uploadJson || uploadJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: uploadJson[@"error"] ?: @"Ошибка разбора ответа"}];
                completion(nil, err);
            });
            return;
        }
        NSString *server = uploadJson[@"server"] ?: uploadJson[@"server_id"] ?: uploadJson[@"upload_server"];
        NSString *photoParam = uploadJson[@"photo"] ?: uploadJson[@"photos_list"];
        NSString *hashParam = uploadJson[@"hash"] ?: uploadJson[@"secret"];
        if (!server || !photoParam || !hashParam) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось извлечь параметры"}]);
            });
            return;
        }
        if ([photoParam hasPrefix:@"\""] && [photoParam hasSuffix:@"\""]) {
            photoParam = [photoParam substringWithRange:NSMakeRange(1, photoParam.length-2)];
        }
        NSString *encodedPhoto = (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(NULL, (__bridge CFStringRef)photoParam, NULL, CFSTR("!*'();:@&=+$,/?%#[]"), kCFStringEncodingUTF8);
        NSString *saveUrlString = [NSString stringWithFormat:@"%@photos.saveMessagesPhoto?server=%@&photo=%@&hash=%@&access_token=%@&v=%@",
                                   [self baseURLString], server, encodedPhoto, hashParam, token, kVKAPIVersion];
        NSDictionary *saveJson = [self performSyncGET:saveUrlString error:&error];
        if (error || !saveJson || saveJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: saveJson[@"error"][@"error_msg"] ?: @"Ошибка сохранения"}];
                completion(nil, err);
            });
            return;
        }
        NSArray *savedPhotos = saveJson[@"response"];
        if (![savedPhotos isKindOfClass:[NSArray class]] || savedPhotos.count == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Фото не сохранено"}]);
            });
            return;
        }
        NSDictionary *photoInfo = savedPhotos[0];
        NSString *ownerId = [photoInfo[@"owner_id"] stringValue];
        NSString *photoId = [photoInfo[@"id"] stringValue];
        NSString *attachment = [NSString stringWithFormat:@"photo%@_%@", ownerId, photoId];
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(attachment, nil);
        });
    });
}

#pragma mark - Загрузка видео для сообщения

- (void)uploadVideoForMessage:(NSURL *)videoURL completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"] ?: @"";
        NSString *getServerUrl = [NSString stringWithFormat:@"%@video.getUploadServer?access_token=%@&v=5.131",
                                  [self baseURLString], token];
        NSError *error = nil;
        NSDictionary *serverJson = [self performSyncGET:getServerUrl error:&error];
        if (error || !serverJson || serverJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: serverJson[@"error"][@"error_msg"] ?: @"Ошибка получения сервера"}];
                completion(nil, err);
            });
            return;
        }
        NSString *uploadURL = serverJson[@"response"][@"upload_url"];
        if (!uploadURL) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось получить URL для загрузки видео"}]);
            });
            return;
        }
        NSData *videoData = [NSData dataWithContentsOfURL:videoURL];
        if (!videoData) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось прочитать видеофайл"}]);
            });
            return;
        }
        NSString *boundary = @"----VKUploadBoundary";
        NSMutableData *body = [NSMutableData data];
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Disposition: form-data; name=\"video\"; filename=\"video.mp4\"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: video/mp4\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:videoData];
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
        NSMutableURLRequest *uploadRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:uploadURL]];
        [uploadRequest setHTTPMethod:@"POST"];
        [uploadRequest setValue:contentType forHTTPHeaderField:@"Content-Type"];
        [uploadRequest setValue:[NSString stringWithFormat:@"%lu", (unsigned long)body.length] forHTTPHeaderField:@"Content-Length"];
        [uploadRequest setHTTPBody:body];
        [uploadRequest setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
        NSHTTPURLResponse *uploadResponse = nil;
        NSData *uploadResponseData = [NSURLConnection sendSynchronousRequest:uploadRequest returningResponse:&uploadResponse error:&error];
        if (error || !uploadResponseData) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Ошибка загрузки видео"}]);
            });
            return;
        }
        NSDictionary *uploadJson = [NSJSONSerialization JSONObjectWithData:uploadResponseData options:0 error:&error];
        if (error || !uploadJson || uploadJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: uploadJson[@"error"] ?: @"Ошибка разбора ответа"}];
                completion(nil, err);
            });
            return;
        }
        NSString *server = uploadJson[@"server"] ?: uploadJson[@"server_id"] ?: uploadJson[@"upload_server"];
        NSString *videoParam = uploadJson[@"video"] ?: uploadJson[@"file"];
        NSString *hashParam = uploadJson[@"hash"] ?: uploadJson[@"secret"];
        if (!server || !videoParam || !hashParam) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось извлечь параметры"}]); return;
            });
            return;
        }
        NSString *saveUrlString = [NSString stringWithFormat:@"%@video.save?server=%@&video=%@&hash=%@&owner_id=%@&name=video&access_token=%@&v=5.131",
                                   [self baseURLString], server, videoParam, hashParam, userId, token];
        NSDictionary *saveJson = [self performSyncGET:saveUrlString error:&error];
        if (error || !saveJson || saveJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: saveJson[@"error"][@"error_msg"] ?: @"Ошибка сохранения видео"}];
                completion(nil, err);
            });
            return;
        }
        NSDictionary *response = saveJson[@"response"];
        if (!response || ![response isKindOfClass:[NSDictionary class]]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Ответ сохранения видео пуст"}]);
            });
            return;
        }
        NSString *ownerId = [response[@"owner_id"] stringValue];
        NSString *videoId = [response[@"id"] stringValue];
        if (!ownerId || !videoId) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось получить ID видео"}]);
            });
            return;
        }
        NSString *attachment = [NSString stringWithFormat:@"video%@_%@", ownerId, videoId];
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(attachment, nil);
        });
    });
}

#pragma mark - Стикерпаки (упрощённо, только для совместимости)

- (void)getStickerPacksWithCompletion:(void(^)(NSArray *packs, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@store.getProducts?type=stickers&access_token=%@&v=5.131",
                               [self baseURLString], token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || !json || json[@"error"]) {
                completion(@[], nil);
                return;
            }
            NSArray *items = json[@"response"][@"items"] ?: @[];
            completion(items, nil);
        });
    });
}

- (void)getStickersForPackId:(NSInteger)packId completion:(void(^)(NSArray *stickers, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@store.getStickers?product_id=%ld&access_token=%@&v=5.131",
                               [self baseURLString], (long)packId, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || !json || json[@"error"]) {
                completion(@[], nil);
                return;
            }
            NSArray *items = json[@"response"][@"items"] ?: @[];
            completion(items, nil);
        });
    });
}

#pragma mark - Стикеры (получение изображения)

- (void)getStickerImageWithId:(NSString *)stickerId completion:(void(^)(UIImage *image, NSError *error))completion {
    if (!stickerId) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Некорректный ID стикера"}]);
        });
        return;
    }
    NSArray *urls = @[
                      [NSString stringWithFormat:@"https://vk.com/sticker/%@/512.png", stickerId],
                      [NSString stringWithFormat:@"https://vk.com/sticker/%@/256.png", stickerId],
                      [NSString stringWithFormat:@"https://vk.com/sticker/%@/128.png", stickerId],
                      [NSString stringWithFormat:@"https://vk.com/sticker/%@-256b.png", stickerId],
                      [NSString stringWithFormat:@"https://vk.com/sticker/%@-256.png", stickerId]
                      ];
    [self tryLoadStickerWithURLs:urls index:0 completion:completion];
}

- (void)tryLoadStickerWithURLs:(NSArray *)urls index:(NSInteger)index completion:(void(^)(UIImage *image, NSError *error))completion {
    if (index >= urls.count) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось загрузить стикер"}]);
        });
        return;
    }
    NSString *urlString = urls[index];
    [self downloadImageWithURL:urlString completion:^(UIImage *image) {
        if (image) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(image, nil);
            });
        } else {
            [self tryLoadStickerWithURLs:urls index:index+1 completion:completion];
        }
    }];
}

#pragma mark - Загрузка картинок (с кэшированием)

- (void)downloadImageWithURL:(NSString *)imageURL completion:(void(^)(UIImage *image))completion {
    if (!imageURL || !completion) return;
    static NSCache *imageCache = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        imageCache = [[NSCache alloc] init];
        [imageCache setCountLimit:50];
    });
    UIImage *cached = [imageCache objectForKey:imageURL];
    if (cached) {
        completion(cached);
        return;
    }
    [self performAsyncGET:imageURL completion:^(NSData *data, NSError *error) {
        if (data && !error) {
            UIImage *image = [UIImage imageWithData:data];
            if (image) {
                [imageCache setObject:image forKey:imageURL];
                completion(image);
                return;
            }
        }
        completion(nil);
    }];
}

#pragma mark - Музыка (исправлено)

- (void)getAudioWithCompletion:(void(^)(NSArray *audios, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"] ?: @"";
        NSString *urlString = [NSString stringWithFormat:@"%@audio.get?owner_id=%@&count=100&need_links=1&access_token=%@&v=%@",
                               [self baseURLString], userId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        if (error || !json || json[@"error"]) {
            // fallback на поиск популярного
            [self searchAudioWithQuery:@"популярное" completion:^(NSArray *audios, NSError *searchError) {
                if (searchError) {
                    completion(nil, searchError);
                } else {
                    completion(audios, nil);
                }
            }];
            return;
        }
        NSArray *items = json[@"response"][@"items"];
        if (![items isKindOfClass:[NSArray class]]) {
            items = @[];
        }
        NSMutableArray *filtered = [NSMutableArray array];
        for (NSDictionary *audio in items) {
            if ([audio isKindOfClass:[NSDictionary class]] && audio[@"url"] && [audio[@"url"] isKindOfClass:[NSString class]]) {
                [filtered addObject:audio];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(filtered, nil);
        });
    });
}

- (void)searchAudioWithQuery:(NSString *)query completion:(void(^)(NSArray *audios, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *encodedQuery = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@audio.search?q=%@&count=50&access_token=%@&v=5.131",
                               [self baseURLString], encodedQuery, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        if (error || !json || json[@"error"]) {
            if (error) {
                completion(nil, error);
            } else {
                NSError *err = [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"] ?: @"Ошибка поиска"}];
                completion(nil, err);
            }
            return;
        }
        NSArray *items = json[@"response"][@"items"] ?: @[];
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(items, nil);
        });
    });
}

#pragma mark - Профиль

- (void)profileGetInfoWithUserId:(NSString *)userId completion:(void(^)(NSDictionary *userInfo, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@users.get?user_ids=%@&fields=photo_50,status,bdate,online,last_seen,city&access_token=%@&v=%@", [self baseURLString], userId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            NSArray *users = json[@"response"];
            if (users.count > 0) {
                completion(users[0], nil);
            } else {
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Пользователь не найден"}]);
            }
        });
    });
}

- (void)getWallPostsWithOwnerId:(NSString *)ownerId completion:(void(^)(NSArray *posts, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@wall.get?owner_id=%@&count=10&access_token=%@&v=%@", [self baseURLString], ownerId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            completion(json[@"response"][@"items"], nil);
        });
    });
}

#pragma mark - Поиск (пользователи/группы)

- (void)searchUsersWithQuery:(NSString *)query completion:(void(^)(NSArray *users, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *encodedQuery = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@users.search?q=%@&count=50&fields=photo_50&access_token=%@&v=%@",
                               [self baseURLString], encodedQuery, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            NSArray *items = json[@"response"][@"items"];
            completion(items ?: @[], nil);
        });
    });
}

- (void)searchGroupsWithQuery:(NSString *)query completion:(void(^)(NSArray *groups, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *encodedQuery = [query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@groups.search?q=%@&type=group&count=50&fields=photo_50&access_token=%@&v=%@",
                               [self baseURLString], encodedQuery, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            NSArray *items = json[@"response"][@"items"];
            completion(items ?: @[], nil);
        });
    });
}

#pragma mark - Группы

- (void)getGroupsWithCompletion:(void(^)(NSArray *groups, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"] ?: @"";
        NSString *urlString = [NSString stringWithFormat:@"%@groups.get?user_id=%@&extended=1&fields=photo_50&access_token=%@&v=%@",
                               [self baseURLString], userId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            completion(json[@"response"][@"items"], nil);
        });
    });
}

- (void)joinGroup:(NSString *)groupId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSCharacterSet *nonDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        NSString *cleanGroupId = [[groupId componentsSeparatedByCharactersInSet:nonDigits] componentsJoinedByString:@""];
        if (cleanGroupId.length == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Неверный ID группы"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@groups.join?group_id=%@&access_token=%@&v=5.131",
                               [self baseURLString], cleanGroupId, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

- (void)leaveGroup:(NSString *)groupId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSCharacterSet *nonDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        NSString *cleanGroupId = [[groupId componentsSeparatedByCharactersInSet:nonDigits] componentsJoinedByString:@""];
        if (cleanGroupId.length == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Неверный ID группы"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@groups.leave?group_id=%@&access_token=%@&v=5.131",
                               [self baseURLString], cleanGroupId, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

#pragma mark - Комментарии

- (void)createComment:(NSString *)text forOwnerId:(NSString *)ownerId postId:(NSString *)postId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *encodedText = [text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *urlString = [NSString stringWithFormat:@"%@wall.createComment?owner_id=%@&post_id=%@&message=%@&access_token=%@&v=%@",
                               [self baseURLString], ownerId, postId, encodedText, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

- (void)getCommentsForPostWithOwnerId:(NSString *)ownerId postId:(NSString *)postId completion:(void(^)(NSArray *comments, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@wall.getComments?owner_id=%@&post_id=%@&count=20&access_token=%@&v=%@",
                               [self baseURLString], ownerId, postId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            NSArray *items = json[@"response"][@"items"];
            completion(items ?: @[], nil);
        });
    });
}

#pragma mark - Фотоальбомы

- (void)getPhotoAlbumsWithCompletion:(void(^)(NSArray *albums, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *userId = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKUserId"] ?: @"";
        NSString *urlString = [NSString stringWithFormat:@"%@photos.getAlbums?owner_id=%@&need_system=1&access_token=%@&v=%@",
                               [self baseURLString], userId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(nil, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(nil, apiError);
                return;
            }
            NSArray *items = json[@"response"][@"items"];
            completion(items ?: @[], nil);
        });
    });
}

#pragma mark - Лайки (исправлено)

- (void)addLikeForOwnerId:(NSString *)ownerId itemId:(NSString *)itemId type:(NSString *)type completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        if (![type isEqualToString:@"post"] && ![type isEqualToString:@"comment"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Неверный тип лайка"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@likes.add?type=%@&owner_id=%@&item_id=%@&access_token=%@&v=5.131",
                               [self baseURLString], type, ownerId, itemId, token];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            NSDictionary *response = json[@"response"];
            if (response && [response[@"likes"] integerValue] > 0) {
                completion(YES, nil);
            } else {
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось поставить лайк"}]);
            }
        });
    });
}

#pragma mark - Загрузка фото на стену и публикация поста

- (void)uploadPhotoForWall:(UIImage *)photo completion:(void(^)(NSString *attachment, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *getServerUrl = [NSString stringWithFormat:@"%@photos.getWallUploadServer?access_token=%@&v=%@",
                                  [self baseURLString], token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *serverJson = [self performSyncGET:getServerUrl error:&error];
        if (error || !serverJson || serverJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: serverJson[@"error"][@"error_msg"] ?: @"Ошибка получения сервера"}];
                completion(nil, err);
            });
            return;
        }
        NSString *uploadURL = serverJson[@"response"][@"upload_url"];
        if (!uploadURL) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось получить URL для загрузки на стену"}]);
            });
            return;
        }
        NSData *imageData = UIImageJPEGRepresentation(photo, 0.9);
        NSString *boundary = @"----VKUploadBoundary";
        NSMutableData *body = [NSMutableData data];
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Disposition: form-data; name=\"photo\"; filename=\"photo.jpg\"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:imageData];
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
        NSMutableURLRequest *uploadRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:uploadURL]];
        [uploadRequest setHTTPMethod:@"POST"];
        [uploadRequest setValue:contentType forHTTPHeaderField:@"Content-Type"];
        [uploadRequest setValue:[NSString stringWithFormat:@"%lu", (unsigned long)body.length] forHTTPHeaderField:@"Content-Length"];
        [uploadRequest setHTTPBody:body];
        [uploadRequest setValue:@"VKAndroidApp/7.0" forHTTPHeaderField:@"User-Agent"];
        NSHTTPURLResponse *uploadResponse = nil;
        NSData *uploadResponseData = [NSURLConnection sendSynchronousRequest:uploadRequest returningResponse:&uploadResponse error:&error];
        if (error || !uploadResponseData) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Ошибка загрузки фото на стену"}]);
            });
            return;
        }
        NSDictionary *uploadJson = [NSJSONSerialization JSONObjectWithData:uploadResponseData options:0 error:&error];
        if (error || !uploadJson || uploadJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: uploadJson[@"error"] ?: @"Ошибка ответа"}];
                completion(nil, err);
            });
            return;
        }
        NSString *server = uploadJson[@"server"] ?: uploadJson[@"server_id"] ?: uploadJson[@"upload_server"];
        NSString *photoParam = uploadJson[@"photo"] ?: uploadJson[@"photos_list"];
        NSString *hashParam = uploadJson[@"hash"] ?: uploadJson[@"secret"];
        if (!server || !photoParam || !hashParam) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Не удалось извлечь параметры для стены"}]); return;
            });
            return;
        }
        if ([photoParam hasPrefix:@"\""] && [photoParam hasSuffix:@"\""]) {
            photoParam = [photoParam substringWithRange:NSMakeRange(1, photoParam.length-2)];
        }
        NSString *encodedPhoto = (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(NULL, (__bridge CFStringRef)photoParam, NULL, CFSTR("!*'();:@&=+$,/?%#[]"), kCFStringEncodingUTF8);
        NSString *saveUrlString = [NSString stringWithFormat:@"%@photos.saveWallPhoto?server=%@&photo=%@&hash=%@&access_token=%@&v=%@",
                                   [self baseURLString], server, encodedPhoto, hashParam, token, kVKAPIVersion];
        NSDictionary *saveJson = [self performSyncGET:saveUrlString error:&error];
        if (error || !saveJson || saveJson[@"error"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: saveJson[@"error"][@"error_msg"] ?: @"Ошибка сохранения фото на стене"}];
                completion(nil, err);
            });
            return;
        }
        NSArray *savedPhotos = saveJson[@"response"];
        if (![savedPhotos isKindOfClass:[NSArray class]] || savedPhotos.count == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Фото не сохранено на стене"}]);
            });
            return;
        }
        NSDictionary *photoInfo = savedPhotos[0];
        NSString *ownerId = [photoInfo[@"owner_id"] stringValue];
        NSString *photoId = [photoInfo[@"id"] stringValue];
        NSString *attachment = [NSString stringWithFormat:@"photo%@_%@", ownerId, photoId];
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(attachment, nil);
        });
    });
}

- (void)wallPost:(NSString *)text ownerId:(NSString *)ownerId attachment:(NSString *)attachment completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *encodedText = [text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ?: @"";
        NSMutableString *urlString = [NSMutableString stringWithFormat:@"%@wall.post?owner_id=%@&message=%@&access_token=%@&v=%@",
                                      [self baseURLString], ownerId, encodedText, token, kVKAPIVersion];
        if (attachment.length > 0) {
            [urlString appendFormat:@"&attachments=%@", attachment];
        }
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue]
                                                    userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

#pragma mark - Подписки (друзья)

- (void)followUser:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@friends.add?user_id=%@&access_token=%@&v=%@", [self baseURLString], userId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

- (void)unfollowUser:(NSString *)userId completion:(void(^)(BOOL success, NSError *error))completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
        if (!token) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
            });
            return;
        }
        NSString *urlString = [NSString stringWithFormat:@"%@friends.delete?user_id=%@&access_token=%@&v=%@", [self baseURLString], userId, token, kVKAPIVersion];
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                completion(NO, error);
                return;
            }
            if (json[@"error"]) {
                NSError *apiError = [NSError errorWithDomain:@"VK" code:[json[@"error"][@"error_code"] integerValue] userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"]}];
                completion(NO, apiError);
                return;
            }
            completion(YES, nil);
        });
    });
}

#pragma mark - Видео прокси

- (NSString *)videoProxyURLString:(NSString *)videoURL {
    if (![self useProxy]) return videoURL;
    NSString *proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"ProxyAddress"];
    if (proxy.length == 0) return videoURL;
    NSString *encoded = [videoURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return [NSString stringWithFormat:@"%@video?url=%@", proxy, encoded];
}

#pragma mark - Long Poll (заглушка)

- (void)startLongPollWithCompletion:(void(^)(NSDictionary *event))eventHandler {
    // Заглушка
}

- (void)stopLongPoll {
    // Заглушка
}

- (void)clearVideoPreviewCache {
    [self.videoPreviewCache removeAllObjects];
}
- (void)getLastPostForGroupId:(NSString *)groupId completion:(void(^)(NSDictionary *post, NSError *error))completion {
    if (!groupId) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Неверный ID группы"}]);
        });
        return;
    }
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    if (!token) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(nil, [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: @"Нет токена"}]);
        });
        return;
    }
    NSString *urlString = [NSString stringWithFormat:@"%@wall.get?owner_id=-%@&count=1&access_token=%@&v=5.131",
                           [self baseURLString], groupId, token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [self performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || !json || json[@"error"]) {
                NSError *err = error ?: [NSError errorWithDomain:@"VK" code:-1 userInfo:@{NSLocalizedDescriptionKey: json[@"error"][@"error_msg"] ?: @"Ошибка получения поста"}];
                completion(nil, err);
                return;
            }
            NSArray *items = json[@"response"][@"items"];
            if (items.count > 0) {
                completion(items[0], nil);
            } else {
                completion(nil, nil);
            }
        });
    });
}

@end