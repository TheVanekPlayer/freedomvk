// VideoPlayerViewController.h
#import <UIKit/UIKit.h>

@interface VideoPlayerViewController : UIViewController

- (instancetype)initWithVideoOwnerId:(NSString *)ownerId videoId:(NSString *)videoId;

@end