// PostDetailViewController.h
#import <UIKit/UIKit.h>

@class SideMenuViewController;

@interface PostDetailViewController : UIViewController
@property (nonatomic, unsafe_unretained) SideMenuViewController *sideMenuController;
- (instancetype)initWithPost:(NSDictionary *)post;
@end