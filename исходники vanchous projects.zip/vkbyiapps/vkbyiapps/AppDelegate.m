// AppDelegate.m
#import "AppDelegate.h"
#import "LoginViewController.h"
#import "SideMenuViewController.h"
#import "VKAPIClient.h"
#import "ThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@implementation NSURLRequest (IgnoreSSL)
+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host { return YES; }
@end

@implementation AppDelegate

- (void)applicationDidBecomeActive:(UIApplication *)application {
    application.applicationIconBadgeNumber = 0;
    [self updateBadgeCount];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    // ===== ПРИМЕНЯЕМ ТЕМУ =====
    [ThemeManager applyThemeToWindow:self.window];
    
    // ===== ГЛОБАЛЬНАЯ СТИЛИЗАЦИЯ НАВБАРА =====
    UIColor *tintColor = [ThemeManager navigationBarTintColor];
    UIImage *navBg = [self navigationBarBackgroundImageWithTopColor:tintColor bottomColor:[self darkerColor:tintColor]];
    [[UINavigationBar appearance] setBackgroundImage:navBg forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
    [[UINavigationBar appearance] setTintColor:tintColor];
    [[UINavigationBar appearance] setTitleTextAttributes:@{
                                                           UITextAttributeFont: [UIFont fontWithName:@"HelveticaNeue-Bold" size:20],
                                                           UITextAttributeTextColor: [ThemeManager navigationBarTitleColor],
                                                           UITextAttributeTextShadowColor: [UIColor colorWithWhite:0.0 alpha:0.5],
                                                           UITextAttributeTextShadowOffset: [NSValue valueWithUIOffset:UIOffsetMake(0, -1)]
                                                           }];
    [[UINavigationBar appearance] setBarStyle:UIBarStyleBlack];
    
    // ===== ФОН ТАБЛИЦ =====
    [[UITableView appearance] setBackgroundColor:[UIColor clearColor]];
    [[UITableView appearance] setBackgroundView:nil];
    
    // ===== ЗАПУСК ПРИЛОЖЕНИЯ =====
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    UIViewController *rootController;
    if (token.length > 0) {
        rootController = [[SideMenuViewController alloc] init];
    } else {
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        rootController = [[UINavigationController alloc] initWithRootViewController:loginVC];
    }
    self.window.rootViewController = rootController;
    [self.window makeKeyAndVisible];
    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound)];
    
    [self startGroupPolling];
    
    // Подписка на смену темы
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeDidChange:) name:ThemeDidChangeNotification object:nil];
    
    return YES;
}

- (void)themeDidChange:(NSNotification *)notification {
    [ThemeManager applyThemeToWindow:self.window];
    // Обновляем навбар глобально
    UIColor *tintColor = [ThemeManager navigationBarTintColor];
    UIImage *navBg = [self navigationBarBackgroundImageWithTopColor:tintColor bottomColor:[self darkerColor:tintColor]];
    [[UINavigationBar appearance] setBackgroundImage:navBg forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setTintColor:tintColor];
    [[UINavigationBar appearance] setTitleTextAttributes:@{
                                                           UITextAttributeFont: [UIFont fontWithName:@"HelveticaNeue-Bold" size:20],
                                                           UITextAttributeTextColor: [ThemeManager navigationBarTitleColor],
                                                           UITextAttributeTextShadowColor: [UIColor colorWithWhite:0.0 alpha:0.5],
                                                           UITextAttributeTextShadowOffset: [NSValue valueWithUIOffset:UIOffsetMake(0, -1)]
                                                           }];
}

- (UIImage *)navigationBarBackgroundImageWithTopColor:(UIColor *)topColor bottomColor:(UIColor *)bottomColor {
    CGRect rect = CGRectMake(0, 0, 1, 44);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGFloat locations[] = {0.0, 1.0};
    NSArray *colors = @[(id)topColor.CGColor, (id)bottomColor.CGColor];
    CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)colors, locations);
    CGContextDrawLinearGradient(context, gradient, CGPointMake(0, 0), CGPointMake(0, rect.size.height), 0);
    CGGradientRelease(gradient);
    CGColorSpaceRelease(colorSpace);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (UIColor *)darkerColor:(UIColor *)color {
    CGFloat h, s, b, a;
    if ([color getHue:&h saturation:&s brightness:&b alpha:&a]) {
        return [UIColor colorWithHue:h saturation:s brightness:b * 0.7 alpha:a];
    }
    return color;
}

- (void)updateBadgeCount {
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    if (!token) return;
    NSString *urlString = [NSString stringWithFormat:@"%@messages.getConversations?count=1&access_token=%@&v=5.131",
                           [[VKAPIClient sharedClient] baseURLString], token];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSError *error = nil;
        NSDictionary *json = [[VKAPIClient sharedClient] performSyncGET:urlString error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!error && json[@"response"]) {
                NSInteger unread = [json[@"response"][@"unread_count"] integerValue];
                [UIApplication sharedApplication].applicationIconBadgeNumber = unread;
            }
        });
    });
}

#pragma mark - Групповые уведомления

- (void)startGroupPolling {
    [NSTimer scheduledTimerWithTimeInterval:300 target:self selector:@selector(checkGroupUpdates) userInfo:nil repeats:YES];
}

- (void)checkGroupUpdates {
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"VKAccessToken"];
    if (!token) return;
    [[VKAPIClient sharedClient] getGroupsWithCompletion:^(NSArray *groups, NSError *error) {
        if (error || !groups.count) return;
        for (NSDictionary *group in groups) {
            NSString *groupId = [group[@"id"] stringValue];
            NSString *key = [NSString stringWithFormat:@"lastPost_%@", groupId];
            NSNumber *lastPostId = [[NSUserDefaults standardUserDefaults] objectForKey:key];
            [[VKAPIClient sharedClient] getLastPostForGroupId:groupId completion:^(NSDictionary *post, NSError *error) {
                if (error || !post) return;
                NSNumber *newPostId = post[@"id"];
                if (!lastPostId || [newPostId integerValue] > [lastPostId integerValue]) {
                    [self showLocalNotificationForGroup:group post:post];
                    [[NSUserDefaults standardUserDefaults] setObject:newPostId forKey:key];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }];
        }
    }];
}

- (void)showLocalNotificationForGroup:(NSDictionary *)group post:(NSDictionary *)post {
    NSString *text = post[@"text"] ?: @"(без текста)";
    if (text.length > 50) text = [[text substringToIndex:50] stringByAppendingString:@"..."];
    NSString *body = [NSString stringWithFormat:@"Новый пост в группе %@: %@", group[@"name"], text];
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    notification.alertBody = body;
    notification.soundName = UILocalNotificationDefaultSoundName;
    notification.userInfo = @{@"groupId": group[@"id"], @"postId": post[@"id"]};
    [[UIApplication sharedApplication] presentLocalNotificationNow:notification];
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
    // Можно обработать открытие поста
    NSDictionary *userInfo = notification.userInfo;
    if (userInfo) {
        NSString *groupId = userInfo[@"groupId"];
        NSString *postId = userInfo[@"postId"];
        if (groupId && postId) {
            NSLog(@"Открыть пост %@ в группе %@", postId, groupId);
        }
    }
}

#pragma mark - Push

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    const unsigned char *dataBuffer = (const unsigned char *)[deviceToken bytes];
    NSMutableString *hexString = [NSMutableString stringWithCapacity:([deviceToken length] * 2)];
    for (NSUInteger i = 0; i < [deviceToken length]; ++i) {
        [hexString appendFormat:@"%02x", dataBuffer[i]];
    }
    NSString *token = [hexString copy];
    [[VKAPIClient sharedClient] registerDeviceWithToken:token completion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"Push-уведомления зарегистрированы в VK");
        } else {
            NSLog(@"Ошибка регистрации push в VK: %@", error);
        }
    }];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"Не удалось получить deviceToken: %@", error);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    [self updateBadgeCount];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NewMessageNotification" object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end